# AI & Digital Twin Integration in Product Lifecycle Management (PLM)

An enterprise-grade, responsive full-stack platform integrating **PTC Windchill PLM REST Services** with real-time **WebGL 3D Digital Twins**, **IoT telemetry streaming**, and **AI predictive maintenance models**.

Works seamlessly on mobile phones, tablets, and desktops (PWA-ready), with an automatic **Windchill Demo Mode** fallback when operating outside the campus intranet.

---

## 🌟 Key Features

1. **PTC Windchill PLM REST Integration (OData v4)**:
   - Connects to college server at `http://plm.cit.com/Windchill` (`172.16.31.150`).
   - Secure backend proxy handling Basic Authentication, session cookies, and `CSRF_NONCE` tokens.
   - Credentials configured strictly via `.env` (`WINDCHILL_USER`, `WINDCHILL_PASS`); never exposed to the client.
   - Interactive **Connection Status Indicator** & **Test Connection** button.
   - **Product Creation Workflow**: Register products with Name, `GEN` template, and `PrivateAccess = No`.
   - **BOM Hierarchy**: Browse multi-level product structures with rolled-up costs, mass, and supplier lead times.
   - **Documents & CAD**: WTDocument management with Creo CAD assemblies (`.asm`, `.prt`), GD&T drawings (`.drw`), and FEA simulation reports.
   - **Change Management**: Formal WTChangeRequest2 (ECR), Change Orders (ECO), and Problem Reports (PR).
   - **Demo / Mock Mode**: Rich realistic simulated dataset when outside the campus network.

2. **Interactive 3D Digital Twin Module**:
   - WebGL 3D model using **Three.js** with orbit rotation, pan, zoom, and touch controls.
   - **Exploded View Slider**: Smoothly translates motor subassemblies along the axial plane (casing, stator coils, ceramic bearings, rotor core, shaft).
   - **Thermal Heatmap View**: Dynamic shader rendering temperature gradients across casing and windings.
   - **X-Ray / Wireframe Mode**: Inspect internal rotating components in real time.
   - **Sensor Hotspot Pins**: Interactive 3D pins on the PT100 thermal probe and drive-end bearing.
   - **Live Simulated Telemetry**: Real-time speed (RPM), temperature (°C), vibration harmonics (mm/s), pressure, and power with live Recharts feeds.
   - **Simulate Telemetry Anomalies**: Trigger bearing vibration spikes or thermal overloads to observe closed-loop AI detection.
   - **Lifecycle Timeline**: Tracks Design → Manufacture → Operate → Service → Retire.

3. **AI Engineering Intelligence & Predictive Analytics**:
   - **PLM Engineering Copilot**: Interactive AI chat assistant with domain knowledge on Windchill REST OData, Creo workspace workflows, FMEA, and BOM optimization.
   - **Weibull Failure Reliability Curves**: Calculates cumulative failure probability $P(t) = 1 - e^{-(t/\eta)^\beta}$ ($\beta = 2.4$) with Arrhenius thermal stress acceleration.
   - **Remaining Useful Life (RUL)**: Live MTBF calculation and maintenance countdown.
   - **AI Change Impact Analysis**: Automated risk scoring and justification summaries for ECRs and ECOs.
   - **Anomaly Detection**: Statistical z-score and dynamic threshold verification.

4. **Security, Roles & Data Export**:
   - **Role-Based Access Control (RBAC)**: Admin, Engineer, and Viewer roles with JWT tokens and bcrypt password hashing.
   - **One-Click Quick Login Switcher**: Instant role switching for rapid demonstration.
   - **Export Suite**: Export Parts, Products, and Change Requests to RFC 4180 CSV, formatted Excel (`.xls`), and printable PDF reports.
   - **Audit Trail**: Searchable event logs tracking user logins, sync events, and anomaly simulations.

---

## 🏛️ System Architecture

```mermaid
flowchart LR
    A["Client Browser\n(React 18 + Vite + Tailwind)"] <-->|"REST API + JWT\n(Port 5000)"| B["Node.js Express Proxy\n(Rate Limit, Helmet, CORS)"]
    B <-->|"OData v4 REST\n(CSRF + Basic Auth)"| C["PTC Windchill Server\n(172.16.31.150:80\nplm.cit.com)"]
    B <-->|"SQL Operations"| D[("SQLite Database\nnode:sqlite")]
    B <-->|"Weibull / RUL Models"| E["AI Reasoning Engine"]
    F["PTC Creo Parametric\nCAD Workstation"] <-->|"Workgroup Manager\n(plm.cit.com/Windchill)"| C
```

---

## 🌐 Network Setup: Connecting to College Windchill (`172.16.31.150`)

### 1. Private Campus IP Constraint
The Windchill server is hosted at `172.16.31.150`. This is an **RFC 1918 private IPv4 internal address**. A public web server or home computer cannot route packets directly to `172.16.31.150` without:
1. Connecting directly to the **College Campus Network** (Wi-Fi / Ethernet), OR
2. Establishing a connection through an authorized **College VPN**, OR
3. Setting up a secure **Reverse Proxy** (e.g. NGINX, Cloudflare Tunnel, or WireGuard).

> [!NOTE]
> If you are outside the campus network without VPN, the platform operates in **Windchill Demo Mode**, serving realistic data with complete CRUD functionality.

### 2. Operating System Hosts File Configuration
PTC Windchill requires HTTP requests to address the server by its fully qualified hostname (`plm.cit.com`). You must map `plm.cit.com` to `172.16.31.150`:

**Add this line to your hosts file:**
```
172.16.31.150 plm.cit.com
```

- **Windows**: Edit `C:\Windows\System32\drivers\etc\hosts` (Run Notepad as Administrator).
- **Linux / macOS**: Run `sudo nano /etc/hosts`, paste the line, and save.

---

## 🛠️ PTC Creo Parametric CAD Integration Guide

To connect Creo Parametric workstations to the college Windchill instance:

1. **Register the Server in Creo**:
   - Navigate to **File → Manage Session → Server Management**.
   - Click **Server → Register New Server**.
   - **Name**: `CIT Windchill`
   - **Location**: `http://plm.cit.com/Windchill`
2. **Set as Primary Server**:
   - Right-click the newly added server and select **Set as Primary Server**.
3. **Create Active Workspace**:
   - Under the server menu, click **Workspace → New**.
   - Select context **High-Efficiency Electric Drive Unit 250kW**.
4. **Check-In CAD Assemblies**:
   - Saving or checking in `.prt`, `.asm`, and `.drw` models automatically updates the corresponding WTParts in Windchill and synchronizes with the 3D Digital Twin viewer.

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- **Node.js**: v20+ or v22/v24 (Node 24 recommended, includes built-in `node:sqlite`)
- **npm**: v10+

### Step 1: Clone and Install Dependencies
```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### Step 2: Configure Environment Variables
Copy `.env.example` to `.env` in the `backend/` folder:
```bash
cd backend
cp .env.example .env
```

Edit `backend/.env` with your settings:
```env
PORT=5000
NODE_ENV=development
JWT_SECRET=super_secret_jwt_plm_digital_twin_key_2026
WINDCHILL_BASE_URL=http://plm.cit.com/Windchill
WINDCHILL_USER=your_windchill_username
WINDCHILL_PASS=your_windchill_password
DEMO_MODE=true
```

> [!CAUTION]
> If your Windchill credentials are a shared class account, check with your lab staff before wiring them into public repositories or shared hosting environments.

### Step 3: Seed Database & Run Tests
```bash
# Seed default users, products, BOM, and telemetry
cd backend
npm run seed

# Run automated API unit tests
npm test
```

### Step 4: Run the Application
You can run both services concurrently:

**Terminal 1 (Backend):**
```bash
cd backend
npm run dev
# Running on http://localhost:5000
```

**Terminal 2 (Frontend):**
```bash
cd frontend
npm run dev
# Running on http://localhost:5173 (proxies /api to :5000)
```

Or build the frontend once and let the Express backend serve everything:
```bash
cd frontend && npm run build
cd ../backend && npm start
# Open http://localhost:5000 in your browser
```

---

## 👥 Pre-Configured Demo Accounts

| Role | Email / Login | Password | Capabilities |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@cit.com` | `admin123` | Full access, user management, system settings |
| **Engineer** | `engineer@cit.com` | `eng123` | Create products, WTParts, change requests, 3D twin controls |
| **Viewer** | `viewer@cit.com` | `view123` | Read-only inspection of BOM, twins, and reports |

*Tip: Use the **Quick Demo Accounts** buttons on the login page or navbar for 1-click role switching.*

---

## 🐳 Docker Deployment

A multi-stage `Dockerfile` and `docker-compose.yml` are included.

### Run with Docker Compose:
```bash
docker compose up -d --build
```
This automatically:
- Builds the production React frontend.
- Copies the static assets into the backend server.
- Automatically maps `plm.cit.com:172.16.31.150` via `extra_hosts`.
- Runs SQLite on persistent volume `plm-data`.
- Exposes the full application on `http://localhost:5000`.

---

## ☁️ Production Cloud Deployment (Render / Railway / Vercel)

### Option A: Deployment on Campus Network (Direct Windchill Access)
1. Run the Docker container or Node.js service on a machine inside the college network.
2. Ensure port 5000 is open.
3. Access via the server's local LAN IP: `http://<server-ip>:5000`.

### Option B: Public Cloud with Reverse Proxy / VPN
To host on Render, Railway, or VPS so anyone with the link can access it:
1. **Frontend + Backend Hosting**: Deploy the repository to Render / Railway as a Web Service using the `Dockerfile`.
2. **Environment Variables**: In your cloud dashboard, set:
   - `DEMO_MODE=true` (or `false` if VPN is active)
   - `JWT_SECRET=<strong-random-key>`
   - `PORT=5000`
3. **Windchill Bridge (Optional for Live Data)**:
   - Install **Cloudflare Tunnel** or **Tailscale** on a computer inside the college lab.
   - Expose `172.16.31.150:80` as a secure tunnel URL (e.g. `https://windchill-proxy.yourdomain.com`).
   - Set `WINDCHILL_BASE_URL=https://windchill-proxy.yourdomain.com/Windchill` in your cloud web service.
4. **HTTPS**: Render and Railway provision free SSL/TLS certificates automatically.

---

## 🧪 Automated Test Verification

Run the test suite:
```bash
cd backend
npm test
```
**Test Coverage**:
- Health check & server details endpoint
- JWT login with valid and invalid credentials
- Windchill connection status & fallback modes
- Product retrieval (`GEN` template validation)
- Multi-level BOM hierarchy rollup
- Digital Twin live telemetry stream
- Weibull failure risk & RUL model calculation
- AI Copilot domain reasoning
- RFC 4180 CSV export

---

## 📄 License
MIT License. Developed for CIT Advanced Engineering Systems.
