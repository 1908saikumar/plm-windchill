import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => localStorage.getItem('plm_theme') || 'dark');
  const [accent, setAccent] = useState(() => localStorage.getItem('plm_accent') || 'teal');
  const [logoStyle, setLogoStyle] = useState(() => localStorage.getItem('plm_logo_style') || 'turbine');
  const [customLogoUrl, setCustomLogoUrl] = useState(() => localStorage.getItem('plm_custom_logo_url') || '');

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('plm_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('plm_accent', accent);
  }, [accent]);

  useEffect(() => {
    localStorage.setItem('plm_logo_style', logoStyle);
  }, [logoStyle]);

  useEffect(() => {
    if (customLogoUrl) {
      localStorage.setItem('plm_custom_logo_url', customLogoUrl);
    } else {
      localStorage.removeItem('plm_custom_logo_url');
    }
  }, [customLogoUrl]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  return (
    <ThemeContext.Provider value={{
      theme,
      isDark: theme === 'dark',
      toggleTheme,
      setTheme,
      accent,
      setAccent,
      logoStyle,
      setLogoStyle,
      customLogoUrl,
      setCustomLogoUrl
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
}
