import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('plm_auth_token'));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      if (token) {
        try {
          const res = await api.getMe();
          setUser(res.user);
        } catch (err) {
          console.warn('Session expired or invalid, logging out');
          logout();
        }
      }
      setIsLoading(false);
    }
    loadUser();
  }, [token]);

  const login = async (loginField, password) => {
    const res = await api.login(loginField, password);
    localStorage.setItem('plm_auth_token', res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const quickLogin = async (roleName) => {
    const creds = {
      Admin: { login: 'admin@cit.com', pass: 'admin123' },
      Engineer: { login: 'engineer@cit.com', pass: 'eng123' },
      Viewer: { login: 'viewer@cit.com', pass: 'view123' }
    };
    const target = creds[roleName] || creds.Engineer;
    return await login(target.login, target.pass);
  };

  const register = async (userData) => {
    const res = await api.register(userData);
    localStorage.setItem('plm_auth_token', res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const logout = () => {
    localStorage.removeItem('plm_auth_token');
    setToken(null);
    setUser(null);
  };

  const updateProfilePhoto = async (photoUrl) => {
    try {
      const res = await api.updateProfilePhoto(photoUrl);
      if (res.user) {
        setUser(res.user);
      } else {
        setUser(prev => ({ ...prev, avatar: photoUrl }));
      }
      return res;
    } catch (err) {
      setUser(prev => ({ ...prev, avatar: photoUrl }));
      throw err;
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      setUser,
      token,
      role: user?.role || 'Viewer',
      isAuthenticated: !!user,
      isAdmin: user?.role === 'Admin',
      isEngineer: user?.role === 'Engineer' || user?.role === 'Admin',
      isLoading,
      login,
      quickLogin,
      register,
      logout,
      updateProfilePhoto
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}
