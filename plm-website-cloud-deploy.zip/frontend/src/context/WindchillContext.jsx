import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api';

const WindchillContext = createContext(null);

export function WindchillProvider({ children }) {
  const [status, setStatus] = useState({
    connected: true,
    mode: 'demo',
    isDemo: true,
    baseUrl: 'http://plm.cit.com/Windchill',
    serverIp: '172.16.31.150',
    hostname: 'plm.cit.com',
    latencyMs: 14,
    lastChecked: null,
    message: ''
  });
  const [isTesting, setIsTesting] = useState(false);

  const checkStatus = useCallback(async () => {
    try {
      const data = await api.getWindchillStatus();
      setStatus(prev => ({
        ...prev,
        ...data,
        lastChecked: new Date().toLocaleTimeString()
      }));
    } catch (err) {
      console.warn('Failed to retrieve Windchill status:', err.message);
    }
  }, []);

  const testConnection = async () => {
    setIsTesting(true);
    try {
      const res = await api.testWindchillConnection();
      setStatus(prev => ({
        ...prev,
        ...res,
        lastChecked: new Date().toLocaleTimeString()
      }));
      return res;
    } catch (err) {
      const failState = {
        connected: false,
        mode: 'error',
        error: err.message,
        lastChecked: new Date().toLocaleTimeString()
      };
      setStatus(prev => ({ ...prev, ...failState }));
      return failState;
    } finally {
      setIsTesting(false);
    }
  };

  const toggleDemoMode = async (enabled) => {
    try {
      await api.toggleDemoMode(enabled);
      await checkStatus();
    } catch (err) {
      console.error('Failed to toggle demo mode:', err);
    }
  };

  useEffect(() => {
    checkStatus();
    // Re-check periodically every 45s
    const interval = setInterval(checkStatus, 45000);
    return () => clearInterval(interval);
  }, [checkStatus]);

  return (
    <WindchillContext.Provider value={{
      status,
      isTesting,
      isDemo: status.isDemo || status.mode === 'demo',
      checkStatus,
      testConnection,
      toggleDemoMode
    }}>
      {children}
    </WindchillContext.Provider>
  );
}

export function useWindchill() {
  const context = useContext(WindchillContext);
  if (!context) throw new Error('useWindchill must be used within a WindchillProvider');
  return context;
}
