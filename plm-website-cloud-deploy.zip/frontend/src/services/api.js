const API_BASE = '/api';

function getAuthHeader() {
  const token = localStorage.getItem('plm_auth_token');
  return token ? { 'Authorization': `Bearer ${token}` } : {};
}

async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {})
  };

  const config = {
    ...options,
    headers
  };

  if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
    config.body = JSON.stringify(options.body);
  }

  const res = await fetch(url, config);

  if (!res.ok) {
    let errMessage = `Error ${res.status}: ${res.statusText}`;
    try {
      const errorData = await res.json();
      if (errorData.error) errMessage = errorData.error;
    } catch (e) {
      // not JSON
    }
    throw new Error(errMessage);
  }

  // Handle binary/csv/excel download responses
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/csv') || contentType.includes('ms-excel') || contentType.includes('application/octet-stream')) {
    return res.blob();
  }

  return res.json();
}

export const api = {
  // Auth
  login: (login, password) => request('/auth/login', { method: 'POST', body: { login, password } }),
  register: (data) => request('/auth/register', { method: 'POST', body: data }),
  forgotPassword: (email) => request('/auth/forgot-password', { method: 'POST', body: { email } }),
  getMe: () => request('/auth/me'),
  getUsers: () => request('/auth/users'),
  updateUserRole: (id, role) => request(`/auth/users/${id}/role`, { method: 'PATCH', body: { role } }),
  updateProfilePhoto: (photoUrl) => request('/auth/profile-photo', { method: 'POST', body: { photoUrl } }),

  // Windchill REST
  getWindchillStatus: () => request('/windchill/status'),
  testWindchillConnection: () => request('/windchill/test-connection', { method: 'POST' }),
  toggleDemoMode: (enabled) => request('/windchill/toggle-demo', { method: 'POST', body: { enabled } }),
  getWindchillCredentials: () => request('/windchill/credentials'),
  updateWindchillCredentials: (user, pass) => request('/windchill/credentials', { method: 'POST', body: { user, pass } }),
  executeWindchillQuery: (endpoint) => request('/windchill/execute-query', { method: 'POST', body: { endpoint } }),
  
  getProducts: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/windchill/products${q ? `?${q}` : ''}`);
  },
  createProduct: (data) => request('/windchill/products', { method: 'POST', body: data }),
  
  getParts: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/windchill/parts${q ? `?${q}` : ''}`);
  },
  createPart: (data) => request('/windchill/parts', { method: 'POST', body: data }),
  
  getBomTree: (rootPartId) => request(`/windchill/bom${rootPartId ? `?rootPartId=${rootPartId}` : ''}`),
  
  getDocuments: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/windchill/documents${q ? `?${q}` : ''}`);
  },
  createDocument: (data) => request('/windchill/documents', { method: 'POST', body: data }),
  
  getChangeRequests: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/windchill/change-requests${q ? `?${q}` : ''}`);
  },
  createChangeRequest: (data) => request('/windchill/change-requests', { method: 'POST', body: data }),
  
  syncWindchill: () => request('/windchill/sync', { method: 'POST' }),

  // Digital Twin
  getTwinState: () => request('/digital-twin/state'),
  simulateTwinAnomaly: (active, type) => request('/digital-twin/simulate-anomaly', { method: 'POST', body: { active, type } }),

  // AI & Analytics
  askAiAssistant: (message, context) => request('/ai/chat', { method: 'POST', body: { message, context } }),
  predictFailure: (partId) => request(`/ai/predict-failure${partId ? `?partId=${partId}` : ''}`),
  getBomSummary: (rootPartId) => request(`/ai/bom-summary${rootPartId ? `?rootPartId=${rootPartId}` : ''}`),
  getChangeImpact: (id) => request(`/ai/change-impact/${id}`),

  // Audit Logs
  getAuditLogs: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/audit/logs${q ? `?${q}` : ''}`);
  },

  // Settings
  getSettings: () => request('/settings'),
  updateSettings: (data) => request('/settings', { method: 'POST', body: data }),

  // Export URLs
  exportPartsCsvUrl: '/api/export/parts.csv',
  exportProductsCsvUrl: '/api/export/products.csv',
  exportChangesCsvUrl: '/api/export/changes.csv',
  exportExcelUrl: (type = 'parts') => `/api/export/excel?type=${type}`
};

export default api;
