import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { 
  Layers, Thermometer, Eye, RotateCw, ZoomIn, Info, AlertTriangle, 
  Box, Cpu, Disc, Zap, Activity, ChevronDown 
} from 'lucide-react';

export const CAD_MODELS = [
  {
    id: 'motor',
    name: 'EDU-250 Motor Assembly',
    partNumber: 'EDU-250-ASY-001',
    rev: 'Rev B.1',
    category: 'Electric Powertrain',
    desc: 'High-Efficiency 250kW Permanent Magnet Synchronous Drive Unit with Stator RTD Probes and Hybrid Bearings.',
    sensors: [
      { id: 'bearing', label: 'Drive-End Bearing VIB-01', partId: 'PART-BEARING-DE', spec: 'Limit 3.5 mm/s RMS', state: 'RELEASED' },
      { id: 'stator', label: 'Stator PT100 RTD Probe', partId: 'PART-TEMP-SENSOR', spec: 'Warning > 80°C (Max 95°C)', state: 'RELEASED' }
    ]
  },
  {
    id: 'drone',
    name: 'AERO-X4 Quadrotor Drone',
    partNumber: 'AERO-X4-UAV-002',
    rev: 'Rev A.4',
    category: 'Autonomous UAV',
    desc: 'Industrial Inspection Drone with carbon-fiber frame, quad brushless propulsion, and LiDAR telemetry payload.',
    sensors: [
      { id: 'esc', label: 'ESC Thermal Bus M1', partId: 'PART-ESC-40A', spec: 'Warning > 75°C', state: 'RELEASED' },
      { id: 'lidar', label: 'Top LiDAR Telemetry Dome', partId: 'PART-LIDAR-NAV', spec: 'Frequency: 20 Hz, Range: 50m', state: 'INWORK' }
    ]
  },
  {
    id: 'robot_arm',
    name: 'COBOT-R6 Robotic Joint',
    partNumber: 'COBOT-R6-JNT-003',
    rev: 'Rev C.0',
    category: 'Harmonic Articulation',
    desc: '6-Axis Industrial Collaborative Arm Actuator Joint with high-torque strain-wave gearbox and parallel gripper.',
    sensors: [
      { id: 'torque', label: 'Joint Torque Strain Sensor', partId: 'PART-TORQUE-CELL', spec: 'Max 180 N·m dynamic', state: 'RELEASED' },
      { id: 'harmonic', label: 'Flexspline Harmonic VIB', partId: 'PART-HARMONIC-GEAR', spec: 'Limit 2.8 mm/s vibration', state: 'RELEASED' }
    ]
  },
  {
    id: 'turbine',
    name: 'TURBINE-900 Aero Blisk',
    partNumber: 'TURBINE-900-BLK-004',
    rev: 'Rev D.2',
    category: 'Aero Propulsion',
    desc: 'Stage-1 High-Pressure Bladed Disk (Blisk) forged titanium rotor with 24 integrated aerofoil blades and nacelle shroud.',
    sensors: [
      { id: 'blade_strain', label: 'Blade Root Strain Gauge', partId: 'PART-TITANIUM-BLISK', spec: 'Max 450 MPa Centrifugal', state: 'RELEASED' },
      { id: 'pyro', label: 'Inlet Pyrometer Temp Sensor', partId: 'PART-PYRO-900', spec: 'Operating: 750°C - 920°C', state: 'RELEASED' }
    ]
  }
];

export default function DigitalTwinViewer({
  telemetry,
  selectedModelId = 'motor',
  onModelChange,
  height = '480px'
}) {
  const mountRef = useRef(null);
  const [activeModel, setActiveModel] = useState(selectedModelId);
  const [explodeFactor, setExplodeFactor] = useState(0); // 0 = assembled, 1 = fully exploded
  const [thermalView, setThermalView] = useState(false);
  const [wireframeView, setWireframeView] = useState(false);
  const [isRotating, setIsRotating] = useState(true);
  const [activePin, setActivePin] = useState(null);

  // References to 3D subassemblies for exploded view translation
  const partsRef = useRef({});
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const reqIdRef = useRef(null);

  // Sync external model prop
  useEffect(() => {
    if (selectedModelId && selectedModelId !== activeModel) {
      setActiveModel(selectedModelId);
    }
  }, [selectedModelId]);

  const handleModelSelect = (modelId) => {
    setActiveModel(modelId);
    setExplodeFactor(0);
    setActivePin(null);
    if (onModelChange) onModelChange(modelId);
  };

  const currentModelMeta = CAD_MODELS.find(m => m.id === activeModel) || CAD_MODELS[0];

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // --- Scene Setup ---
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x060b17);

    // Camera
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(7, 5, 9);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x06b6d4, 1.5);
    dirLight1.position.set(12, 18, 12);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xf97316, 0.8);
    dirLight2.position.set(-12, -6, -10);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0x14b8a6, 1.2, 20);
    pointLight.position.set(0, 4, 0);
    scene.add(pointLight);

    // Floor Grid
    const grid = new THREE.GridHelper(24, 24, 0x14b8a6, 0x1e293b);
    grid.position.y = -2.6;
    scene.add(grid);

    // Master Group
    const assemblyGroup = new THREE.Group();
    scene.add(assemblyGroup);

    // Reusable Materials
    const metalMat = new THREE.MeshStandardMaterial({ color: 0xcfd8dc, metalness: 0.9, roughness: 0.2 });
    const darkMetalMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.35 });
    const blueHullMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.65, roughness: 0.3, transparent: true, opacity: 0.92 });
    const copperMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.25 });
    const carbonMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.4, roughness: 0.6 });
    const chromeMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.95, roughness: 0.1 });
    const orangeMat = new THREE.MeshStandardMaterial({ color: 0xea580c, metalness: 0.7, roughness: 0.3 });

    // Build model geometry based on activeModel
    let animRefs = {};

    if (activeModel === 'drone') {
      // ===== 2. AERO-X4 QUADROTOR DRONE CAD MODEL =====
      // Fuselage center pod
      const bodyGeom = new THREE.BoxGeometry(1.6, 0.5, 1.8);
      const bodyMesh = new THREE.Mesh(bodyGeom, carbonMat);
      assemblyGroup.add(bodyMesh);

      // Top Dome (LiDAR / GPS)
      const domeGeom = new THREE.SphereGeometry(0.45, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
      const domeMesh = new THREE.Mesh(domeGeom, blueHullMat);
      domeMesh.position.y = 0.25;
      assemblyGroup.add(domeMesh);

      // Underside Gimbal Payload
      const gimbalGeom = new THREE.SphereGeometry(0.35, 16, 16);
      const gimbalMesh = new THREE.Mesh(gimbalGeom, darkMetalMat);
      gimbalMesh.position.y = -0.45;
      assemblyGroup.add(gimbalMesh);

      // 4 Arm Booms (X-Configuration) & Motors
      const booms = [];
      const motors = [];
      const props = [];

      const boomAngles = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];
      boomAngles.forEach((ang, idx) => {
        const boomGroup = new THREE.Group();
        const dist = 3.2;
        const x = Math.cos(ang) * dist;
        const z = Math.sin(ang) * dist;

        // Arm rod
        const rodGeom = new THREE.CylinderGeometry(0.08, 0.08, dist, 16);
        rodGeom.rotateZ(Math.PI / 2);
        rodGeom.rotateY(ang);
        const rodMesh = new THREE.Mesh(rodGeom, carbonMat);
        rodMesh.position.set(x * 0.5, 0, z * 0.5);
        boomGroup.add(rodMesh);

        // Motor pod
        const motorGeom = new THREE.CylinderGeometry(0.3, 0.3, 0.4, 24);
        const motorMesh = new THREE.Mesh(motorGeom, orangeMat);
        motorMesh.position.set(x, 0.15, z);
        boomGroup.add(motorMesh);
        motors.push(motorMesh);

        // Propeller
        const propGeom = new THREE.BoxGeometry(2.0, 0.03, 0.18);
        const propMesh = new THREE.Mesh(propGeom, chromeMat);
        propMesh.position.set(x, 0.4, z);
        assemblyGroup.add(propMesh);
        props.push(propMesh);

        assemblyGroup.add(boomGroup);
        booms.push({ group: boomGroup, baseAngle: ang, dist });
      });

      animRefs = {
        modelType: 'drone',
        bodyMesh,
        domeMesh,
        gimbalMesh,
        booms,
        motors,
        props,
        materials: { primary: blueHullMat, secondary: orangeMat, carbon: carbonMat }
      };

    } else if (activeModel === 'robot_arm') {
      // ===== 3. COBOT-R6 ROBOTIC ARM JOINT CAD MODEL =====
      // Heavy Base Pedestal
      const baseGeom = new THREE.CylinderGeometry(2.0, 2.2, 0.8, 32);
      const baseMesh = new THREE.Mesh(baseGeom, darkMetalMat);
      baseMesh.position.y = -1.8;
      assemblyGroup.add(baseMesh);

      // Rotating Turntable Ring
      const ringGeom = new THREE.CylinderGeometry(1.7, 1.7, 0.5, 32);
      const ringMesh = new THREE.Mesh(ringGeom, blueHullMat);
      ringMesh.position.y = -1.15;
      assemblyGroup.add(ringMesh);

      // Harmonic Drive Actuator Housing
      const harmGeom = new THREE.CylinderGeometry(1.2, 1.2, 1.5, 32);
      harmGeom.rotateX(Math.PI / 2);
      const harmMesh = new THREE.Mesh(harmGeom, chromeMat);
      harmMesh.position.y = -0.1;
      assemblyGroup.add(harmMesh);

      // Articulated Arm Boom (Boom Link)
      const boomGeom = new THREE.BoxGeometry(0.9, 2.4, 0.9);
      const boomMesh = new THREE.Mesh(boomGeom, orangeMat);
      boomMesh.position.set(0, 1.4, 0.4);
      boomMesh.rotation.x = -0.3;
      assemblyGroup.add(boomMesh);

      // Parallel Gripper End Effector
      const gripperBaseGeom = new THREE.BoxGeometry(1.0, 0.4, 0.6);
      const gripperBase = new THREE.Mesh(gripperBaseGeom, darkMetalMat);
      gripperBase.position.set(0, 2.5, 1.0);
      assemblyGroup.add(gripperBase);

      const finger1Geom = new THREE.BoxGeometry(0.12, 0.6, 0.15);
      const finger1 = new THREE.Mesh(finger1Geom, chromeMat);
      finger1.position.set(-0.35, 2.9, 1.0);
      assemblyGroup.add(finger1);

      const finger2 = new THREE.Mesh(finger1Geom, chromeMat);
      finger2.position.set(0.35, 2.9, 1.0);
      assemblyGroup.add(finger2);

      animRefs = {
        modelType: 'robot_arm',
        baseMesh,
        ringMesh,
        harmMesh,
        boomMesh,
        gripperBase,
        finger1,
        finger2,
        materials: { primary: blueHullMat, secondary: orangeMat, gear: chromeMat }
      };

    } else if (activeModel === 'turbine') {
      // ===== 4. TURBINE-900 AERO BLISK ASSEMBLY CAD MODEL =====
      // Central Forged Hub Disk
      const hubGeom = new THREE.CylinderGeometry(1.6, 1.6, 0.8, 40);
      hubGeom.rotateX(Math.PI / 2);
      const hubMesh = new THREE.Mesh(hubGeom, darkMetalMat);
      assemblyGroup.add(hubMesh);

      // Center Nose Spinner Cone
      const coneGeom = new THREE.ConeGeometry(0.8, 1.8, 32);
      coneGeom.rotateX(-Math.PI / 2);
      const coneMesh = new THREE.Mesh(coneGeom, chromeMat);
      coneMesh.position.z = 1.3;
      assemblyGroup.add(coneMesh);

      // Drive Shaft
      const shaftGeom = new THREE.CylinderGeometry(0.4, 0.4, 5.0, 32);
      shaftGeom.rotateX(Math.PI / 2);
      const shaftMesh = new THREE.Mesh(shaftGeom, metalMat);
      shaftMesh.position.z = -1.2;
      assemblyGroup.add(shaftMesh);

      // 24 Curved Aerofoil Turbine Blades (Blisk)
      const bladesGroup = new THREE.Group();
      for (let i = 0; i < 24; i++) {
        const theta = (i / 24) * Math.PI * 2;
        const bladeGeom = new THREE.BoxGeometry(0.15, 1.4, 0.45);
        const bladeMesh = new THREE.Mesh(bladeGeom, blueHullMat);
        bladeMesh.position.set(Math.cos(theta) * 2.2, Math.sin(theta) * 2.2, 0);
        bladeMesh.rotation.z = theta;
        bladeMesh.rotation.y = 0.45; // aerodynamic twist pitch
        bladesGroup.add(bladeMesh);
      }
      assemblyGroup.add(bladesGroup);

      // Outer Flow-Path Nacelle Shroud
      const nacelleGeom = new THREE.CylinderGeometry(3.2, 3.2, 1.6, 48, 1, true);
      nacelleGeom.rotateX(Math.PI / 2);
      const nacelleMesh = new THREE.Mesh(nacelleGeom, blueHullMat);
      assemblyGroup.add(nacelleMesh);

      animRefs = {
        modelType: 'turbine',
        hubMesh,
        coneMesh,
        shaftMesh,
        bladesGroup,
        nacelleMesh,
        materials: { primary: blueHullMat, secondary: chromeMat }
      };

    } else {
      // ===== 1. EDU-250 MOTOR ASSEMBLY (DEFAULT) =====
      // Shaft
      const shaftGeom = new THREE.CylinderGeometry(0.35, 0.35, 7.0, 32);
      shaftGeom.rotateX(Math.PI / 2);
      const shaftMesh = new THREE.Mesh(shaftGeom, metalMat);
      assemblyGroup.add(shaftMesh);

      // Rotor Core
      const rotorCoreGeom = new THREE.CylinderGeometry(1.2, 1.2, 2.8, 32);
      rotorCoreGeom.rotateX(Math.PI / 2);
      const rotorCoreMesh = new THREE.Mesh(rotorCoreGeom, darkMetalMat);
      assemblyGroup.add(rotorCoreMesh);

      // Copper Stator Windings
      const windingGroup = new THREE.Group();
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2;
        const ringGeom = new THREE.TorusGeometry(1.4, 0.08, 16, 32);
        const ringMesh = new THREE.Mesh(ringGeom, copperMat);
        ringMesh.position.set(Math.cos(angle) * 0.1, Math.sin(angle) * 0.1, (i - 6) * 0.22);
        windingGroup.add(ringMesh);
      }
      assemblyGroup.add(windingGroup);

      // Outer Casing with Fins
      const casingGroup = new THREE.Group();
      const casingGeom = new THREE.CylinderGeometry(1.85, 1.85, 3.2, 32, 1, true);
      casingGeom.rotateX(Math.PI / 2);
      const casingMesh = new THREE.Mesh(casingGeom, blueHullMat);
      casingGroup.add(casingMesh);

      for (let f = -1.2; f <= 1.2; f += 0.4) {
        const finGeom = new THREE.TorusGeometry(1.95, 0.05, 16, 40);
        const finMesh = new THREE.Mesh(finGeom, blueHullMat);
        finMesh.position.z = f;
        casingGroup.add(finMesh);
      }
      assemblyGroup.add(casingGroup);

      // Flanges
      const frontFlangeGeom = new THREE.CylinderGeometry(1.9, 1.9, 0.35, 32);
      frontFlangeGeom.rotateX(Math.PI / 2);
      const frontFlangeMesh = new THREE.Mesh(frontFlangeGeom, blueHullMat);
      frontFlangeMesh.position.z = 1.8;
      assemblyGroup.add(frontFlangeMesh);

      const rearFlangeMesh = new THREE.Mesh(frontFlangeGeom, blueHullMat);
      rearFlangeMesh.position.z = -1.8;
      assemblyGroup.add(rearFlangeMesh);

      // Bearings
      const bearingGeom = new THREE.TorusGeometry(0.65, 0.22, 16, 32);
      const bearingDEMesh = new THREE.Mesh(bearingGeom, chromeMat);
      bearingDEMesh.position.z = 2.4;
      assemblyGroup.add(bearingDEMesh);

      const bearingNDEMesh = new THREE.Mesh(bearingGeom, chromeMat);
      bearingNDEMesh.position.z = -2.4;
      assemblyGroup.add(bearingNDEMesh);

      animRefs = {
        modelType: 'motor',
        shaft: shaftMesh,
        rotorCore: rotorCoreMesh,
        windingGroup,
        casingGroup,
        frontFlange: frontFlangeMesh,
        rearFlange: rearFlangeMesh,
        bearingDE: bearingDEMesh,
        bearingNDE: bearingNDEMesh,
        materials: { primary: blueHullMat, secondary: copperMat, bearing: chromeMat }
      };
    }

    partsRef.current = { assemblyGroup, ...animRefs };
    camera.lookAt(0, 0, 0);

    // --- Interactive Mouse & Touch Orbit Controls ---
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      assemblyGroup.rotation.y += deltaX * 0.01;
      assemblyGroup.rotation.x += deltaY * 0.01;
    };

    const onMouseUp = () => { isDragging = false; };

    const onWheel = (e) => {
      e.preventDefault();
      const zoomSpeed = 0.003;
      camera.position.z = Math.max(3.5, Math.min(22, camera.position.z + e.deltaY * zoomSpeed));
    };

    const onTouchStart = (e) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    };

    const onTouchMove = (e) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - prevMouseX;
      const deltaY = e.touches[0].clientY - prevMouseY;
      prevMouseX = e.touches[0].clientX;
      prevMouseY = e.touches[0].clientY;

      assemblyGroup.rotation.y += deltaX * 0.012;
      assemblyGroup.rotation.x += deltaY * 0.012;
    };

    const onTouchEnd = () => { isDragging = false; };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });
    dom.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onTouchEnd);

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Render loop
    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);

      if (isRotating && !isDragging) {
        assemblyGroup.rotation.y += 0.005;
      }

      // Dynamic rotations for active models
      if (animRefs.modelType === 'drone' && animRefs.props) {
        const spin = ((telemetry?.rpm || 8000) / 60000) * 0.8;
        animRefs.props.forEach((prop, i) => {
          prop.rotation.y += (i % 2 === 0 ? 1 : -1) * (spin + 0.15);
        });
      } else if (animRefs.modelType === 'turbine' && animRefs.bladesGroup) {
        const spin = ((telemetry?.rpm || 12000) / 60000) * 0.3;
        animRefs.bladesGroup.rotation.z += spin;
        if (animRefs.coneMesh) animRefs.coneMesh.rotation.z += spin;
      } else if (animRefs.modelType === 'motor' && animRefs.shaft) {
        const spinSpeed = ((telemetry?.rpm || 10000) / 60000) * 0.1;
        animRefs.shaft.rotation.z += spinSpeed;
        if (animRefs.rotorCore) animRefs.rotorCore.rotation.z += spinSpeed;
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(reqIdRef.current);
      window.removeEventListener('resize', handleResize);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      dom.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      renderer.dispose();
    };
  }, [activeModel, isRotating]);

  // Exploded View Update
  useEffect(() => {
    const p = partsRef.current;
    if (!p) return;
    const f = explodeFactor;

    if (p.modelType === 'motor') {
      if (p.frontFlange) p.frontFlange.position.z = 1.8 + f * 2.2;
      if (p.bearingDE) p.bearingDE.position.z = 2.4 + f * 3.4;
      if (p.rearFlange) p.rearFlange.position.z = -1.8 - f * 2.2;
      if (p.bearingNDE) p.bearingNDE.position.z = -2.4 - f * 3.4;
      if (p.casingGroup) p.casingGroup.position.y = f * 1.8;
    } else if (p.modelType === 'drone') {
      if (p.domeMesh) p.domeMesh.position.y = 0.25 + f * 2.0;
      if (p.gimbalMesh) p.gimbalMesh.position.y = -0.45 - f * 1.8;
      if (p.booms) {
        p.booms.forEach(b => {
          b.group.position.x = Math.cos(b.baseAngle) * (f * 1.5);
          b.group.position.z = Math.sin(b.baseAngle) * (f * 1.5);
        });
      }
    } else if (p.modelType === 'robot_arm') {
      if (p.gripperBase) p.gripperBase.position.y = 2.5 + f * 2.0;
      if (p.finger1) p.finger1.position.y = 2.9 + f * 2.0;
      if (p.finger2) p.finger2.position.y = 2.9 + f * 2.0;
      if (p.harmMesh) p.harmMesh.position.y = -0.1 + f * 1.2;
      if (p.ringMesh) p.ringMesh.position.y = -1.15 + f * 0.6;
    } else if (p.modelType === 'turbine') {
      if (p.coneMesh) p.coneMesh.position.z = 1.3 + f * 2.5;
      if (p.nacelleMesh) p.nacelleMesh.position.y = f * 1.8;
      if (p.shaftMesh) p.shaftMesh.position.z = -1.2 - f * 2.0;
    }
  }, [explodeFactor]);

  // Thermal Shader / Wireframe Mode
  useEffect(() => {
    const p = partsRef.current;
    if (!p?.materials?.primary) return;

    const primaryMat = p.materials.primary;

    if (thermalView) {
      const temp = telemetry?.temperature || 75;
      const heatFactor = Math.min(1.0, Math.max(0.0, (temp - 55) / 40));
      const thermalColor = new THREE.Color().setHSL(0.66 * (1.0 - heatFactor), 1.0, 0.55);

      primaryMat.color.copy(thermalColor);
      primaryMat.wireframe = false;
      primaryMat.opacity = 0.88;
    } else if (wireframeView) {
      primaryMat.wireframe = true;
      primaryMat.opacity = 0.5;
      primaryMat.color.setHex(0x38bdf8);
    } else {
      primaryMat.wireframe = false;
      primaryMat.opacity = 0.92;
      primaryMat.color.setHex(0x0284c7);
    }
  }, [thermalView, wireframeView, telemetry?.temperature]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-[#040814] shadow-xl group">
      {/* 3D Canvas Mount */}
      <div ref={mountRef} style={{ height }} className="w-full cursor-grab active:cursor-grabbing" />

      {/* Top Left: CAD Model Switcher & Metadata Badge */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        {/* Model Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <select
              value={activeModel}
              onChange={(e) => handleModelSelect(e.target.value)}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-900/90 text-teal-300 border border-teal-500/40 shadow-lg backdrop-blur-md outline-none cursor-pointer hover:border-teal-400"
            >
              {CAD_MODELS.map(m => (
                <option key={m.id} value={m.id}>
                  📦 {m.name} ({m.partNumber})
                </option>
              ))}
            </select>
          </div>

          <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[11px] font-mono bg-slate-800/80 text-slate-300 border border-slate-700/80 backdrop-blur-md">
            {currentModelMeta.rev}
          </span>
        </div>

        <p className="text-[11px] text-slate-400 font-sans backdrop-blur-sm max-w-sm hidden sm:block">
          {currentModelMeta.desc}
        </p>
      </div>

      {/* Top Right: Sensor Hotspot Pins */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        {currentModelMeta.sensors.map((sensor) => {
          const isSelected = activePin === sensor.id;
          return (
            <button
              key={sensor.id}
              onClick={() => setActivePin(isSelected ? null : sensor.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border backdrop-blur-md transition ${
                isSelected
                  ? 'bg-teal-500/20 border-teal-500/60 text-teal-300 ring-2 ring-teal-500/20'
                  : 'bg-slate-900/80 border-slate-700/80 text-slate-200 hover:border-teal-500'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
              <span className="truncate max-w-[140px] sm:max-w-none">{sensor.label}</span>
            </button>
          );
        })}
      </div>

      {/* Sensor Pin Info Modal Card */}
      {activePin && (
        <div className="absolute bottom-20 left-4 max-w-sm p-4 rounded-xl bg-slate-900/95 border border-teal-500/50 backdrop-blur-lg shadow-2xl z-20 text-xs animate-in fade-in">
          <div className="flex justify-between items-start mb-2">
            <span className="font-bold text-white text-sm">
              {currentModelMeta.sensors.find(s => s.id === activePin)?.label}
            </span>
            <button onClick={() => setActivePin(null)} className="text-slate-400 hover:text-white p-0.5">✕</button>
          </div>
          <p className="text-slate-300 leading-relaxed text-xs">
            {currentModelMeta.sensors.find(s => s.id === activePin)?.spec}. Linked directly to Windchill Digital Thread telemetry bus.
          </p>
          <div className="mt-3 pt-2 border-t border-slate-800 flex justify-between text-[11px] text-teal-400 font-mono">
            <span>Part: {currentModelMeta.sensors.find(s => s.id === activePin)?.partId}</span>
            <span>Lifecycle: {currentModelMeta.sensors.find(s => s.id === activePin)?.state}</span>
          </div>
        </div>
      )}

      {/* Bottom Control Toolbar */}
      <div className="absolute bottom-3 inset-x-3 px-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-800 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 z-10">
        {/* Exploded View Slider */}
        <div className="flex items-center gap-2.5 min-w-[200px]">
          <Layers className="w-4 h-4 text-teal-400" />
          <span className="text-xs font-semibold text-slate-300">Exploded View</span>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={explodeFactor}
            onChange={(e) => setExplodeFactor(parseFloat(e.target.value))}
            className="w-24 sm:w-36 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-400"
          />
          <span className="text-[11px] font-mono text-teal-400 min-w-[32px]">
            {Math.round(explodeFactor * 100)}%
          </span>
        </div>

        {/* View Mode Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setThermalView(!thermalView);
              if (!thermalView) setWireframeView(false);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
              thermalView 
                ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
            }`}
            title="Toggle Thermal Heatmap Shader"
          >
            <Thermometer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Thermal</span>
          </button>

          <button
            onClick={() => {
              setWireframeView(!wireframeView);
              if (!wireframeView) setThermalView(false);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
              wireframeView 
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
            }`}
            title="Toggle X-Ray / Wireframe"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">X-Ray</span>
          </button>

          <button
            onClick={() => setIsRotating(!isRotating)}
            className={`p-1.5 rounded-lg text-xs transition border ${
              isRotating ? 'text-teal-400 bg-teal-500/10 border-teal-500/30' : 'text-slate-400 hover:bg-slate-800 border-transparent'
            }`}
            title="Toggle Auto Rotation"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
