import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const LOGO_OPTIONS = [
  { id: 'turbine', name: 'Industrial Turbine', desc: 'Aerodynamic rotor blade gradient' },
  { id: 'quantum', name: 'Quantum Cyber-Physical', desc: 'Dual-ring orbital digital thread' },
  { id: 'monogram', name: 'CIT-PLM Monogram', desc: 'Modern geometric faceted badge' },
  { id: 'circuit', name: 'Neural Digital Thread', desc: 'Silicon circuit vertex node' },
  { id: 'shield', name: 'Windchill Shield', desc: 'Enterprise CAD engineering emblem' },
  { id: 'custom', name: 'Custom Uploaded Logo', desc: 'Use your own university or corporate emblem' }
];

export default function BrandLogo({ size = 'md', className = '', showText = false, overrideStyle = null }) {
  const { logoStyle: currentStyle, customLogoUrl } = useTheme();
  const activeStyle = overrideStyle || currentStyle || 'turbine';

  const sizeMap = {
    sm: { box: 'w-7 h-7', icon: 20 },
    md: { box: 'w-9 h-9', icon: 26 },
    lg: { box: 'w-12 h-12', icon: 34 },
    xl: { box: 'w-16 h-16', icon: 48 }
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  const renderIcon = () => {
    if (activeStyle === 'custom' && customLogoUrl) {
      return (
        <img
          src={customLogoUrl}
          alt="Custom Logo"
          className="w-full h-full object-contain rounded-lg"
        />
      );
    }

    switch (activeStyle) {
      case 'quantum':
        return (
          <svg className="w-full h-full p-1" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="20" cy="20" rx="16" ry="7" stroke="url(#quantumGrad1)" strokeWidth="2.5" strokeDasharray="3 2" transform="rotate(-30 20 20)" />
            <ellipse cx="20" cy="20" rx="16" ry="7" stroke="url(#quantumGrad2)" strokeWidth="2.5" transform="rotate(45 20 20)" />
            <circle cx="20" cy="20" r="5" fill="url(#coreGrad)" />
            <circle cx="20" cy="20" r="2.5" fill="#ffffff" />
            <defs>
              <linearGradient id="quantumGrad1" x1="4" y1="13" x2="36" y2="27" gradientUnits="userSpaceOnUse">
                <stop stopColor="#06b6d4" />
                <stop offset="1" stopColor="#14b8a6" />
              </linearGradient>
              <linearGradient id="quantumGrad2" x1="4" y1="13" x2="36" y2="27" gradientUnits="userSpaceOnUse">
                <stop stopColor="#f97316" />
                <stop offset="1" stopColor="#ec4899" />
              </linearGradient>
              <linearGradient id="coreGrad" x1="15" y1="15" x2="25" y2="25" gradientUnits="userSpaceOnUse">
                <stop stopColor="#14b8a6" />
                <stop offset="1" stopColor="#0284c7" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'monogram':
        return (
          <svg className="w-full h-full p-1.5" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <polygon points="20,2 36,11 36,29 20,38 4,29 4,11" stroke="url(#monoStroke)" strokeWidth="2.5" fill="url(#monoFill)" fillOpacity="0.3" />
            <text x="20" y="25" textAnchor="middle" fill="#ffffff" fontSize="13" fontWeight="900" fontFamily="sans-serif" letterSpacing="0.5">CIT</text>
            <defs>
              <linearGradient id="monoStroke" x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
                <stop stopColor="#14b8a6" />
                <stop offset="0.5" stopColor="#06b6d4" />
                <stop offset="1" stopColor="#f59e0b" />
              </linearGradient>
              <linearGradient id="monoFill" x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0f766e" />
                <stop offset="1" stopColor="#1e293b" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'circuit':
        return (
          <svg className="w-full h-full p-1" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="6" y="6" width="28" height="28" rx="6" stroke="url(#circGrad)" strokeWidth="2" fill="#030712" />
            <circle cx="20" cy="20" r="4.5" fill="#14b8a6" />
            <path d="M20 6V15.5 M20 24.5V34 M6 20H15.5 M24.5 20H34" stroke="url(#circGrad)" strokeWidth="2" strokeLinecap="round" />
            <circle cx="9" cy="9" r="1.8" fill="#06b6d4" />
            <circle cx="31" cy="9" r="1.8" fill="#f97316" />
            <circle cx="9" cy="31" r="1.8" fill="#f59e0b" />
            <circle cx="31" cy="31" r="1.8" fill="#10b981" />
            <defs>
              <linearGradient id="circGrad" x1="6" y1="6" x2="34" y2="34" gradientUnits="userSpaceOnUse">
                <stop stopColor="#06b6d4" />
                <stop offset="1" stopColor="#14b8a6" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'shield':
        return (
          <svg className="w-full h-full p-1" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 4L34 9V20C34 28.5 28 34.5 20 37C12 34.5 6 28.5 6 20V9L20 4Z" stroke="url(#shieldGrad)" strokeWidth="2.5" fill="url(#shieldBg)" />
            <path d="M14 18L19 23L27 15" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            <defs>
              <linearGradient id="shieldGrad" x1="6" y1="4" x2="34" y2="37" gradientUnits="userSpaceOnUse">
                <stop stopColor="#10b981" />
                <stop offset="1" stopColor="#06b6d4" />
              </linearGradient>
              <linearGradient id="shieldBg" x1="6" y1="4" x2="34" y2="37" gradientUnits="userSpaceOnUse">
                <stop stopColor="#064e3b" stopOpacity="0.6" />
                <stop offset="1" stopColor="#022c22" stopOpacity="0.8" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'turbine':
      default:
        return (
          <svg className="w-full h-full p-1" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="20" cy="20" r="16.5" stroke="url(#turbineBorder)" strokeWidth="2" strokeDasharray="4 2" />
            {/* Turbine blades */}
            <path d="M20 20C19 12 25 7 28 6C26 11 25 16 20 20Z" fill="url(#blade1)" />
            <path d="M20 20C28 19 33 25 34 28C29 26 24 25 20 20Z" fill="url(#blade2)" />
            <path d="M20 20C21 28 15 33 12 34C14 29 15 24 20 20Z" fill="url(#blade3)" />
            <path d="M20 20C12 21 7 15 6 12C11 14 16 15 20 20Z" fill="url(#blade4)" />
            {/* Center spinner */}
            <circle cx="20" cy="20" r="4.5" fill="url(#hubGrad)" />
            <circle cx="20" cy="20" r="2" fill="#ffffff" />
            <defs>
              <linearGradient id="turbineBorder" x1="3.5" y1="3.5" x2="36.5" y2="36.5" gradientUnits="userSpaceOnUse">
                <stop stopColor="#14b8a6" />
                <stop offset="1" stopColor="#06b6d4" />
              </linearGradient>
              <linearGradient id="blade1" x1="20" y1="6" x2="28" y2="20" gradientUnits="userSpaceOnUse">
                <stop stopColor="#14b8a6" />
                <stop offset="1" stopColor="#0d9488" />
              </linearGradient>
              <linearGradient id="blade2" x1="20" y1="19" x2="34" y2="28" gradientUnits="userSpaceOnUse">
                <stop stopColor="#06b6d4" />
                <stop offset="1" stopColor="#0891b2" />
              </linearGradient>
              <linearGradient id="blade3" x1="20" y1="20" x2="12" y2="34" gradientUnits="userSpaceOnUse">
                <stop stopColor="#f97316" />
                <stop offset="1" stopColor="#ea580c" />
              </linearGradient>
              <linearGradient id="blade4" x1="20" y1="12" x2="6" y2="20" gradientUnits="userSpaceOnUse">
                <stop stopColor="#f59e0b" />
                <stop offset="1" stopColor="#d97706" />
              </linearGradient>
              <linearGradient id="hubGrad" x1="16" y1="16" x2="24" y2="24" gradientUnits="userSpaceOnUse">
                <stop stopColor="#38bdf8" />
                <stop offset="1" stopColor="#0284c7" />
              </linearGradient>
            </defs>
          </svg>
        );
    }
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className={`${currentSize.box} rounded-xl bg-slate-950 p-0.5 border border-slate-700/60 shadow-md shadow-teal-500/10 flex items-center justify-center shrink-0 overflow-hidden`}>
        {renderIcon()}
      </div>

      {showText && (
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">CIT PLM</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-semibold bg-teal-500/15 text-teal-600 dark:text-teal-400 border border-teal-500/20">
              Digital Twin
            </span>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-none mt-0.5">
            PTC Windchill Enterprise
          </p>
        </div>
      )}
    </div>
  );
}
