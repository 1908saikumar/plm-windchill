import React from 'react';

export default function StatusBadge({ status, size = 'sm' }) {
  const norm = (status || '').toUpperCase().replace(/[\s_-]+/g, '');

  let style = 'bg-slate-500/10 text-slate-400 border-slate-500/20';

  if (norm.includes('RELEASED') || norm.includes('APPROVED') || norm.includes('COMPLETED') || norm.includes('CLOSED')) {
    style = 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
  } else if (norm.includes('INWORK') || norm.includes('DRAFT') || norm.includes('PROGRESS')) {
    style = 'bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border-cyan-500/30';
  } else if (norm.includes('REVIEW') || norm.includes('SUBMITTED') || norm.includes('PENDING')) {
    style = 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30';
  } else if (norm.includes('CRITICAL') || norm.includes('HIGH') || norm.includes('OBSOLETE') || norm.includes('REJECTED')) {
    style = 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30';
  } else if (norm.includes('DEMO')) {
    style = 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30';
  }

  const sizeClasses = size === 'xs' 
    ? 'text-[10px] px-1.5 py-0.5' 
    : size === 'md' 
    ? 'text-xs px-2.5 py-1' 
    : 'text-[11px] px-2 py-0.5';

  return (
    <span className={`inline-flex items-center font-medium rounded-full border ${sizeClasses} ${style}`}>
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-70"></span>
      {status || 'Unknown'}
    </span>
  );
}
