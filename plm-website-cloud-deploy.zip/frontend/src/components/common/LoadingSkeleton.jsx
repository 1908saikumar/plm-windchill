import React from 'react';

export default function LoadingSkeleton({ rows = 4, type = 'card' }) {
  if (type === 'table') {
    return (
      <div className="w-full space-y-3 animate-pulse">
        <div className="h-10 bg-slate-200 dark:bg-slate-800/60 rounded-lg"></div>
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="h-12 bg-slate-100 dark:bg-slate-850/40 rounded-lg"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-pulse">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-44 bg-slate-200/70 dark:bg-slate-850/60 border border-slate-300/40 dark:border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex justify-between">
            <div className="h-5 w-32 bg-slate-300 dark:bg-slate-700/60 rounded"></div>
            <div className="h-5 w-16 bg-slate-300 dark:bg-slate-700/60 rounded-full"></div>
          </div>
          <div className="h-4 w-48 bg-slate-300/60 dark:bg-slate-800 rounded"></div>
          <div className="h-12 w-full bg-slate-300/40 dark:bg-slate-800/40 rounded"></div>
        </div>
      ))}
    </div>
  );
}
