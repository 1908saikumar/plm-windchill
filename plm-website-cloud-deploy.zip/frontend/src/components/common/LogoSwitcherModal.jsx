import React, { useState, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';
import BrandLogo, { LOGO_OPTIONS } from './BrandLogo';
import Modal from './Modal';
import { Check, Upload, Image, Sparkles, Trash2 } from 'lucide-react';

export default function LogoSwitcherModal({ isOpen, onClose }) {
  const { logoStyle, setLogoStyle, customLogoUrl, setCustomLogoUrl } = useTheme();
  const [previewCustom, setPreviewCustom] = useState(customLogoUrl || '');
  const fileInputRef = useRef(null);

  const handleSelectStyle = (id) => {
    setLogoStyle(id);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (PNG, JPG, SVG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target.result;
      setPreviewCustom(dataUrl);
      setCustomLogoUrl(dataUrl);
      setLogoStyle('custom');
    };
    reader.readAsDataURL(file);
  };

  const handleClearCustom = () => {
    setPreviewCustom('');
    setCustomLogoUrl('');
    if (logoStyle === 'custom') {
      setLogoStyle('turbine');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Customize Website Brand Logo"
      subtitle="Select an engineering emblem or upload your institution's custom branding"
      maxWidth="max-w-xl"
    >
      <div className="space-y-5 text-xs">
        {/* Current Active Preview */}
        <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo size="lg" />
            <div>
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                Active Logo Style
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white capitalize">
                {LOGO_OPTIONS.find(o => o.id === logoStyle)?.name || 'Custom'}
              </h4>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-semibold bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
            Current
          </span>
        </div>

        {/* Preset Options Grid */}
        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Select Logo Option
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {LOGO_OPTIONS.filter(o => o.id !== 'custom').map((opt) => {
              const isSelected = logoStyle === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleSelectStyle(opt.id)}
                  className={`p-3 rounded-xl border text-left flex items-center gap-3 transition ${
                    isSelected
                      ? 'bg-teal-500/10 border-teal-500/50 ring-2 ring-teal-500/20 shadow-sm'
                      : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <BrandLogo size="md" overrideStyle={opt.id} />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                      <span className="truncate">{opt.name}</span>
                      {isSelected && <Check className="w-4 h-4 text-teal-500 shrink-0" />}
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {opt.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Logo Upload Section */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h5 className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Image className="w-4 h-4 text-teal-500" />
                <span>Upload Custom Original Logo</span>
              </h5>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Upload your college, department, or company emblem (PNG, JPG, SVG).
              </p>
            </div>
            {previewCustom && (
              <button
                type="button"
                onClick={handleClearCustom}
                className="text-xs text-rose-500 hover:text-rose-600 flex items-center gap-1"
                title="Remove custom logo"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition"
            >
              <Upload className="w-4 h-4 text-teal-500" />
              <span>Browse Image File</span>
            </button>

            {previewCustom && (
              <button
                type="button"
                onClick={() => setLogoStyle('custom')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  logoStyle === 'custom'
                    ? 'bg-teal-500 text-white'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-white'
                }`}
              >
                {logoStyle === 'custom' ? '✓ Currently Applied' : 'Apply Uploaded Logo'}
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-semibold text-xs shadow-md shadow-teal-500/20 transition"
          >
            Done
          </button>
        </div>
      </div>
    </Modal>
  );
}
