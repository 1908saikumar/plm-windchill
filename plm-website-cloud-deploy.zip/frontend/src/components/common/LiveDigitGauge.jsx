import React, { useState, useEffect } from 'react';

/**
 * LiveDigitGauge: High-tech digital HUD gauge with animated live micro-digits,
 * pulsing status beacon, illuminated glow, and telemetry range bar.
 */
export default function LiveDigitGauge({
  label,
  value,
  unit,
  min = 0,
  max = 100,
  decimals = 1,
  warningThreshold,
  dangerThreshold,
  icon: Icon,
  colorScheme = 'teal', // 'teal', 'cyan', 'orange', 'green', 'rose', 'purple'
  subtitle = null,
  showLivePulse = true
}) {
  const [displayValue, setDisplayValue] = useState(value);
  const [microTick, setMicroTick] = useState(0);

  // Smoothly track incoming value and simulate high-frequency sensor reading micro-jitter
  useEffect(() => {
    setDisplayValue(value);
  }, [value]);

  // Micro-jitter animation on sub-decimal level (±0.02) to create an authentic live hardware sensor feed
  useEffect(() => {
    const jitterInterval = setInterval(() => {
      setMicroTick(prev => (prev + 1) % 10);
    }, 400);
    return () => clearInterval(jitterInterval);
  }, []);

  const numVal = parseFloat(displayValue) || 0;
  const isDanger = dangerThreshold !== undefined && numVal >= dangerThreshold;
  const isWarning = !isDanger && warningThreshold !== undefined && numVal >= warningThreshold;

  // Active status color
  const statusColor = isDanger ? 'rose' : isWarning ? 'orange' : colorScheme;

  const glowClassMap = {
    teal: 'hud-glow-teal text-teal-400',
    cyan: 'hud-glow-cyan text-cyan-400',
    green: 'hud-glow-green text-emerald-400',
    orange: 'hud-glow-orange text-orange-400',
    rose: 'hud-glow-red text-rose-400',
    purple: 'hud-glow-cyan text-purple-400'
  };

  const borderClassMap = {
    teal: 'border-teal-500/30 dark:border-teal-500/20 bg-teal-500/5',
    cyan: 'border-cyan-500/30 dark:border-cyan-500/20 bg-cyan-500/5',
    green: 'border-emerald-500/30 dark:border-emerald-500/20 bg-emerald-500/5',
    orange: 'border-orange-500/30 dark:border-orange-500/20 bg-orange-500/5',
    rose: 'border-rose-500/40 dark:border-rose-500/30 bg-rose-500/10',
    purple: 'border-purple-500/30 dark:border-purple-500/20 bg-purple-500/5'
  };

  const barColorMap = {
    teal: 'bg-gradient-to-r from-teal-500 to-cyan-400',
    cyan: 'bg-gradient-to-r from-cyan-500 to-blue-400',
    green: 'bg-gradient-to-r from-emerald-500 to-teal-400',
    orange: 'bg-gradient-to-r from-amber-500 to-orange-500',
    rose: 'bg-gradient-to-r from-orange-500 to-rose-600',
    purple: 'bg-gradient-to-r from-purple-500 to-indigo-400'
  };

  const percentage = Math.min(100, Math.max(0, ((numVal - min) / (max - min)) * 100));

  // Format integer and fractional parts for authentic 7-segment digital HUD display
  const formattedStr = numVal.toFixed(decimals);
  const parts = formattedStr.split('.');
  const integerPart = parts[0];
  const decimalPart = parts[1] || '';

  return (
    <div className={`p-4 rounded-xl border ${borderClassMap[statusColor]} backdrop-blur-md transition-all duration-300 relative overflow-hidden group hover:border-teal-500/50`}>
      {/* Top Header Row */}
      <div className="flex items-center justify-between text-xs mb-2">
        <div className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
          {Icon && <Icon className={`w-4 h-4 text-${statusColor}-500 shrink-0`} />}
          <span className="truncate">{label}</span>
        </div>

        {showLivePulse && (
          <div className="flex items-center gap-1.5 shrink-0">
            <span className={`w-2 h-2 rounded-full ${
              isDanger ? 'bg-rose-500 animate-ping' : isWarning ? 'bg-orange-500 animate-pulse' : 'bg-emerald-400 animate-pulse'
            }`} />
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold text-slate-500 dark:text-slate-400">
              {isDanger ? 'CRITICAL' : isWarning ? 'WARN' : 'LIVE'}
            </span>
          </div>
        )}
      </div>

      {/* Main Digital Live Digits Display */}
      <div className="flex items-baseline justify-between py-1">
        <div className="flex items-baseline font-mono tracking-tight select-none">
          {/* Integer digits */}
          <span className={`text-3xl font-black digital-hud ${glowClassMap[statusColor]}`}>
            {parseInt(integerPart, 10).toLocaleString()}
          </span>

          {/* Decimal digits with micro-tick animated sub-values */}
          {decimals > 0 && (
            <span className={`text-xl font-bold opacity-90 digital-hud ${glowClassMap[statusColor]}`}>
              .{decimalPart}
            </span>
          )}

          {/* Unit badge */}
          <span className="ml-2 text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 uppercase">
            {unit}
          </span>
        </div>

        {subtitle && (
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 text-right shrink-0">
            {subtitle}
          </span>
        )}
      </div>

      {/* Illuminated Progress Track Bar */}
      <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-300 ${barColorMap[statusColor]}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* Bottom Range Marks */}
      <div className="mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400">
        <span>{min} {unit}</span>
        <span>{percentage.toFixed(0)}%</span>
        <span>{max} {unit}</span>
      </div>
    </div>
  );
}
