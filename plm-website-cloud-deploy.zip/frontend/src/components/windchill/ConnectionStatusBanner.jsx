import React from 'react';
import { useWindchill } from '../../context/WindchillContext';
import { Server, Wifi, WifiOff, RefreshCw, AlertCircle, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ConnectionStatusBanner() {
  const { status, isTesting, testConnection, toggleDemoMode } = useWindchill();

  const isLive = status.mode === 'live' && status.connected;
  const isDemo = status.isDemo || status.mode === 'demo';

  return (
    <div className={`w-full px-4 py-2.5 rounded-xl border backdrop-blur-md mb-6 flex flex-wrap items-center justify-between gap-3 text-xs transition-all ${
      isLive 
        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
        : isDemo
        ? 'bg-purple-500/10 border-purple-500/30 text-purple-200'
        : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
    }`}>
      {/* Status info */}
      <div className="flex items-center gap-3">
        <div className={`p-1.5 rounded-lg ${
          isLive ? 'bg-emerald-500/20 text-emerald-400' : isDemo ? 'bg-purple-500/20 text-purple-400' : 'bg-rose-500/20 text-rose-400'
        }`}>
          {isLive ? <Wifi className="w-4 h-4" /> : isDemo ? <Server className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900 dark:text-white">
              {isLive ? 'Live Windchill REST Connected' : isDemo ? 'Windchill Demo Mode (Simulated OData)' : 'Windchill Server Offline'}
            </span>
            <span className="font-mono text-[11px] opacity-80">
              plm.cit.com (172.16.31.150)
            </span>
            {status.latencyMs && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-black/20 text-current">
                {status.latencyMs}ms
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-300 mt-0.5">
            {isLive
              ? 'Synchronized with college Windchill server at plm.cit.com/Windchill.'
              : isDemo
              ? 'Using persistent local SQLite engineering repository with realistic WTPart/BOM data.'
              : status.error || 'Server unreachable. Please check hosts file and VPN connection.'}
          </p>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={testConnection}
          disabled={isTesting}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900/60 hover:bg-slate-900/90 text-white border border-white/10 transition disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
          {isTesting ? 'Testing...' : 'Test Connection'}
        </button>

        <button
          onClick={() => toggleDemoMode(!isDemo)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
            isDemo
              ? 'bg-purple-600/30 border-purple-500/50 text-purple-200 hover:bg-purple-600/40'
              : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}
          title="Toggle between Live Windchill and Simulated Demo Mode"
        >
          {isDemo ? 'Demo Mode Active' : 'Switch to Demo'}
        </button>

        <Link
          to="/help"
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-black/20 transition"
          title="View Hosts & Network Configuration Guide"
        >
          <HelpCircle className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
