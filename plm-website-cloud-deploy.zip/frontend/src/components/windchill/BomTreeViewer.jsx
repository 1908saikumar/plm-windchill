import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Box, Cpu, Disc, Zap, Activity } from 'lucide-react';
import StatusBadge from '../common/StatusBadge';

function BomTreeNode({ node, level = 0, onSelectPart, selectedPartId }) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = selectedPartId === node.id;

  const getIcon = (category) => {
    switch (category) {
      case 'Assembly': return <Box className="w-4 h-4 text-teal-400" />;
      case 'Subassembly': return <Disc className="w-4 h-4 text-cyan-400" />;
      case 'Sensor': return <Activity className="w-4 h-4 text-orange-400" />;
      case 'Electronics': return <Zap className="w-4 h-4 text-amber-400" />;
      default: return <Cpu className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="select-none text-xs">
      <div
        onClick={() => onSelectPart && onSelectPart(node)}
        className={`flex items-center justify-between py-2 px-3 rounded-lg cursor-pointer transition border ${
          isSelected
            ? 'bg-teal-500/15 border-teal-500/40 text-teal-300'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 border-transparent text-slate-700 dark:text-slate-300'
        }`}
        style={{ paddingLeft: `${Math.max(12, level * 22)}px` }}
      >
        <div className="flex items-center gap-2 min-w-0">
          {hasChildren ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(!isOpen);
              }}
              className="p-0.5 text-slate-400 hover:text-white"
            >
              {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <span className="w-3.5 h-3.5" />
          )}

          {getIcon(node.category)}

          <div className="truncate">
            <span className="font-mono font-medium text-slate-900 dark:text-slate-100 mr-2">
              {node.number}
            </span>
            <span className="text-slate-500 dark:text-slate-400">
              {node.name}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0 ml-2">
          {node.has_twin === 1 && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              3D Twin
            </span>
          )}
          <span className="font-mono text-slate-500 dark:text-slate-400">
            Rev {node.version}
          </span>
          <StatusBadge status={node.state} size="xs" />
          <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 min-w-[70px] text-right">
            ${(node.totalCost || node.cost).toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {hasChildren && isOpen && (
        <div className="space-y-0.5 mt-0.5 border-l border-slate-200 dark:border-slate-800/60 ml-4">
          {node.children.map((child) => (
            <BomTreeNode
              key={child.id}
              node={child}
              level={level + 1}
              onSelectPart={onSelectPart}
              selectedPartId={selectedPartId}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function BomTreeViewer({ treeData, onSelectPart, selectedPartId }) {
  if (!treeData) {
    return (
      <div className="p-8 text-center text-xs text-slate-500">
        No BOM hierarchy loaded. Select an assembly to view its product structure.
      </div>
    );
  }

  return (
    <div className="w-full bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl p-4 overflow-x-auto shadow-sm">
      <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-200 dark:border-slate-800 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
        <span>Part Structure / Item Tree</span>
        <div className="flex items-center gap-6">
          <span>Digital Twin</span>
          <span>Revision</span>
          <span>Lifecycle</span>
          <span className="min-w-[70px] text-right">Rolled-Up Cost</span>
        </div>
      </div>
      <BomTreeNode
        node={treeData}
        level={0}
        onSelectPart={onSelectPart}
        selectedPartId={selectedPartId}
      />
    </div>
  );
}
