import React, { useState } from 'react';
import Modal from '../common/Modal';
import api from '../../services/api';
import { Layers, CheckCircle2, AlertCircle } from 'lucide-react';

export default function CreateProductModal({ isOpen, onClose, onCreated }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [template, setTemplate] = useState('GEN');
  const [privateAccess, setPrivateAccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter a valid product name');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await api.createProduct({
        name: name.trim(),
        description: description.trim(),
        template: template || 'GEN',
        privateAccess: privateAccess
      });

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setName('');
        setDescription('');
        onCreated && onCreated(res.product);
        onClose();
      }, 1000);
    } catch (err) {
      setError(err.message || 'Failed to create Windchill product');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create New Windchill Product Context"
      subtitle="Standard PTC Windchill Product creation workflow with GEN template"
      maxWidth="max-w-xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 p-3 text-xs rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="flex items-center gap-2 p-3 text-xs rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Product created and registered in Windchill repository!</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Product Name *
          </label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Next-Gen Electric Mobility Powertrain"
            className="w-full px-3.5 py-2 rounded-lg text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Description
          </label>
          <textarea
            rows="3"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Engineering scope, target application, and technical requirements..."
            className="w-full px-3.5 py-2 rounded-lg text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Context Template
            </label>
            <div className="relative">
              <input
                type="text"
                readOnly
                value={template}
                className="w-full px-3.5 py-2 rounded-lg text-sm bg-slate-100 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 cursor-not-allowed font-mono"
              />
              <span className="absolute right-3 top-2.5 text-[10px] font-semibold text-teal-600 dark:text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded">
                Required: GEN
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              Standard General Product Template configured in CIT Windchill
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Private Access
            </label>
            <div className="flex items-center gap-3 h-[42px] px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40">
              <input
                type="checkbox"
                id="privateAccess"
                checked={privateAccess}
                onChange={(e) => setPrivateAccess(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 bg-slate-700 border-slate-600"
              />
              <label htmlFor="privateAccess" className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                {privateAccess ? 'Yes (Restricted)' : 'No (Shared Team Access)'}
              </label>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              Default is No so lab engineers have collaborative access
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting || success}
            className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-medium bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 disabled:opacity-50 transition"
          >
            {isSubmitting ? 'Registering in Windchill...' : 'Create Windchill Product'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
