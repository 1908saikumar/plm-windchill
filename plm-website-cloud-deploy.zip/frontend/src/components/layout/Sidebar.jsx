import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Box, Cpu, FileText, GitPullRequest, 
  Activity, Bot, ArrowDownUp, LineChart, BookOpen, 
  Settings, History, HelpCircle, User, Server
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/windchill', label: 'Windchill PLM Hub', icon: Server, badge: 'PLM', badgeColor: 'bg-emerald-500/20 text-emerald-400' },
  { to: '/products', label: 'Products', icon: Box },
  { to: '/parts', label: 'Parts & BOM', icon: Cpu },
  { to: '/documents', label: 'Documents', icon: FileText },
  { to: '/change-management', label: 'Change Management', icon: GitPullRequest, badge: '3' },
  { to: '/digital-twin', label: 'Digital Twin (3D)', icon: Activity, badge: 'LIVE', badgeColor: 'bg-teal-500/20 text-teal-400' },
  { to: '/ai-assistant', label: 'AI Copilot', icon: Bot, badge: 'AI', badgeColor: 'bg-purple-500/20 text-purple-400' },
  { to: '/import-export', label: 'Import / Export', icon: ArrowDownUp },
  { to: '/predictive-analytics', label: 'Predictive Analytics', icon: LineChart },
  { to: '/learning', label: 'Learning Center', icon: BookOpen },
  { to: '/audit-log', label: 'Audit Log', icon: History },
  { to: '/settings', label: 'Settings', icon: Settings },
  { to: '/help', label: 'Help & Creo Setup', icon: HelpCircle },
];

export default function Sidebar({ isOpen, onClose }) {
  const { role } = useAuth();

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white dark:bg-[#070b16] border-r border-slate-200 dark:border-slate-800/80 transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } flex flex-col justify-between overflow-y-auto`}
      >
        <div className="p-3 space-y-1">
          <div className="px-3 py-2 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            PLM & Digital Thread
          </div>

          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onClose}
                end={item.to === '/'}
                className={({ isActive }) => `
                  flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-500/15 to-cyan-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30 font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-850/60'
                  }
                `}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold ${
                    item.badgeColor || 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </div>

        {/* Bottom System Card */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800/80 m-2 rounded-xl bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">Current Role</span>
            <span className="font-semibold text-teal-600 dark:text-teal-400">{role}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 font-mono">
            Windchill OData: v4 REST
          </div>
        </div>
      </aside>
    </>
  );
}
