import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Box, Activity, Bot, Menu } from 'lucide-react';

export default function MobileNav({ onOpenMenu }) {
  const links = [
    { to: '/', label: 'Home', icon: LayoutDashboard },
    { to: '/products', label: 'Products', icon: Box },
    { to: '/digital-twin', label: 'Twin', icon: Activity },
    { to: '/ai-assistant', label: 'AI', icon: Bot },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 h-16 bg-white/90 dark:bg-slate-950/90 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 lg:hidden flex items-center justify-around px-2">
      {links.map((link) => {
        const Icon = link.icon;
        return (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.to === '/'}
            className={({ isActive }) => `
              flex flex-col items-center justify-center w-14 h-12 rounded-xl text-[10px] font-medium transition ${
                isActive
                  ? 'text-teal-500 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <Icon className="w-5 h-5 mb-0.5" />
            <span>{link.label}</span>
          </NavLink>
        );
      })}

      <button
        onClick={onOpenMenu}
        className="flex flex-col items-center justify-center w-14 h-12 rounded-xl text-[10px] font-medium text-slate-400 hover:text-slate-200"
      >
        <Menu className="w-5 h-5 mb-0.5" />
        <span>Menu</span>
      </button>
    </nav>
  );
}
