import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useWindchill } from '../../context/WindchillContext';
import BrandLogo from '../common/BrandLogo';
import LogoSwitcherModal from '../common/LogoSwitcherModal';
import { 
  Sun, Moon, Wifi, Server, WifiOff, LogOut, User, 
  ShieldCheck, RefreshCw, Bell, ChevronDown, Sparkles, Menu, Palette, Camera
} from 'lucide-react';

export default function Navbar({ onToggleSidebar }) {
  const { user, role, quickLogin, logout, isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { status, testConnection, isTesting } = useWindchill();
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const navigate = useNavigate();

  const isLive = status.mode === 'live' && status.connected;
  const isDemo = status.isDemo || status.mode === 'demo';

  const handleRoleSwitch = async (targetRole) => {
    setShowRoleMenu(false);
    await quickLogin(targetRole);
  };

  return (
    <header className="sticky top-0 z-30 w-full h-16 bg-white/90 dark:bg-[#080d1a]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 lg:px-6 flex items-center justify-between">
      {/* Left: Mobile hamburger & Interactive Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2.5 group">
            <BrandLogo size="md" />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">PLM</span>
                <span className="text-xs px-1.5 py-0.5 rounded font-mono font-semibold bg-teal-500/15 text-teal-600 dark:text-teal-400 border border-teal-500/20">
                  Digital Twin
                </span>
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 hidden sm:block">
                PTC Windchill REST & AI
              </p>
            </div>
          </Link>

          {/* Quick Logo Option Picker button */}
          <button
            onClick={() => setIsLogoModalOpen(true)}
            className="p-1 rounded-md text-slate-400 hover:text-teal-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Change website logo (multiple options)"
          >
            <Palette className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center: Live Windchill Connection Pill */}
      <div className="hidden md:flex items-center gap-2">
        <Link 
          to="/windchill"
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border cursor-pointer transition ${
            isLive
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20'
              : isDemo
              ? 'bg-purple-500/10 border-purple-500/30 text-purple-600 dark:text-purple-300 hover:bg-purple-500/20'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20'
          }`}
          title="Open Windchill PLM Hub & Server Console"
        >
          <span className={`w-2 h-2 rounded-full ${
            isLive ? 'bg-emerald-500 animate-pulse' : isDemo ? 'bg-purple-500' : 'bg-rose-500'
          }`} />
          <span className="font-mono text-[11px]">
            {isLive ? 'Live: plm.cit.com' : isDemo ? 'Demo: Simulated REST' : 'Windchill: Offline'}
          </span>
          <span className="text-[10px] opacity-70 underline ml-1">Open Hub</span>
          {isTesting && <RefreshCw className="w-3 h-3 animate-spin ml-1" />}
        </Link>
      </div>

      {/* Right: Quick Role Switcher, Theme Toggle & Profile */}
      <div className="flex items-center gap-2.5">
        {/* Quick Demo Role Switcher */}
        {isAuthenticated && (
          <div className="relative">
            <button
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-750 transition border border-slate-200 dark:border-slate-700"
              title="Quickly switch roles for testing"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
              <span>{role}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 mt-2 w-48 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-1.5 z-40 text-xs animate-in fade-in">
                <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Switch Active Role
                </div>
                {['Admin', 'Engineer', 'Viewer'].map((r) => (
                  <button
                    key={r}
                    onClick={() => handleRoleSwitch(r)}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
                      role === r ? 'text-teal-600 dark:text-teal-400 font-semibold bg-teal-500/5' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span>{r}</span>
                    {role === r && <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Light / Dark Mode Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
        </button>

        {/* User Profile Avatar / Logout */}
        {isAuthenticated ? (
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1 rounded-full border border-transparent hover:border-slate-300 dark:hover:border-slate-700 transition"
            >
              <img
                src={user?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80'}
                alt={user?.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-teal-500/30"
              />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-40 text-xs animate-in fade-in">
                <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                  <p className="font-semibold text-slate-900 dark:text-white truncate">{user?.name}</p>
                  <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
                  <span className="inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] font-mono bg-teal-500/10 text-teal-500">
                    {role} • {user?.department || 'Engineering'}
                  </span>
                </div>

                <Link
                  to="/profile"
                  onClick={() => setShowUserMenu(false)}
                  className="flex items-center gap-2 px-4 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Your Profile</span>
                </Link>

                <Link
                  to="/profile"
                  onClick={() => setShowUserMenu(false)}
                  className="flex items-center gap-2 px-4 py-2 text-teal-600 dark:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Upload Original Photo</span>
                </Link>

                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                    navigate('/login');
                  }}
                  className="w-full flex items-center gap-2 px-4 py-2 text-rose-500 hover:bg-rose-500/10 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <Link
            to="/login"
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-teal-500 text-white hover:bg-teal-600 transition shadow-sm"
          >
            Sign In
          </Link>
        )}
      </div>

      {/* Brand Logo Picker Modal */}
      <LogoSwitcherModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
      />
    </header>
  );
}
