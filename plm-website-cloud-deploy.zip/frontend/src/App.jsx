import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { WindchillProvider } from './context/WindchillContext';

import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import MobileNav from './components/layout/MobileNav';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import PartsAndBOM from './pages/PartsAndBOM';
import Documents from './pages/Documents';
import ChangeManagement from './pages/ChangeManagement';
import DigitalTwin from './pages/DigitalTwin';
import AIAssistant from './pages/AIAssistant';
import ImportExport from './pages/ImportExport';
import PredictiveAnalytics from './pages/PredictiveAnalytics';
import Learning from './pages/Learning';
import Settings from './pages/Settings';
import AuditLog from './pages/AuditLog';
import Profile from './pages/Profile';
import Help from './pages/Help';
import WindchillHub from './pages/WindchillHub';

function AppLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-xs font-mono text-slate-400">Loading PLM & Digital Twin Platform...</span>
        </div>
      </div>
    );
  }

  // Redirect unauthenticated users to /login
  if (!isAuthenticated && location.pathname !== '/login') {
    return <Navigate to="/login" replace />;
  }

  // Login page layout without sidebar/navbar
  if (location.pathname === '/login') {
    return children;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#030712] text-slate-800 dark:text-slate-100 flex flex-col">
      {/* Top Navbar */}
      <Navbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main View Area */}
        <main className="flex-1 lg:pl-64 flex flex-col min-w-0 pb-20 lg:pb-8">
          <div className="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav onOpenMenu={() => setSidebarOpen(true)} />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <WindchillProvider>
            <AppLayout>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/" element={<Dashboard />} />
                <Route path="/windchill" element={<WindchillHub />} />
                <Route path="/products" element={<Products />} />
                <Route path="/parts" element={<PartsAndBOM />} />
                <Route path="/documents" element={<Documents />} />
                <Route path="/change-management" element={<ChangeManagement />} />
                <Route path="/digital-twin" element={<DigitalTwin />} />
                <Route path="/ai-assistant" element={<AIAssistant />} />
                <Route path="/import-export" element={<ImportExport />} />
                <Route path="/predictive-analytics" element={<PredictiveAnalytics />} />
                <Route path="/learning" element={<Learning />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/audit-log" element={<AuditLog />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/help" element={<Help />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AppLayout>
          </WindchillProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
