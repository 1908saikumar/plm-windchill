import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import api from '../services/api';
import { 
  LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, 
  ResponsiveContainer, BarChart, Bar, CartesianGrid 
} from 'recharts';
import { 
  LineChart as ChartIcon, AlertTriangle, ShieldCheck, 
  Activity, Clock, Cpu, ArrowUpRight, TrendingUp, Sparkles, RefreshCw
} from 'lucide-react';

export default function PredictiveAnalytics() {
  const [selectedPartId, setSelectedPartId] = useState('PART-BEARING-DE');
  const [predictionData, setPredictionData] = useState(null);
  const [bomSummary, setBomSummary] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async (partId) => {
    setIsLoading(true);
    try {
      const [pred, bom] = await Promise.all([
        api.predictFailure(partId),
        api.getBomSummary('PART-EDU-TOP')
      ]);
      setPredictionData(pred);
      setBomSummary(bom);
    } catch (err) {
      console.warn('Analytics fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData(selectedPartId);
  }, [selectedPartId]);

  // Lead time and Cost Sensitivity Data for forecasting chart
  const leadTimeCostForecast = [
    { period: 'Q1 (Current)', baselineCost: 4250, projectedCost: 4250, leadDays: 28 },
    { period: 'Q2 (Projected)', baselineCost: 4250, projectedCost: 4310, leadDays: 32 },
    { period: 'Q3 (SiC Ramp)', baselineCost: 4250, projectedCost: 4180, leadDays: 24 },
    { period: 'Q4 (Consolidated)', baselineCost: 4250, projectedCost: 3950, leadDays: 18 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Predictive Reliability & Cost Analytics"
        description="Machine learning Weibull failure models, Remaining Useful Life (RUL) estimation, and BOM cost forecasting."
        badge="Predictive AI Models"
        actions={
          <div className="flex items-center gap-2">
            <select
              value={selectedPartId}
              onChange={(e) => setSelectedPartId(e.target.value)}
              className="px-3 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 outline-none"
            >
              <option value="PART-BEARING-DE">Drive-End Bearing (EDU-250-BRG-102)</option>
              <option value="PART-BEARING-NDE">Non-Drive End Bearing (EDU-250-BRG-103)</option>
              <option value="PART-INVERTER-MOD">800V SiC Inverter Module</option>
              <option value="PART-STATOR-ASY">Stator Winding Core Assembly</option>
            </select>

            <button
              onClick={() => loadData(selectedPartId)}
              className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition"
              title="Refresh Models"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        }
      />

      {/* Primary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Remaining Useful Life */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Remaining Useful Life (RUL)</span>
            <Clock className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-slate-900 dark:text-white mt-2">
            {predictionData?.remainingUsefulLifeHours?.toLocaleString() || '412'} <span className="text-sm font-sans text-slate-400 font-normal">hrs</span>
          </div>
          <div className="mt-2 text-[11px] font-medium text-orange-500 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Inspection required in ~17 days</span>
          </div>
        </div>

        {/* Adjusted MTBF */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Operational MTBF</span>
            <ShieldCheck className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-teal-600 dark:text-teal-400 mt-2">
            {predictionData?.adjustedMTBF?.toLocaleString() || '14,630'} <span className="text-sm font-sans text-slate-400 font-normal">hrs</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Nominal rating: 20,000 hrs
          </p>
        </div>

        {/* Environmental Stress Factor */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Telemetry Stress Factor</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-cyan-600 dark:text-cyan-400 mt-2">
            {predictionData?.stressMultiplier || '1.38'}×
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Arrhenius Thermal + Vibration Exponent
          </p>
        </div>

        {/* Reliability Risk Level */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Failure Risk Tier</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-500 mt-2">
            {predictionData?.riskLevel || 'HIGH'}
          </div>
          <p className="mt-2 text-[11px] text-slate-400 font-sans">
            Linked to ECR-00081 Si3N4 upgrade
          </p>
        </div>
      </div>

      {/* Weibull Failure Probability Curve */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-500" />
              <span>Weibull Failure Probability Distribution Curve (β = 2.4)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Cumulative probability of wear-out failure P(t) = 1 - exp(-(t/η)^β) for {predictionData?.partName || 'Drive-End Bearing'}.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-teal-400">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span> Reliability (%)
            </span>
            <span className="flex items-center gap-1.5 text-rose-400">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Failure Prob (%)
            </span>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={predictionData?.weibullCurve || []}>
              <defs>
                <linearGradient id="colorFail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorRel" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
              <XAxis 
                dataKey="operatingHours" 
                stroke="#64748b" 
                fontSize={11} 
                tickFormatter={(val) => `${val}h`} 
              />
              <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#0f172a', 
                  borderColor: '#334155',
                  borderRadius: '8px',
                  fontSize: '11px',
                  color: '#f8fafc'
                }}
                formatter={(val, name) => [`${val}%`, name === 'failureProbabilityPct' ? 'Failure Probability' : 'Reliability']}
                labelFormatter={(label) => `Operating Hours: ${label} hrs`}
              />
              <Area type="monotone" dataKey="reliabilityPct" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorRel)" />
              <Area type="monotone" dataKey="failureProbabilityPct" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorFail)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between">
          <span className="text-slate-400">
            Current Operating Milestone: <strong className="text-white">14,218 hrs</strong> (approaching knee of wear-out curve)
          </span>
          <span className="font-semibold text-teal-400">
            {predictionData?.maintenanceRecommendation || 'Schedule overhaul within 14 calendar days.'}
          </span>
        </div>
      </div>

      {/* Cost & Sourcing Lead Time Forecast */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Optimization Forecast */}
        <div className="glass-card p-6 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              BOM Cost Optimization Trajectory ($ USD)
            </h3>
            <p className="text-xs text-slate-500">
              Parametric cost projection based on design consolidation and volume ramp.
            </p>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={leadTimeCostForecast}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="period" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} domain={[3000, 5000]} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#f8fafc'
                  }}
                  formatter={(val) => [`$${val}`, 'Projected Unit Cost']}
                />
                <Bar dataKey="projectedCost" fill="#0d9488" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[11px] text-slate-400">
            Projected unit savings of <strong>$300.00 (-7.1%)</strong> achievable by Q4 through conformal housing casting.
          </p>
        </div>

        {/* AI BOM Intelligence Highlights */}
        <div className="glass-card p-6 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                AI Sourcing & Reliability Insights
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Automated synthesis across BOM components and live telemetry streams.
            </p>

            <div className="space-y-3">
              {(bomSummary?.aiInsights || [
                'Component consolidation: The Stator Housing cooling jacket could be 3D printed with conformal channels to cut weight by 14%.',
                'Lead time compression: Establish consignment buffer stock with PowerSem for 800V SiC modules to eliminate the 45-day bottleneck.',
                'Targeted standardization: 6205 bearing size matches industrial standard catalog, allowing 3 pre-qualified second-source vendors.'
              ]).map((insight, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 text-xs flex items-start gap-2.5">
                  <span className="w-4 h-4 rounded-full bg-teal-500/20 text-teal-400 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                    {insight}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 font-mono flex justify-between">
            <span>Highest Sourcing Bottleneck:</span>
            <strong className="text-orange-400">SiC Module (45 days)</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
