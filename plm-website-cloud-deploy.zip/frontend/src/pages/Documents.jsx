import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import StatusBadge from '../components/common/StatusBadge';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  FileText, Search, Plus, Download, RefreshCw, AlertCircle, 
  FileCode, FileSpreadsheet, CheckCircle2, Eye, HardDrive
} from 'lucide-react';
import Modal from '../components/common/Modal';

export default function Documents() {
  const [documents, setDocuments] = useState([]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const { isEngineer } = useAuth();

  // Upload Form state
  const [docName, setDocName] = useState('');
  const [docType, setDocType] = useState('CADDrawing');
  const [fileName, setFileName] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  const loadDocuments = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getDocuments({ search, type: typeFilter });
      setDocuments(data.items || []);
    } catch (err) {
      setError(err.message || 'Failed to retrieve Windchill documents');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDocuments();
  }, [search, typeFilter]);

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!docName.trim()) return;

    setIsUploading(true);
    try {
      await api.createDocument({
        name: docName.trim(),
        type: docType,
        fileName: fileName.trim() || `${docName.toLowerCase().replace(/\s+/g, '_')}.pdf`,
        fileSize: Math.floor(1048576 + Math.random() * 8388608)
      });
      setIsUploadOpen(false);
      setDocName('');
      setFileName('');
      loadDocuments();
    } catch (err) {
      alert('Upload failed: ' + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const getDocIcon = (type) => {
    switch (type) {
      case 'CreoCADModel': return <FileCode className="w-5 h-5 text-teal-400" />;
      case 'CADDrawing': return <FileText className="w-5 h-5 text-cyan-400" />;
      case 'AnalysisReport': return <FileSpreadsheet className="w-5 h-5 text-purple-400" />;
      default: return <FileText className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Engineering Documents & CAD Drawings"
        description="PTC Windchill WTDocument repository, Creo CAD assemblies (.asm/.prt), and ISO engineering specifications."
        badge="WTDocument /DocMgmt"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={loadDocuments}
              className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition"
              title="Refresh Documents"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            {isEngineer && (
              <button
                onClick={() => setIsUploadOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 transition"
              >
                <Plus className="w-4 h-4" />
                <span>Upload Document</span>
              </button>
            )}
          </div>
        }
      />

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, number, filename..."
              className="w-full pl-9 pr-3.5 py-1.5 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-teal-500 outline-none"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2" />
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 outline-none"
          >
            <option value="">All Document Types</option>
            <option value="CreoCADModel">Creo 3D CAD (.asm/.prt)</option>
            <option value="CADDrawing">Manufacturing Drawings (.drw)</option>
            <option value="AnalysisReport">FEA & Thermal Reports</option>
            <option value="Specification">Engineering Specs (ISO)</option>
          </select>
        </div>

        <div className="text-xs text-slate-500 dark:text-slate-400">
          Showing {documents.length} WTDocuments
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={loadDocuments} className="text-xs font-semibold underline">Retry</button>
        </div>
      )}

      {/* Document Grid */}
      {isLoading ? (
        <LoadingSkeleton rows={4} type="card" />
      ) : documents.length === 0 ? (
        <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 space-y-3">
          <FileText className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">No Documents Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Upload CAD drawings, specifications, or FEA reports to link with Windchill parts.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {documents.map((doc) => (
            <div
              key={doc.id}
              className="glass-card p-5 flex flex-col justify-between hover:border-teal-500/50 transition"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0">
                      {getDocIcon(doc.type)}
                    </div>
                    <div>
                      <span className="font-mono text-xs font-semibold text-teal-600 dark:text-teal-400">
                        {doc.number}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                        {doc.name}
                      </h3>
                      <p className="font-mono text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        {doc.file_name} • {formatFileSize(doc.file_size)}
                      </p>
                    </div>
                  </div>
                  <StatusBadge status={doc.state} size="xs" />
                </div>
              </div>

              <div className="pt-3 mt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
                <div className="flex items-center gap-2">
                  <span>Rev {doc.version}</span>
                  <span>•</span>
                  <span>{doc.author || 'CIT Engineering'}</span>
                </div>

                <button
                  onClick={() => alert(`Simulated download of ${doc.file_name} from Windchill vault.`)}
                  className="flex items-center gap-1.5 text-teal-600 dark:text-teal-400 font-semibold hover:underline"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Document Modal */}
      <Modal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        title="Upload WTDocument to Windchill"
        subtitle="Registers CAD files, drawings, or engineering specifications into Windchill vault"
      >
        <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Document Title *
            </label>
            <input
              type="text"
              required
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              placeholder="e.g. Inverter Gate Driver Layout Schematic"
              className="w-full px-3.5 py-2 rounded-lg text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Document Type
              </label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white outline-none"
              >
                <option value="CreoCADModel">Creo CAD Model (.asm/.prt)</option>
                <option value="CADDrawing">CAD Drawing (.drw)</option>
                <option value="AnalysisReport">FEA / Thermal Report</option>
                <option value="Specification">Engineering Specification</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                File Attachment Name
              </label>
              <input
                type="text"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="e.g. inverter_schematic_v2.pdf"
                className="w-full px-3.5 py-2 rounded-lg text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>
          </div>

          <div className="p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center bg-slate-50 dark:bg-slate-800/40">
            <HardDrive className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              Drag & Drop file or Click to Browse
            </span>
            <p className="text-[11px] text-slate-400 mt-1">
              Supports .asm, .prt, .drw, .pdf, .step, .dxf (Max: 50MB)
            </p>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsUploadOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUploading}
              className="px-5 py-2 rounded-lg font-medium bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 disabled:opacity-50"
            >
              {isUploading ? 'Registering Document...' : 'Upload to Windchill'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
