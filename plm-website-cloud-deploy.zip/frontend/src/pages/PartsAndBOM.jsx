import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../components/layout/PageHeader';
import BomTreeViewer from '../components/windchill/BomTreeViewer';
import CreatePartModal from '../components/windchill/CreatePartModal';
import StatusBadge from '../components/common/StatusBadge';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Cpu, Search, Plus, Filter, Download, Activity, 
  Layers, RefreshCw, AlertCircle, FileSpreadsheet, Eye, ChevronRight
} from 'lucide-react';
import Modal from '../components/common/Modal';

export default function PartsAndBOM() {
  const [viewMode, setViewMode] = useState('tree'); // 'tree' or 'table'
  const [parts, setParts] = useState([]);
  const [bomTree, setBomTree] = useState(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedPart, setSelectedPart] = useState(null);
  const { isEngineer } = useAuth();

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [partsRes, treeRes] = await Promise.all([
        api.getParts({ search, category: categoryFilter }),
        api.getBomTree('PART-EDU-TOP')
      ]);
      setParts(partsRes.items || []);
      setBomTree(treeRes);
    } catch (err) {
      setError(err.message || 'Failed to retrieve parts and BOM structure');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [search, categoryFilter]);

  const totalCost = parts.reduce((sum, p) => sum + (p.cost || 0), 0);
  const totalWeight = parts.reduce((sum, p) => sum + (p.weight || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Parts & Multi-Level Bill of Materials (BOM)"
        description="Synchronized PTC Windchill WTPart structures with hierarchical cost and weight rollups."
        badge="WTPart & Uses Link"
        actions={
          <div className="flex items-center gap-2">
            <a
              href={api.exportPartsCsvUrl}
              download
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition shadow-sm"
              title="Export BOM to CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </a>

            <a
              href={api.exportExcelUrl('parts')}
              download
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition shadow-sm"
              title="Export BOM to Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
              <span>Excel</span>
            </a>

            {isEngineer && (
              <button
                onClick={() => setIsCreateOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create WTPart</span>
              </button>
            )}
          </div>
        }
      />

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Total Parts</span>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">{parts.length}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Rolled-Up BOM Cost</span>
          <div className="text-xl font-bold text-teal-600 dark:text-teal-400 mt-0.5">${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Assembly Mass</span>
          <div className="text-xl font-bold text-cyan-600 dark:text-cyan-400 mt-0.5">{totalWeight.toFixed(2)} kg</div>
        </div>
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Digital Twin Linked</span>
          <div className="text-xl font-bold text-orange-500 mt-0.5">5 Components</div>
        </div>
      </div>

      {/* Filters & View Mode Selector */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          {/* Search */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search parts by number, name, supplier..."
              className="w-full pl-9 pr-3.5 py-1.5 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-teal-500 outline-none"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2" />
          </div>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 outline-none"
          >
            <option value="">All Categories</option>
            <option value="Assembly">Assemblies</option>
            <option value="Subassembly">Subassemblies</option>
            <option value="Component">Components</option>
            <option value="Standard Component">Standard Parts</option>
            <option value="Sensor">Sensors</option>
            <option value="Electronics">Electronics</option>
          </select>
        </div>

        {/* View Switcher: Tree vs Table */}
        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-end sm:self-auto">
          <button
            onClick={() => setViewMode('tree')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition ${
              viewMode === 'tree'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            BOM Tree
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition ${
              viewMode === 'table'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Flat Table
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {isLoading ? (
        <LoadingSkeleton rows={5} type={viewMode === 'table' ? 'table' : 'card'} />
      ) : error ? (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={loadData} className="text-xs font-semibold underline">Retry</button>
        </div>
      ) : viewMode === 'tree' ? (
        <div className="space-y-4">
          <div className="p-3 rounded-xl bg-teal-500/10 border border-teal-500/30 text-xs text-teal-900 dark:text-teal-200 flex items-center justify-between">
            <span>Displaying hierarchical product breakdown for <strong>EDU-250-ASY-001</strong>. Click any component to inspect metadata or link to the 3D digital twin.</span>
            <Link to="/digital-twin" className="flex items-center gap-1 font-semibold text-teal-700 dark:text-teal-300 hover:underline shrink-0">
              <Activity className="w-3.5 h-3.5" />
              <span>Open 3D Model</span>
            </Link>
          </div>

          <BomTreeViewer
            treeData={bomTree}
            onSelectPart={(node) => setSelectedPart(node)}
            selectedPartId={selectedPart?.id}
          />
        </div>
      ) : (
        /* Flat Table View */
        <div className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-300 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Part Number</th>
                  <th className="py-3 px-4">Part Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Rev</th>
                  <th className="py-3 px-4">Lifecycle</th>
                  <th className="py-3 px-4 text-right">Cost (USD)</th>
                  <th className="py-3 px-4 text-right">Weight (kg)</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {parts.map((part) => (
                  <tr
                    key={part.id}
                    onClick={() => setSelectedPart(part)}
                    className="hover:bg-slate-100/70 dark:hover:bg-slate-850 cursor-pointer transition"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      {part.number}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                      {part.name}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                      {part.category}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                      {part.version}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={part.state} size="xs" />
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                      ${part.cost.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-600 dark:text-slate-400">
                      {part.weight.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                      {part.supplier || '—'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPart(part);
                        }}
                        className="p-1 rounded text-teal-600 dark:text-teal-400 hover:bg-teal-500/10"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Part Detail Inspector Modal */}
      {selectedPart && (
        <Modal
          isOpen={!!selectedPart}
          onClose={() => setSelectedPart(null)}
          title={selectedPart.name}
          subtitle={`Windchill WTPart: ${selectedPart.number}`}
          maxWidth="max-w-xl"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Windchill OData ID:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">{selectedPart.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Category:</span>
                <span className="font-semibold text-teal-400">{selectedPart.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Current Revision:</span>
                <span className="font-mono font-semibold text-slate-200">{selectedPart.version}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Lifecycle State:</span>
                <StatusBadge status={selectedPart.state} size="xs" />
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Unit Cost:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">${selectedPart.cost?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Mass:</span>
                <span className="font-mono text-slate-300">{selectedPart.weight} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Supplier:</span>
                <span className="text-slate-300">{selectedPart.supplier || 'CIT Advanced Dynamics'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Lead Time:</span>
                <span className="text-slate-300">{selectedPart.lead_time_days || 14} days</span>
              </div>
            </div>

            {selectedPart.has_twin === 1 && (
              <div className="p-3 rounded-xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-teal-400" />
                  <span className="text-teal-300">Linked to 3D Digital Twin Simulation</span>
                </div>
                <Link
                  to="/digital-twin"
                  className="px-3 py-1 rounded-lg text-xs font-semibold bg-teal-500 text-white"
                >
                  View in 3D
                </Link>
              </div>
            )}

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedPart(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create Part Modal */}
      <CreatePartModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onCreated={() => loadData()}
        parts={parts}
      />
    </div>
  );
}
