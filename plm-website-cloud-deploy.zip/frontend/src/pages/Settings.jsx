import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useWindchill } from '../context/WindchillContext';
import BrandLogo, { LOGO_OPTIONS } from '../components/common/BrandLogo';
import LogoSwitcherModal from '../components/common/LogoSwitcherModal';
import api from '../services/api';
import { 
  Settings as SettingsIcon, Server, ShieldCheck, Sun, Moon, 
  Palette, RefreshCw, Key, Users, CheckCircle2, AlertCircle, Wifi, Image
} from 'lucide-react';

export default function Settings() {
  const { user, isAdmin } = useAuth();
  const { theme, toggleTheme, accent, setAccent, logoStyle, setLogoStyle } = useTheme();
  const { status, testConnection, isTesting, toggleDemoMode } = useWindchill();
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  const [settings, setSettings] = useState({
    windchill_base_url: 'http://plm.cit.com/Windchill',
    windchill_server_ip: '172.16.31.150',
    demo_mode: 'true',
    refresh_interval_sec: '5',
    ai_api_key: '',
    language: 'en'
  });

  const [usersList, setUsersList] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function loadSettings() {
      try {
        const s = await api.getSettings();
        setSettings(prev => ({ ...prev, ...s }));
        if (isAdmin) {
          const u = await api.getUsers();
          setUsersList(u.users || []);
        }
      } catch (err) {
        console.warn('Failed to load settings:', err);
      }
    }
    loadSettings();
  }, [isAdmin]);

  const handleSave = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setSavedSuccess(false);
    try {
      await api.updateSettings(settings);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      alert('Error saving settings: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestConnection = async () => {
    const res = await testConnection();
    setTestResult(res);
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      await api.updateUserRole(userId, newRole);
      const u = await api.getUsers();
      setUsersList(u.users || []);
    } catch (err) {
      alert('Role update failed: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="System Preferences & Configuration"
        description="Configure Windchill connection parameters, demo mode, UI themes, and user access permissions."
        badge="Platform Settings"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Settings Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Windchill Server Connection */}
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-teal-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Windchill PLM Server Connection
                </h3>
              </div>
              <span className={`px-2 py-0.5 rounded text-xs font-mono font-semibold ${
                status.connected ? 'bg-emerald-500/10 text-emerald-400' : 'bg-purple-500/10 text-purple-400'
              }`}>
                {status.isDemo ? 'Demo Mode Active' : 'Live Windchill'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Windchill Base URL
                </label>
                <input
                  type="text"
                  value={settings.windchill_base_url || ''}
                  onChange={(e) => setSettings({ ...settings, windchill_base_url: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Server Internal IP
                </label>
                <input
                  type="text"
                  readOnly
                  value="172.16.31.150"
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 font-mono text-slate-500 cursor-not-allowed outline-none"
                />
              </div>
            </div>

            {/* Demo Mode Toggle & Test Button */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="demoMode"
                  checked={settings.demo_mode === 'true' || status.isDemo}
                  onChange={(e) => {
                    const enabled = e.target.checked;
                    setSettings({ ...settings, demo_mode: enabled ? 'true' : 'false' });
                    toggleDemoMode(enabled);
                  }}
                  className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 bg-slate-700 border-slate-600"
                />
                <label htmlFor="demoMode" className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <strong>Enable Demo Mode</strong> (serve realistic sample data when Windchill is unreachable)
                </label>
              </div>

              <button
                type="button"
                onClick={handleTestConnection}
                disabled={isTesting}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 text-white hover:bg-slate-800 border border-slate-700 transition"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                <span>{isTesting ? 'Testing Server...' : 'Test Connection'}</span>
              </button>
            </div>

            {testResult && (
              <div className={`p-3 rounded-lg text-xs border ${
                testResult.connected ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
              }`}>
                {testResult.message || testResult.error}
              </div>
            )}
          </div>

          {/* Theme & Appearance */}
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Palette className="w-5 h-5 text-teal-500" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Appearance & Accent Color
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Theme Mode
                </label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => theme !== 'dark' && toggleTheme()}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border font-semibold ${
                      theme === 'dark' ? 'bg-teal-500/15 border-teal-500 text-teal-400' : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Moon className="w-4 h-4" />
                    <span>Dark Industrial</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => theme !== 'light' && toggleTheme()}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border font-semibold ${
                      theme === 'light' ? 'bg-teal-500/15 border-teal-500 text-teal-600' : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Sun className="w-4 h-4" />
                    <span>Light Clean</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Accent Color Palette
                </label>
                <div className="flex items-center gap-2.5">
                  {[
                    { id: 'teal', color: 'bg-teal-500' },
                    { id: 'cyan', color: 'bg-cyan-500' },
                    { id: 'orange', color: 'bg-orange-500' },
                    { id: 'blue', color: 'bg-blue-600' }
                  ].map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setAccent(item.id)}
                      className={`w-7 h-7 rounded-full ${item.color} ring-2 transition ${
                        accent === item.id ? 'ring-white scale-110' : 'ring-transparent hover:scale-105'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Website Logo Multiple Options */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="block font-semibold text-slate-800 dark:text-slate-200">
                    Website Brand Logo Style
                  </label>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                    Choose an SVG emblem or upload your institution's custom logo.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsLogoModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-500 text-white hover:bg-teal-600 transition shadow-sm"
                >
                  Upload / Customize
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {LOGO_OPTIONS.filter(o => o.id !== 'custom').map((opt) => {
                  const isSelected = logoStyle === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setLogoStyle(opt.id)}
                      className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition ${
                        isSelected
                          ? 'bg-teal-500/10 border-teal-500/60 ring-2 ring-teal-500/20'
                          : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-750'
                      }`}
                    >
                      <BrandLogo size="sm" overrideStyle={opt.id} />
                      <div className="min-w-0">
                        <div className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                          {opt.name}
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                          {isSelected ? '✓ Active' : 'Select'}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* User Management (Admin Only) */}
          {isAdmin && (
            <div className="glass-card p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-teal-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  User Management (Admin Role)
                </h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-850 text-slate-400 font-semibold text-[10px] uppercase">
                    <tr>
                      <th className="py-2.5 px-3">Name</th>
                      <th className="py-2.5 px-3">Email</th>
                      <th className="py-2.5 px-3">Department</th>
                      <th className="py-2.5 px-3">Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {usersList.map((u) => (
                      <tr key={u.id}>
                        <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">{u.name}</td>
                        <td className="py-2.5 px-3 text-slate-500">{u.email}</td>
                        <td className="py-2.5 px-3 text-slate-400">{u.department}</td>
                        <td className="py-2.5 px-3">
                          <select
                            value={u.role}
                            onChange={(e) => handleRoleChange(u.id, e.target.value)}
                            className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-semibold text-teal-600 dark:text-teal-400"
                          >
                            <option value="Admin">Admin</option>
                            <option value="Engineer">Engineer</option>
                            <option value="Viewer">Viewer</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Save Button */}
          <div className="flex items-center justify-between">
            {savedSuccess && (
              <span className="flex items-center gap-1.5 text-xs text-emerald-500 font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Configuration saved successfully!</span>
              </span>
            )}
            <div className="ml-auto">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="px-6 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 disabled:opacity-50 transition"
              >
                {isSaving ? 'Saving Changes...' : 'Save Preferences'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Info Column */}
        <div className="space-y-6">
          {/* Security Credentials Tip */}
          <div className="glass-card p-5 space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h4 className="font-semibold text-slate-900 dark:text-white">Credentials Security Policy</h4>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              Windchill username and password (<code className="font-mono text-teal-400">WINDCHILL_USER</code>, <code className="font-mono text-teal-400">WINDCHILL_PASS</code>) are stored exclusively in the server-side <code className="font-mono">.env</code> file. They are never exposed to the client browser.
            </p>
          </div>

          {/* AI LLM Key Config */}
          <div className="glass-card p-5 space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4 text-purple-400" />
              <h4 className="font-semibold text-slate-900 dark:text-white">AI Copilot LLM Engine</h4>
            </div>
            <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
              Default uses the built-in engineering reasoning engine. To link external OpenAI or Gemini models, configure <code className="font-mono text-purple-400">LLM_API_KEY</code> in <code className="font-mono">.env</code>.
            </p>
          </div>
        </div>
      </div>

      <LogoSwitcherModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
      />
    </div>
  );
}
