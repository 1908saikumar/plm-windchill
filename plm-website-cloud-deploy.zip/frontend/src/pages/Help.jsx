import React, { useState } from 'react';
import PageHeader from '../components/layout/PageHeader';
import { 
  HelpCircle, Server, Terminal, ShieldCheck, Copy, 
  Check, ExternalLink, Cpu, AlertTriangle, Network, Lock
} from 'lucide-react';

export default function Help() {
  const [copiedHosts, setCopiedHosts] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const hostsLine = '172.16.31.150 plm.cit.com';
  const windchillUrl = 'http://plm.cit.com/Windchill';

  const copyToClipboard = (text, setCopied) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <PageHeader
        title="College Windchill Setup & Deployment Guide"
        description="Comprehensive network documentation for connecting to 172.16.31.150 (plm.cit.com), Creo CAD integration, and cloud deployment."
        badge="Documentation"
      />

      {/* Critical Network Notice Banner */}
      <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 space-y-2">
        <div className="flex items-center gap-2 font-bold text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
          <span>Important: Private Campus IP Architecture (172.16.31.150)</span>
        </div>
        <p className="text-xs leading-relaxed">
          The address <strong className="font-mono">172.16.31.150</strong> is an <em>RFC 1918 private IPv4 internal subnet</em>. It can only be reached when your computer is connected to the college campus Wi-Fi, Ethernet, or an authorized institutional VPN. When outside the college intranet, this web application seamlessly operates in <strong>Windchill Demo Mode</strong> so you can view, create, test, and demonstrate all features without interruptions.
        </p>
      </div>

      {/* Section 1: OS Hosts File Configuration */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <Terminal className="w-5 h-5 text-teal-500" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            1. Operating System Hosts File Configuration
          </h3>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          Because PTC Windchill uses hostname-based session cookies and Kerberos/basic authentication, the hostname <code className="font-mono text-teal-400">plm.cit.com</code> must resolve directly to <code className="font-mono text-teal-400">172.16.31.150</code> on the computer running the backend proxy.
        </p>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 font-mono text-xs">
          <span className="text-emerald-400 font-semibold">{hostsLine}</span>
          <button
            onClick={() => copyToClipboard(hostsLine, setCopiedHosts)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition text-[11px]"
          >
            {copiedHosts ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedHosts ? 'Copied!' : 'Copy Line'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-white">Windows Instructions:</span>
            <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
              <li>Open Notepad as <strong>Administrator</strong>.</li>
              <li>Open <code className="font-mono">C:\Windows\System32\drivers\etc\hosts</code>.</li>
              <li>Add <code className="font-mono text-teal-400">{hostsLine}</code> at the bottom and Save.</li>
            </ol>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-white">Linux / macOS Instructions:</span>
            <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
              <li>Open terminal and run: <code className="font-mono">sudo nano /etc/hosts</code>.</li>
              <li>Append the line: <code className="font-mono text-teal-400">{hostsLine}</code>.</li>
              <li>Press <kbd>Ctrl+O</kbd> and <kbd>Enter</kbd> to save, then <kbd>Ctrl+X</kbd> to exit.</li>
            </ol>
          </div>
        </div>
      </div>

      {/* Section 2: PTC Creo Parametric CAD Connection */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <Cpu className="w-5 h-5 text-teal-500" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            2. Connecting PTC Creo Parametric to Windchill
          </h3>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          Design engineers in the CIT laboratory connect Creo Parametric directly to the same Windchill instance:
        </p>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800">
            <h4 className="font-bold text-slate-900 dark:text-white mb-1">Step A: Add Server in Creo</h4>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              In Creo Parametric, navigate to <strong>File → Manage Session → Server Management</strong>. Click <strong>Server → Register New Server</strong>.
              Enter Name as <code className="font-mono text-teal-400">CIT Windchill</code> and Location as <code className="font-mono text-teal-400">http://plm.cit.com/Windchill</code>.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800">
            <h4 className="font-bold text-slate-900 dark:text-white mb-1">Step B: Set as Primary Server & Create Workspace</h4>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              Right-click the registered server and select <strong>Set as Primary Server</strong>. Under the server, click <strong>Workspace → New</strong> and choose product context <strong>High-Efficiency Electric Drive Unit 250kW</strong>.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800">
            <h4 className="font-bold text-slate-900 dark:text-white mb-1">Step C: Model Check-In & Digital Twin Sync</h4>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              When you save or check in assemblies (.asm) and drawings (.drw), Windchill iterates the WTPart revision (e.g. from A.1 to B.1), which updates the 3D Digital Twin viewer.
            </p>
          </div>
        </div>
      </div>

      {/* Section 3: Deployment Architecture & Options */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <Network className="w-5 h-5 text-teal-500" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            3. Production Deployment Scenarios
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Option A */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-bold text-teal-400">
              <Server className="w-4 h-4" />
              <span>Option A: Host Inside College Network</span>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              Deploy the container on a campus Linux server or lab VM. It has direct socket connectivity to <code className="font-mono">172.16.31.150:80</code>. Accessible to all lab workstations, PCs, and connected mobile devices on the campus Wi-Fi.
            </p>
          </div>

          {/* Option B */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-bold text-cyan-400">
              <Lock className="w-4 h-4" />
              <span>Option B: Public Cloud + Reverse Proxy / VPN</span>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              Deploy the web application on Render, Railway, or Vercel with HTTPS. Connect the cloud backend to the campus network via WireGuard / Tailscale VPN or an NGINX reverse proxy with an authenticated TLS tunnel (Cloudflare Tunnel).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
