import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import BrandLogo from '../components/common/BrandLogo';
import { 
  ShieldCheck, ArrowRight, Lock, Mail, User, 
  Cpu, Sun, Moon, AlertCircle, CheckCircle2, Sparkles, Activity
} from 'lucide-react';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [loginInput, setLoginInput] = useState('admin@cit.com');
  const [password, setPassword] = useState('admin123');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [department, setDepartment] = useState('Product Engineering');
  const [role, setRole] = useState('Engineer');
  const [error, setError] = useState(null);
  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const { login, register, quickLogin } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setIsLoading(true);

    try {
      if (isForgotPassword) {
        setMessage('Password reset link sent to registered email. For demo accounts, use credentials below.');
        setIsLoading(false);
        return;
      }

      if (isRegister) {
        await register({ email: loginInput, username, password, name, department, role });
      } else {
        await login(loginInput, password);
      }
      navigate('/');
    } catch (err) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemo = async (roleName) => {
    setIsLoading(true);
    setError(null);
    try {
      await quickLogin(roleName);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 dark:bg-[#030712] text-slate-800 dark:text-slate-100">
      {/* Left Hero Graphic Section */}
      <div className="md:w-1/2 bg-gradient-to-br from-slate-900 via-[#071328] to-[#041c22] p-8 md:p-14 flex flex-col justify-between relative overflow-hidden text-white border-r border-slate-800">
        {/* Background glow effects */}
        <div className="absolute top-1/4 -left-20 w-96 h-96 rounded-full bg-teal-500/15 blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-10 right-0 w-80 h-80 rounded-full bg-orange-500/10 blur-3xl pointer-events-none"></div>

        {/* Brand header */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo size="md" />
            <div>
              <h2 className="text-base font-bold tracking-tight text-white">CIT PLM Platform</h2>
              <p className="text-[11px] text-teal-400 font-mono">Windchill REST • 172.16.31.150</p>
            </div>
          </div>

          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/80 text-slate-300 hover:text-white transition"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 my-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-teal-500/10 text-teal-300 border border-teal-500/20 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-teal-400" />
            <span>Digital Thread & Predictive Analytics</span>
          </div>

          <h1 className="text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight">
            AI & Digital Twin Integration in <span className="bg-gradient-to-r from-teal-400 to-cyan-300 bg-clip-text text-transparent">Product Lifecycle Management</span>
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed max-w-md">
            Seamlessly bridging PTC Windchill enterprise PLM with real-time WebGL 3D digital twins, telemetry streaming, and automated AI engineering intelligence.
          </p>

          {/* Interactive Graphic Representation */}
          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 backdrop-blur-md space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono text-teal-400">EDU-250 Motor Assembly</span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                Digital Twin Active
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                <div className="text-[10px] text-slate-400">Speed</div>
                <div className="font-mono font-bold text-white mt-0.5">12,000 RPM</div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                <div className="text-[10px] text-slate-400">Temperature</div>
                <div className="font-mono font-bold text-teal-300 mt-0.5">78.4 °C</div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                <div className="text-[10px] text-slate-400">Vibration</div>
                <div className="font-mono font-bold text-orange-400 mt-0.5">2.15 mm/s</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="relative z-10 text-[11px] text-slate-400 flex items-center justify-between">
          <span>College Server: plm.cit.com/Windchill</span>
          <span>Role-Based Access Control</span>
        </div>
      </div>

      {/* Right Login / Register Form Section */}
      <div className="md:w-1/2 p-8 md:p-14 flex flex-col justify-center max-w-xl mx-auto w-full">
        <div className="mb-6">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            {isForgotPassword 
              ? 'Reset Your Password' 
              : isRegister 
              ? 'Create PLM Account' 
              : 'Sign in to Platform'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {isForgotPassword
              ? 'Enter your institutional email to recover access.'
              : isRegister
              ? 'Register as an engineer or viewer in the digital thread directory.'
              : 'Access Windchill product structures, 3D twins, and AI copilot.'}
          </p>
        </div>

        {/* Quick Demo Role Switcher Buttons */}
        {!isForgotPassword && !isRegister && (
          <div className="mb-6 p-3.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
                Quick Demo Accounts:
              </span>
              <span className="text-[10px] text-slate-400">Click to auto-login</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('Admin')}
                disabled={isLoading}
                className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 hover:border-teal-500 hover:text-teal-500 transition shadow-sm"
              >
                Admin
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('Engineer')}
                disabled={isLoading}
                className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 hover:border-teal-500 hover:text-teal-500 transition shadow-sm"
              >
                Engineer
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('Viewer')}
                disabled={isLoading}
                className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 hover:border-teal-500 hover:text-teal-500 transition shadow-sm"
              >
                Viewer
              </button>
            </div>
          </div>
        )}

        {/* Alerts */}
        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 text-xs rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {message && (
          <div className="mb-4 flex items-center gap-2 p-3 text-xs rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{message}</span>
          </div>
        )}

        {/* Auth Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Dr. Robert Chen"
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="rchen"
                    className="w-full px-3.5 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Role
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  >
                    <option value="Engineer">Engineer</option>
                    <option value="Admin">Admin</option>
                    <option value="Viewer">Viewer</option>
                  </select>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {isRegister ? 'Institutional Email' : 'Email or Username'}
            </label>
            <div className="relative">
              <input
                type={isRegister ? 'email' : 'text'}
                required
                value={loginInput}
                onChange={(e) => setLoginInput(e.target.value)}
                placeholder="admin@cit.com"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
              />
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            </div>
          </div>

          {!isForgotPassword && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Password
                </label>
                {!isRegister && (
                  <button
                    type="button"
                    onClick={() => setIsForgotPassword(true)}
                    className="text-xs text-teal-600 dark:text-teal-400 hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2 transition disabled:opacity-50 mt-2"
          >
            {isLoading ? 'Authenticating...' : (
              <>
                <span>{isForgotPassword ? 'Send Recovery Link' : isRegister ? 'Register Account' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Toggle between Login, Register, Forgot */}
        <div className="mt-6 text-center text-xs text-slate-500 dark:text-slate-400 space-y-2">
          {isForgotPassword ? (
            <button
              onClick={() => setIsForgotPassword(false)}
              className="text-teal-600 dark:text-teal-400 font-semibold hover:underline"
            >
              Back to Sign In
            </button>
          ) : isRegister ? (
            <p>
              Already have an account?{' '}
              <button
                onClick={() => setIsRegister(false)}
                className="text-teal-600 dark:text-teal-400 font-semibold hover:underline"
              >
                Sign In
              </button>
            </p>
          ) : (
            <p>
              Don't have an account?{' '}
              <button
                onClick={() => setIsRegister(true)}
                className="text-teal-600 dark:text-teal-400 font-semibold hover:underline"
              >
                Register
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
