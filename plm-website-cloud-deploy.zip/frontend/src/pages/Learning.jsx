import React, { useState } from 'react';
import PageHeader from '../components/layout/PageHeader';
import { 
  BookOpen, Layers, Activity, Bot, Cpu, CheckCircle2, 
  ArrowRight, ShieldCheck, Terminal, Server, Code 
} from 'lucide-react';

export default function Learning() {
  const [activeTab, setActiveTab] = useState('plm');

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Engineering Knowledge & Architecture Hub"
        description="Interactive guides explaining Product Lifecycle Management (PLM), Digital Twin streaming, and AI predictive maintenance."
        badge="Educational Center"
      />

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'plm', label: 'PLM & Windchill Architecture', icon: Layers },
          { id: 'twin', label: 'Digital Twin Cyber-Physical Thread', icon: Activity },
          { id: 'ai', label: 'AI Predictive Models & Weibull', icon: Bot },
          { id: 'creo', label: 'Creo Parametric Integration', icon: Cpu }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                isActive
                  ? 'bg-teal-500/15 text-teal-600 dark:text-teal-400 border border-teal-500/30'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content: PLM Architecture */}
      {activeTab === 'plm' && (
        <div className="space-y-6">
          <div className="glass-card p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-teal-500" />
              <span>The Digital Thread in Product Lifecycle Management</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Product Lifecycle Management (PLM) is the single source of truth for all product-related engineering data across its entire lifespan—from initial concept and requirements, through Creo 3D CAD modeling, manufacturing bill of materials (MBOM), field operation, and eventual recycling.
            </p>

            {/* Architecture Diagram */}
            <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 text-white space-y-6">
              <div className="text-xs font-mono font-semibold text-teal-400 uppercase tracking-wider text-center">
                Digital Thread Architecture: PTC Windchill to WebGL Digital Twin
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center text-xs">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 mx-auto flex items-center justify-center font-bold">1</div>
                  <h4 className="font-bold text-white">Creo Parametric CAD</h4>
                  <p className="text-[11px] text-slate-400">Master .prt and .asm 3D assemblies created by design engineers.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-teal-500/40 space-y-2">
                  <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 mx-auto flex items-center justify-center font-bold">2</div>
                  <h4 className="font-bold text-teal-300">PTC Windchill Server</h4>
                  <p className="text-[11px] text-slate-400">plm.cit.com (172.16.31.150). Stores WTParts, revisions, and multi-level BOMs.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-purple-500/40 space-y-2">
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 mx-auto flex items-center justify-center font-bold">3</div>
                  <h4 className="font-bold text-purple-300">Express OData Proxy</h4>
                  <p className="text-[11px] text-slate-400">Secure backend handling basic auth, session cookies, and CSRF nonces.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-orange-500/40 space-y-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 mx-auto flex items-center justify-center font-bold">4</div>
                  <h4 className="font-bold text-orange-300">3D WebGL Twin & AI</h4>
                  <p className="text-[11px] text-slate-400">Real-time Three.js viewer with live telemetry and predictive failure algorithms.</p>
                </div>
              </div>
            </div>

            {/* OData REST API Reference Code Block */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Code className="w-4 h-4 text-teal-500" />
                <span>PTC Windchill REST OData v4 Endpoint Patterns</span>
              </h4>
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto">
                <div className="text-slate-500">// Fetch Products Container</div>
                <div className="text-teal-400">GET http://plm.cit.com/Windchill/servlet/odata/v4/ProdMgmt/Products</div>
                <div className="text-slate-500 mt-2">// Create New Product with GEN Template</div>
                <div className="text-cyan-400">POST http://plm.cit.com/Windchill/servlet/odata/v4/ProdMgmt/Products</div>
                <div className="text-orange-400">{`{ "Name": "EDU-250 Powertrain", "Template": "GEN", "PrivateAccess": false }`}</div>
                <div className="text-slate-500 mt-2">// Required Security Headers</div>
                <div className="text-slate-300">Authorization: Basic &lt;base64(WINDCHILL_USER:WINDCHILL_PASS)&gt;</div>
                <div className="text-slate-300">CSRF_NONCE: &lt;token acquired via PTC.GetCSRFToken()&gt;</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: Digital Twin */}
      {activeTab === 'twin' && (
        <div className="glass-card p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-teal-500" />
            <span>Cyber-Physical Digital Twin Architecture</span>
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            A digital twin is a dynamic virtual clone of an active physical machine that updates in real time using sensor telemetry. In our platform, the digital twin is directly coupled with the Windchill WTPart record (EDU-250-ASY-001) so that field operational anomalies immediately link back to engineering change workflows.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="font-bold text-teal-400">Interactive Three.js Rendering</span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Utilizes WebGL shaders to simulate exploded assemblies, wireframe inspection, and thermal heatmaps rendered directly in modern browsers without CAD plugins.
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="font-bold text-cyan-400">High-Frequency Telemetry Stream</span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Samples speed (RPM), stator temperature (°C), bearing vibration (mm/s), and fluid pressures with sub-second responsiveness.
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="font-bold text-orange-400">Closed-Loop PLM Feedback</span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                When sensor limits are breached, the platform can auto-generate a Problem Report (PR) or Engineering Change Request (ECR) in Windchill.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: AI Predictive Models */}
      {activeTab === 'ai' && (
        <div className="glass-card p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-500" />
            <span>AI Predictive Maintenance & Weibull Reliability Models</span>
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Rather than waiting for a component to break down in service (corrective maintenance) or replacing parts too early (rigid calendar maintenance), predictive maintenance evaluates dynamic operating stress factors to estimate Remaining Useful Life (RUL).
          </p>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono space-y-2 text-teal-300">
            <div className="text-slate-400">// Two-Parameter Weibull Cumulative Failure Probability Function</div>
            <div>P(t) = 1 - exp(- (t / η) ^ β)</div>
            <div className="text-slate-400 pt-2">// Where:</div>
            <div className="text-slate-300">• β (Beta) = 2.4 (Shape parameter indicating mechanical wear-out stage)</div>
            <div className="text-slate-300">• η (Eta) = Characteristic life in operating hours, scaled by Arrhenius thermal stress</div>
            <div className="text-slate-300">• t = Current cumulative operating hours (14,218 hrs for EDU-250)</div>
          </div>
        </div>
      )}

      {/* Tab Content: Creo CAD Integration */}
      {activeTab === 'creo' && (
        <div className="glass-card p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-teal-500" />
            <span>PTC Creo Parametric Setup with College Windchill</span>
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Follow these exact laboratory steps to link your workstation's PTC Creo Parametric software with the college server:
          </p>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="font-bold text-slate-900 dark:text-white">Step 1: Register Server in Creo</span>
              <p className="text-slate-600 dark:text-slate-300">
                In Creo, open <strong>File → Manage Session → Server Management</strong>. Click <strong>Server → Register New Server</strong>.
                Set Location to <code className="text-teal-400 font-mono">http://plm.cit.com/Windchill</code>.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="font-bold text-slate-900 dark:text-white">Step 2: Set as Primary Server</span>
              <p className="text-slate-600 dark:text-slate-300">
                Right-click the newly registered server and choose <strong>Set as Primary Server</strong>. This ensures all CAD models and drawing files save to Windchill by default.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="font-bold text-slate-900 dark:text-white">Step 3: Create Active Workspace</span>
              <p className="text-slate-600 dark:text-slate-300">
                Create a project workspace linked to context <strong>High-Efficiency Electric Drive Unit 250kW</strong>. Models checked in from Creo automatically create and iterate Windchill WTParts.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
