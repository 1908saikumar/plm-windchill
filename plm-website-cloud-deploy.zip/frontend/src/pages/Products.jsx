import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import CreateProductModal from '../components/windchill/CreateProductModal';
import StatusBadge from '../components/common/StatusBadge';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Box, Search, Plus, Filter, RefreshCw, AlertCircle, 
  ExternalLink, CheckCircle2, ShieldCheck, Lock, Unlock, Eye
} from 'lucide-react';
import Modal from '../components/common/Modal';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const { isEngineer } = useAuth();

  const loadProducts = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getProducts({ search });
      setProducts(data.items || []);
    } catch (err) {
      setError(err.message || 'Failed to retrieve Windchill products');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, [search]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Windchill Product Contexts"
        description="Browse enterprise product containers registered in PTC Windchill (plm.cit.com)."
        badge="OData /ProdMgmt/Products"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={loadProducts}
              className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition"
              title="Refresh Products"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            {isEngineer && (
              <button
                onClick={() => setIsCreateOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 transition"
              >
                <Plus className="w-4 h-4" />
                <span>Create Product</span>
              </button>
            )}
          </div>
        }
      />

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative w-full sm:w-96">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products by title, ID, or description..."
            className="w-full pl-9 pr-4 py-2 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-teal-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 w-full sm:w-auto justify-end">
          <span>Found {products.length} registered contexts</span>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={loadProducts} className="text-xs font-semibold underline">Retry</button>
        </div>
      )}

      {/* Product Grid / Loading */}
      {isLoading ? (
        <LoadingSkeleton rows={4} type="card" />
      ) : products.length === 0 ? (
        <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 space-y-3">
          <Box className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">No Products Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            No matching Windchill product contexts found. Create a new product with the GEN template to get started.
          </p>
          {isEngineer && (
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-teal-500 text-white"
            >
              Create Product
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
          {products.map((prod) => (
            <div
              key={prod.id}
              className="glass-card p-5 flex flex-col justify-between hover:border-teal-500/50 transition cursor-pointer"
              onClick={() => setSelectedProduct(prod)}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <span className="font-mono text-xs font-semibold text-teal-600 dark:text-teal-400">
                      {prod.number || prod.id}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                      {prod.name}
                    </h3>
                  </div>
                  <StatusBadge status={prod.state} size="sm" />
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed mb-4">
                  {prod.description || 'No description provided.'}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px]">
                    Template: {prod.template || 'GEN'}
                  </span>
                  <span className="flex items-center gap-1 text-[11px]">
                    {prod.private_access ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3 text-emerald-400" />}
                    {prod.private_access ? 'Private' : 'Shared'}
                  </span>
                </div>

                <button className="flex items-center gap-1 text-teal-600 dark:text-teal-400 font-semibold hover:underline">
                  <Eye className="w-3.5 h-3.5" />
                  <span>Inspect</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Inspect Product Modal */}
      {selectedProduct && (
        <Modal
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
          title={selectedProduct.name}
          subtitle={`Windchill Product Context (${selectedProduct.number || selectedProduct.id})`}
          maxWidth="max-w-xl"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Context Identifier:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">{selectedProduct.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Template:</span>
                <span className="font-mono font-semibold text-teal-400">{selectedProduct.template}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Private Access:</span>
                <span className="font-mono font-semibold text-slate-300">{selectedProduct.private_access ? 'Yes' : 'No'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Lifecycle State:</span>
                <StatusBadge status={selectedProduct.state} size="xs" />
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Created By:</span>
                <span className="font-semibold text-slate-300">{selectedProduct.created_by || 'CIT Engineer'}</span>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-1">Description</h4>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-850 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                {selectedProduct.description || 'No detailed scope recorded in Windchill.'}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedProduct(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create Modal */}
      <CreateProductModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onCreated={() => loadProducts()}
      />
    </div>
  );
}
