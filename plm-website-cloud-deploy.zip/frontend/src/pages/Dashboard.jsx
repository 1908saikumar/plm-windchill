import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../components/layout/PageHeader';
import ConnectionStatusBanner from '../components/windchill/ConnectionStatusBanner';
import CreateProductModal from '../components/windchill/CreateProductModal';
import api from '../services/api';
import { 
  Box, Cpu, Activity, GitPullRequest, ArrowUpRight, 
  Sparkles, RefreshCw, Layers, ShieldCheck, Clock, AlertTriangle, ArrowRight
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import StatusBadge from '../components/common/StatusBadge';

export default function Dashboard() {
  const [twinState, setTwinState] = useState(null);
  const [recentLogs, setRecentLogs] = useState([]);
  const [stats, setStats] = useState({
    products: 4,
    parts: 11,
    changes: 3,
    documents: 4
  });
  const [isCreateProductOpen, setIsCreateProductOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const [state, logsRes, prodRes, partRes, crRes] = await Promise.all([
          api.getTwinState(),
          api.getAuditLogs({ limit: 6 }),
          api.getProducts({ limit: 1 }),
          api.getParts(),
          api.getChangeRequests()
        ]);
        setTwinState(state);
        setRecentLogs(logsRes.items || []);
        setStats({
          products: prodRes.total || 4,
          parts: partRes.total || 11,
          changes: crRes.total || 3,
          documents: 4
        });
      } catch (e) {
        console.warn('Dashboard load error:', e.message);
      }
    }
    loadData();

    // Poll live telemetry every 3 seconds for dynamic dashboard experience
    const interval = setInterval(async () => {
      try {
        const s = await api.getTwinState();
        setTwinState(s);
      } catch (err) {}
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      await api.syncWindchill();
      const logs = await api.getAuditLogs({ limit: 6 });
      setRecentLogs(logs.items || []);
    } catch (e) {
      console.warn('Sync failed:', e.message);
    } finally {
      setIsSyncing(false);
    }
  };

  const current = twinState?.currentTelemetry || {
    temperature: 78.4,
    vibration: 2.15,
    pressure: 4.22,
    rpm: 12000,
    power: 210.5
  };

  const chartData = (twinState?.recentSeries || []).slice(-15).map(pt => ({
    time: pt.timestamp ? new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '',
    temp: pt.temperature,
    vibration: pt.vibration * 20, // scale for dual-line visibility
    rawVib: pt.vibration
  }));

  const pieData = [
    { name: 'Released', value: 7, color: '#10b981' },
    { name: 'In Work', value: 3, color: '#06b6d4' },
    { name: 'Under Review', value: 2, color: '#f59e0b' },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <PageHeader
        title="Engineering Operations Dashboard"
        description="Real-time telemetry, PTC Windchill PLM repository status, and AI predictive health."
        badge="Active Digital Thread"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={handleSync}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-750 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Syncing...' : 'Sync Windchill'}</span>
            </button>

            <button
              onClick={() => setIsCreateProductOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 transition"
            >
              <Box className="w-3.5 h-3.5" />
              <span>+ New Product</span>
            </button>
          </div>
        }
      />

      {/* College Windchill Connection Banner */}
      <ConnectionStatusBanner />

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Products KPI */}
        <Link to="/products" className="glass-card p-5 group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Windchill Products
            </span>
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 group-hover:bg-teal-500/20 transition">
              <Box className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              {stats.products}
            </span>
            <span className="text-xs text-emerald-500 font-medium">GEN Contexts</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Primary: EDU-250 Powertrain</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
          </p>
        </Link>

        {/* Parts / BOM KPI */}
        <Link to="/parts" className="glass-card p-5 group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              WTParts & BOM
            </span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 group-hover:bg-cyan-500/20 transition">
              <Cpu className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              {stats.parts}
            </span>
            <span className="text-xs text-cyan-500 font-medium">Multi-Level Tree</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Rolled-up Cost: $4,250.00</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
          </p>
        </Link>

        {/* Digital Twin KPI */}
        <Link to="/digital-twin" className="glass-card p-5 group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              3D Digital Twin
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-500/20 transition">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono digital-hud hud-glow-teal text-teal-600 dark:text-teal-400">
              {current.rpm.toLocaleString()}
            </span>
            <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">RPM</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-600 dark:text-slate-300 flex items-center justify-between font-mono">
            <span><strong className="text-teal-600 dark:text-teal-400">{current.temperature}°C</strong> • <strong className="text-orange-600 dark:text-orange-400">{current.vibration} mm/s</strong></span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
          </p>
        </Link>

        {/* Change Management KPI */}
        <Link to="/change-management" className="glass-card p-5 group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Change Requests
            </span>
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 group-hover:bg-orange-500/20 transition">
              <GitPullRequest className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              {stats.changes}
            </span>
            <span className="text-xs text-orange-500 font-medium">ECR / ECO / PR</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span className="text-rose-400">1 Critical PR Pending</span>
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
          </p>
        </Link>
      </div>

      {/* Main Charts & Telemetry Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Telemetry Real-time Trend Chart */}
        <div className="lg:col-span-2 glass-card p-5 flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-teal-500" />
                <span>Live Digital Twin Telemetry Feed</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Stator RTD Temperature (°C) & Drive-End Bearing Vibration (mm/s)
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-teal-400 font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span> Temp (°C)
              </span>
              <span className="flex items-center gap-1.5 text-orange-400 font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span> Vibration
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorVib" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#f8fafc'
                  }}
                  formatter={(val, name, item) => {
                    if (name === 'vibration') return [`${item.payload.rawVib} mm/s`, 'Vibration'];
                    return [`${val} °C`, 'Temperature'];
                  }}
                />
                <Area type="monotone" dataKey="temp" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorTemp)" />
                <Area type="monotone" dataKey="vibration" stroke="#f97316" strokeWidth={2} fillOpacity={1} fill="url(#colorVib)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-4 font-mono text-slate-700 dark:text-slate-300 text-[11px]">
              <span>Current Temp: <strong className="text-teal-600 dark:text-teal-400">{current.temperature}°C</strong></span>
              <span>Vibration: <strong className="text-orange-600 dark:text-orange-400">{current.vibration} mm/s</strong></span>
              <span>Power: <strong className="text-slate-900 dark:text-white">{current.power} kW</strong></span>
            </div>
            <Link to="/digital-twin" className="text-teal-600 dark:text-teal-400 hover:underline font-semibold flex items-center gap-1">
              <span>Open 3D Viewer</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* Lifecycle Distribution & AI Health Summary */}
        <div className="glass-card p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span>AI Reliability & Lifecycle</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Weibull Risk Assessment & Component Maturity
            </p>

            <div className="h-44 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#0f172a', 
                      borderColor: '#334155',
                      borderRadius: '8px',
                      fontSize: '11px',
                      color: '#f8fafc'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-3 gap-1 text-center text-xs mt-2">
              {pieData.map(d => (
                <div key={d.name} className="p-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <div className="text-[10px] text-slate-600 dark:text-slate-400">{d.name}</div>
                  <div className="font-mono font-bold text-slate-900 dark:text-white">{d.value}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 text-xs">
            <span className="font-bold text-purple-700 dark:text-purple-300">AI Recommendation:</span>
            <p className="text-[11px] text-slate-700 dark:text-slate-200 mt-1 leading-relaxed">
              Bearing DE is entering Weibull wear-out phase. Approve <strong className="text-teal-700 dark:text-teal-300 font-semibold">ECR-00081</strong> to prevent unexpected downtime.
            </p>
          </div>
        </div>
      </div>

      {/* Recent Engineering Activity & Quick Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Audit Trail */}
        <div className="lg:col-span-2 glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              <span>Recent Engineering & PLM Activity</span>
            </h3>
            <Link to="/audit-log" className="text-xs text-teal-600 dark:text-teal-400 hover:underline font-semibold">
              View All Logs
            </Link>
          </div>

          <div className="space-y-3">
            {recentLogs.map((log) => (
              <div key={log.id} className="flex items-start justify-between p-3 rounded-xl bg-slate-100/70 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs transition">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">{log.user_name}</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                      {log.action}
                    </span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300 text-[11px]">
                    {log.details}
                  </p>
                </div>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono shrink-0 ml-4">
                  {log.timestamp ? new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Launchpad */}
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
            Quick Launchpad
          </h3>

          <div className="space-y-2">
            <button
              onClick={() => setIsCreateProductOpen(true)}
              className="w-full p-3 rounded-xl bg-slate-100/70 dark:bg-slate-850 hover:bg-slate-200/80 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left transition flex items-center justify-between group"
            >
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">Create Windchill Product</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">GEN Template • Team Access</div>
              </div>
              <Box className="w-4 h-4 text-teal-500 group-hover:scale-110 transition" />
            </button>

            <Link
              to="/digital-twin"
              className="w-full p-3 rounded-xl bg-slate-100/70 dark:bg-slate-850 hover:bg-slate-200/80 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left transition flex items-center justify-between group block"
            >
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">3D Exploded Twin Viewer</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">4 CAD Models • Thermal Shaders</div>
              </div>
              <Activity className="w-4 h-4 text-cyan-500 group-hover:scale-110 transition" />
            </Link>

            <Link
              to="/ai-assistant"
              className="w-full p-3 rounded-xl bg-slate-100/70 dark:bg-slate-850 hover:bg-slate-200/80 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left transition flex items-center justify-between group block"
            >
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">PLM Copilot Chat</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">BOM Optimization & Creo Setup</div>
              </div>
              <Sparkles className="w-4 h-4 text-purple-500 group-hover:scale-110 transition" />
            </Link>

            <Link
              to="/import-export"
              className="w-full p-3 rounded-xl bg-slate-100/70 dark:bg-slate-850 hover:bg-slate-200/80 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left transition flex items-center justify-between group block"
            >
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">Export CSV & Excel</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Parts, BOM, and Change Requests</div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-orange-500 group-hover:scale-110 transition" />
            </Link>
          </div>
        </div>
      </div>

      {/* Create Product Modal */}
      <CreateProductModal
        isOpen={isCreateProductOpen}
        onClose={() => setIsCreateProductOpen(false)}
        onCreated={(prod) => {
          setStats(prev => ({ ...prev, products: prev.products + 1 }));
        }}
      />
    </div>
  );
}
