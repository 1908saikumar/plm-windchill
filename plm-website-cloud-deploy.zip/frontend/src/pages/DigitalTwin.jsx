import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import DigitalTwinViewer, { CAD_MODELS } from '../components/3d/DigitalTwinViewer';
import LiveDigitGauge from '../components/common/LiveDigitGauge';
import api from '../services/api';
import { 
  Activity, Thermometer, Gauge, Zap, AlertTriangle, 
  CheckCircle2, RefreshCw, Layers, ShieldCheck, Play, Square, 
  Link as LinkIcon, Box, Cpu, Disc, Radio
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer 
} from 'recharts';

export default function DigitalTwin() {
  const [twinState, setTwinState] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);
  const [selectedAnomaly, setSelectedAnomaly] = useState('BEARING_VIBRATION');
  const [activeModelId, setActiveModelId] = useState('motor');

  const loadState = async () => {
    try {
      const state = await api.getTwinState();
      setTwinState(state);
    } catch (err) {
      console.warn('Twin fetch error:', err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadState();
    const interval = setInterval(loadState, 1500);
    return () => clearInterval(interval);
  }, []);

  const handleToggleAnomaly = async () => {
    if (!twinState) return;
    const nextActive = !twinState.activeAnomaly;
    setIsSimulating(true);
    try {
      const updated = await api.simulateTwinAnomaly(nextActive, selectedAnomaly);
      setTwinState(updated);
    } catch (e) {
      console.warn('Simulation toggle failed:', e);
    } finally {
      setIsSimulating(false);
    }
  };

  const telemetry = twinState?.currentTelemetry || {
    temperature: 78.4,
    vibration: 2.15,
    pressure: 4.22,
    rpm: 12000,
    power: 210.5
  };

  const currentModel = CAD_MODELS.find(m => m.id === activeModelId) || CAD_MODELS[0];

  const series = (twinState?.recentSeries || []).slice(-20).map(pt => ({
    time: pt.timestamp ? new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '',
    temperature: pt.temperature,
    vibration: pt.vibration,
    rpm: pt.rpm
  }));

  const lifecycleStages = twinState?.lifecycle || [
    { stage: 'Design', status: 'Completed', date: '2025-03-12', detail: 'Creo 3D CAD Assembly & GD&T sign-off' },
    { stage: 'Manufacture', status: 'Completed', date: '2025-08-20', detail: 'Zero-defect pilot assembly at CIT Fab' },
    { stage: 'Operate', status: 'Active', date: '2026-01-10', detail: 'Live telemetry stream linked to Windchill digital thread' },
    { stage: 'Service', status: 'Upcoming', date: '2026-11-15', detail: 'Preventive bearing overhaul scheduled (ECR-00081)' },
    { stage: 'Retire', status: 'Pending', date: '2034-01-01', detail: 'Planned 10-year circular economy recycling' }
  ];

  const hasAnomaly = twinState?.activeAnomaly || telemetry.temperature > 82 || telemetry.vibration > 3.5;

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="3D Digital Twin & Real-Time Cyber-Physical Telemetry"
        description="Synchronized cyber-physical CAD models linked to PTC Windchill WTParts with live digital telemetry gauges."
        badge="Live Telemetry Link"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedAnomaly}
              onChange={(e) => setSelectedAnomaly(e.target.value)}
              className="px-3 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 outline-none"
            >
              <option value="BEARING_VIBRATION">Simulate: Bearing Harmonic Spike</option>
              <option value="THERMAL_OVERLOAD">Simulate: Stator Thermal Overload</option>
            </select>

            <button
              onClick={handleToggleAnomaly}
              disabled={isSimulating}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition ${
                twinState?.activeAnomaly
                  ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                  : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white border-slate-300 dark:border-slate-700 hover:border-teal-500'
              }`}
            >
              {twinState?.activeAnomaly ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5" />}
              <span>{twinState?.activeAnomaly ? 'Stop Anomaly' : 'Inject Anomaly'}</span>
            </button>
          </div>
        }
      />

      {/* CAD Model Quick Switcher Tabs */}
      <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Box className="w-4 h-4 text-teal-500" />
            <span>Select 3D CAD Design Assembly</span>
          </span>
          <span className="text-xs text-slate-500 font-mono">
            {CAD_MODELS.length} Pre-loaded CAD Assemblies
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {CAD_MODELS.map((m) => {
            const isSelected = activeModelId === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setActiveModelId(m.id)}
                className={`p-3 rounded-xl border text-left transition ${
                  isSelected
                    ? 'bg-teal-500/10 border-teal-500/60 ring-2 ring-teal-500/20 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] font-bold text-teal-600 dark:text-teal-400">
                    {m.partNumber}
                  </span>
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-teal-400' : 'bg-slate-400'}`} />
                </div>
                <div className="font-bold text-xs text-slate-900 dark:text-white truncate">
                  {m.name}
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                  {m.category}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Critical Anomaly Alert */}
      {hasAnomaly && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-800 dark:text-rose-200 flex items-start justify-between gap-3 animate-pulse">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Telemetry Anomaly Detected: Critical Threshold Exceeded
              </h4>
              <p className="text-xs text-rose-900 dark:text-rose-200 mt-0.5 leading-relaxed">
                Vibration harmonic peak ({telemetry.vibration} mm/s) or Thermal RTD ({telemetry.temperature}°C) indicates outer raceway micro-spalling. AI reliability engine recommends immediate review of <strong>ECR-00081</strong>.
              </p>
            </div>
          </div>
          <button
            onClick={handleToggleAnomaly}
            className="px-3 py-1 rounded-lg text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 shrink-0 shadow-sm"
          >
            Reset Telemetry
          </button>
        </div>
      )}

      {/* Main 3D Viewer & Real-time Gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 3D Canvas */}
        <div className="lg:col-span-2 space-y-4">
          <DigitalTwinViewer
            telemetry={telemetry}
            selectedModelId={activeModelId}
            onModelChange={(newId) => setActiveModelId(newId)}
            height="520px"
          />

          {/* Telemetry Sensor Stream Chart */}
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-teal-500" />
                  <span>Real-Time Sensor Telemetry Stream</span>
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">Live sampling at 1.5s interval with hardware jitter</p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5 text-teal-600 dark:text-teal-400 font-mono">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span> Temp (°C)
                </span>
                <span className="flex items-center gap-1.5 text-orange-600 dark:text-orange-400 font-mono">
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span> Vib (mm/s)
                </span>
              </div>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={series}>
                  <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#0f172a', 
                      borderColor: '#334155',
                      borderRadius: '8px',
                      fontSize: '11px',
                      color: '#f8fafc'
                    }}
                  />
                  <Line type="monotone" dataKey="temperature" stroke="#14b8a6" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="vibration" stroke="#f97316" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right Telemetry Gauges (Live Digits) & Windchill Metadata */}
        <div className="space-y-4">
          <div className="glass-card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Radio className="w-4 h-4 text-teal-500 animate-pulse" />
                <span>Live Digital Telemetry Gauges</span>
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
                ● Live 1.5s
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              High-precision digital telemetry readings with illuminated status indicators.
            </p>

            {/* Live Digits Gauges Grid */}
            <div className="space-y-3 pt-1">
              {/* Shaft Speed / RPM */}
              <LiveDigitGauge
                label="Shaft Rotational Speed"
                value={telemetry.rpm}
                unit="RPM"
                min={0}
                max={15000}
                decimals={0}
                warningThreshold={13500}
                dangerThreshold={14500}
                icon={Gauge}
                colorScheme="cyan"
                subtitle="Synchronous Frequency: 400 Hz"
              />

              {/* Stator RTD Temperature */}
              <LiveDigitGauge
                label="Stator RTD Core Temperature"
                value={telemetry.temperature}
                unit="°C"
                min={20}
                max={110}
                decimals={1}
                warningThreshold={80.0}
                dangerThreshold={86.0}
                icon={Thermometer}
                colorScheme="teal"
                subtitle="Max Permissible: 95.0°C"
              />

              {/* Bearing Vibration RMS */}
              <LiveDigitGauge
                label="Drive-End Bearing Vibration"
                value={telemetry.vibration}
                unit="mm/s"
                min={0}
                max={6.0}
                decimals={2}
                warningThreshold={3.2}
                dangerThreshold={3.8}
                icon={Activity}
                colorScheme="orange"
                subtitle="ISO 10816 Zone B"
              />

              {/* Output Power */}
              <LiveDigitGauge
                label="Inverter Output Power"
                value={telemetry.power}
                unit="kW"
                min={0}
                max={300}
                decimals={1}
                warningThreshold={260}
                dangerThreshold={285}
                icon={Zap}
                colorScheme="green"
                subtitle="Continuous Rating: 250 kW"
              />

              {/* Hydraulic / Lube Pressure */}
              <LiveDigitGauge
                label="Coolant Loop Pressure"
                value={telemetry.pressure}
                unit="bar"
                min={1.0}
                max={6.0}
                decimals={2}
                warningThreshold={5.2}
                dangerThreshold={5.6}
                icon={Disc}
                colorScheme="purple"
                subtitle="Nominal: 4.2 bar"
              />
            </div>
          </div>

          {/* Windchill Digital Thread Linkage Card (High Contrast) */}
          <div className="glass-card p-5 space-y-3 text-xs">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <LinkIcon className="w-4 h-4 text-teal-500" />
              <span>Windchill PLM Linkage</span>
            </h4>

            <div className="space-y-2 font-mono text-[11px]">
              <div className="flex justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">WTPart Number:</span>
                <span className="text-slate-900 dark:text-white font-bold">{currentModel.partNumber}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Master Assembly CAD:</span>
                <span className="text-teal-700 dark:text-teal-300 font-semibold">{currentModel.id}_master.asm</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Operational Hours:</span>
                <span className="text-slate-900 dark:text-white font-bold">14,218 hrs</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Server Host:</span>
                <span className="text-teal-600 dark:text-teal-400 font-bold">plm.cit.com (172.16.31.150)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lifecycle Timeline Module */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Lifecycle Stage Timeline (Digital Thread)
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              End-to-end PLM phase milestones from concept CAD design through retirement.
            </p>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
            Phase 3: Operational Service
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-2">
          {lifecycleStages.map((stage) => {
            const isDone = stage.status === 'Completed';
            const isActive = stage.status === 'Active';
            return (
              <div
                key={stage.stage}
                className={`p-4 rounded-xl border relative transition ${
                  isActive
                    ? 'bg-teal-500/10 border-teal-500/50 shadow-md shadow-teal-500/10'
                    : isDone
                    ? 'bg-slate-100 dark:bg-slate-850/80 border-slate-200 dark:border-slate-800'
                    : 'bg-slate-50/50 dark:bg-slate-900/30 border-dashed border-slate-200 dark:border-slate-800/60 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold font-mono text-slate-900 dark:text-white uppercase">
                    {stage.stage}
                  </span>
                  <span className={`w-2.5 h-2.5 rounded-full ${
                    isActive ? 'bg-teal-400 animate-ping' : isDone ? 'bg-emerald-400' : 'bg-slate-500'
                  }`} />
                </div>
                <div className="text-[11px] font-mono text-teal-700 dark:text-teal-400 font-semibold">{stage.date}</div>
                <p className="text-xs text-slate-700 dark:text-slate-300 mt-2 leading-relaxed">
                  {stage.detail}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
