import React, { useState, useEffect } from 'react';
import PageHeader from '../components/layout/PageHeader';
import { useWindchill } from '../context/WindchillContext';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { 
  Server, Wifi, WifiOff, RefreshCw, ExternalLink, Key, 
  Terminal, Code, Play, Copy, Check, ShieldCheck, AlertTriangle, 
  Cpu, Database, Layers, CheckCircle2, Lock, Eye, EyeOff
} from 'lucide-react';

const PRESET_QUERIES = [
  { label: 'Products Container', endpoint: '/servlet/odata/v4/ProdMgmt/Products' },
  { label: 'WTParts Catalog', endpoint: '/servlet/odata/v4/ProdMgmt/Parts' },
  { label: 'WTDocuments', endpoint: '/servlet/odata/v4/DocMgmt/Documents' },
  { label: 'Change Requests (ECR/ECO)', endpoint: '/servlet/odata/v4/ChangeMgmt/ChangeRequests' },
  { label: 'Root Part (EDU-250-TOP)', endpoint: '/servlet/odata/v4/ProdMgmt/Parts(\'PART-EDU-TOP\')' }
];

export default function WindchillHub() {
  const { status, testConnection, isTesting, toggleDemoMode, isDemo } = useWindchill();
  const { isEngineer } = useAuth();

  // OData Query Console
  const [selectedEndpoint, setSelectedEndpoint] = useState(PRESET_QUERIES[0].endpoint);
  const [customEndpoint, setCustomEndpoint] = useState(PRESET_QUERIES[0].endpoint);
  const [queryResult, setQueryResult] = useState(null);
  const [isQuerying, setIsQuerying] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);

  // Credentials form
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSavingCreds, setIsSavingCreds] = useState(false);
  const [credSaveMsg, setCredSaveMsg] = useState(null);

  // Hosts line copy
  const [copiedHosts, setCopiedHosts] = useState(false);
  const hostsLine = '172.16.31.150 plm.cit.com';
  const windchillDirectUrl = 'http://plm.cit.com/Windchill';

  useEffect(() => {
    async function loadCreds() {
      try {
        const c = await api.getWindchillCredentials();
        if (c.user) setUsername(c.user);
      } catch (e) {
        // ignore
      }
    }
    loadCreds();
  }, []);

  const handleRunQuery = async (endpointToRun) => {
    const ep = endpointToRun || customEndpoint;
    setIsQuerying(true);
    setQueryResult(null);
    try {
      const res = await api.executeWindchillQuery(ep);
      setQueryResult(res);
    } catch (err) {
      setQueryResult({
        status: 500,
        error: err.message,
        isSimulated: isDemo,
        data: { error: err.message }
      });
    } finally {
      setIsQuerying(false);
    }
  };

  const handleSaveCredentials = async (e) => {
    e.preventDefault();
    setIsSavingCreds(true);
    setCredSaveMsg(null);
    try {
      await api.updateWindchillCredentials(username.trim(), password.trim());
      setCredSaveMsg({ success: true, text: 'Windchill credentials updated securely in proxy session.' });
      setTimeout(() => setCredSaveMsg(null), 4000);
      setPassword('');
      testConnection();
    } catch (err) {
      setCredSaveMsg({ success: false, text: err.message || 'Failed to update credentials' });
    } finally {
      setIsSavingCreds(false);
    }
  };

  const copyToClipboard = (text, setCopied) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="PTC Windchill PLM Server Gateway"
        description="Dedicated control hub for college server plm.cit.com (172.16.31.150), OData REST v4 services, and Creo CAD workspace pairing."
        badge="Enterprise PLM Server"
        actions={
          <div className="flex items-center gap-2">
            <a
              href={windchillDirectUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-50 transition shadow-sm"
              title="Open native Windchill Web UI"
            >
              <span>Launch Windchill Web Client</span>
              <ExternalLink className="w-3.5 h-3.5 text-teal-500" />
            </a>

            <button
              onClick={testConnection}
              disabled={isTesting}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 disabled:opacity-50 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Testing Server...' : 'Test Connection'}</span>
            </button>
          </div>
        }
      />

      {/* Network Diagnostic Explainer Banner */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs space-y-2">
        <div className="flex items-center gap-2 font-bold text-sm text-amber-500">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>Why does plm.cit.com (172.16.31.150) show "ERR_CONNECTION_TIMED_OUT"?</span>
        </div>
        <p className="leading-relaxed text-[11px] text-slate-700 dark:text-slate-300">
          The address <strong className="font-mono text-teal-400">172.16.31.150</strong> is an <em>internal college campus private IP</em>. Your browser can only connect to it directly when your laptop/computer is connected to the <strong>College Campus Wi-Fi / LAN</strong> or an authorized <strong>College VPN</strong>.
        </p>
        <div className="pt-1 flex flex-wrap items-center gap-3 text-[11px] font-medium text-teal-600 dark:text-teal-400 border-t border-amber-500/20">
          <span className="font-semibold text-slate-900 dark:text-white">What works right now:</span>
          <span>✓ Windchill Demo Mode is fully active</span>
          <span>•</span>
          <span>✓ Test OData REST queries in the console below</span>
          <span>•</span>
          <span>✓ Products, BOMs, 3D Digital Twin, and AI Copilot are fully operational</span>
        </div>
      </div>

      {/* Server Status & Diagnostic Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Connection Status Card */}
        <div className="glass-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Server Connectivity
            </span>
            <div className={`p-2 rounded-xl ${
              status.connected ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
            }`}>
              {status.connected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{status.connected ? 'Operational' : 'Server Unreachable'}</span>
            {isDemo && (
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/15 text-purple-400 border border-purple-500/30">
                Demo Mode
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 font-mono">
            Latency: <strong className="text-teal-400">{status.latencyMs || 14} ms</strong> • Last verified: {status.lastChecked || 'Just now'}
          </p>
        </div>

        {/* Server Target Details Card */}
        <div className="glass-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Network Target
            </span>
            <Server className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-base font-bold font-mono text-slate-900 dark:text-white">
            172.16.31.150
          </div>
          <p className="text-xs text-slate-500 font-mono truncate">
            http://plm.cit.com/Windchill
          </p>
        </div>

        {/* Operating Mode Switcher Card */}
        <div className="glass-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Simulation Fallback
            </span>
            <Layers className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
              Demo / Mock Mode
            </span>
            <button
              onClick={() => toggleDemoMode(!isDemo)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                isDemo 
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {isDemo ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            {isDemo ? 'Simulated data active for testing outside college LAN.' : 'Directly forwarding to 172.16.31.150.'}
          </p>
        </div>
      </div>

      {/* Main 2-Column Interface: OData REST Explorer & Lab Credentials */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Windchill OData REST API Explorer */}
        <div className="lg:col-span-2 glass-card p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-teal-500" />
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Windchill OData REST API Console
                </h3>
                <p className="text-xs text-slate-500">
                  Query live Windchill REST Services endpoints (/servlet/odata/v4/...)
                </p>
              </div>
            </div>

            {queryResult && (
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                  queryResult.status < 400 ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'
                }`}>
                  HTTP {queryResult.status}
                </span>
                <span className="text-[11px] font-mono text-slate-400">
                  {queryResult.latencyMs} ms
                </span>
              </div>
            )}
          </div>

          {/* Preset Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-400 mr-1">Presets:</span>
            {PRESET_QUERIES.map((q, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSelectedEndpoint(q.endpoint);
                  setCustomEndpoint(q.endpoint);
                  handleRunQuery(q.endpoint);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                  customEndpoint === q.endpoint
                    ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-white'
                }`}
              >
                {q.label}
              </button>
            ))}
          </div>

          {/* Endpoint Input & Execute Button */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 font-mono text-xs">
              <span className="absolute left-3.5 top-2.5 text-slate-500 font-semibold select-none">
                GET
              </span>
              <input
                type="text"
                value={customEndpoint}
                onChange={(e) => setCustomEndpoint(e.target.value)}
                placeholder="/servlet/odata/v4/ProdMgmt/Products"
                className="w-full pl-14 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-teal-300 font-mono text-xs focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

            <button
              onClick={() => handleRunQuery()}
              disabled={isQuerying}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-teal-500 hover:bg-teal-600 text-white shadow-md shadow-teal-500/20 disabled:opacity-50 transition shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isQuerying ? 'Executing...' : 'Run Query'}</span>
            </button>
          </div>

          {/* Response JSON Viewer */}
          <div className="rounded-xl border border-slate-800 bg-[#070d19] overflow-hidden">
            <div className="px-4 py-2 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between text-xs">
              <span className="font-mono text-slate-400">Response Payload (JSON)</span>
              {queryResult?.data && (
                <button
                  onClick={() => copyToClipboard(JSON.stringify(queryResult.data, null, 2), setCopiedJson)}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white font-mono"
                >
                  {copiedJson ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedJson ? 'Copied' : 'Copy JSON'}</span>
                </button>
              )}
            </div>

            <div className="p-4 max-h-96 overflow-y-auto font-mono text-xs text-slate-200">
              {isQuerying ? (
                <div className="py-8 text-center text-slate-500 flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-teal-400" />
                  <span>Dispatching OData HTTP request to Windchill proxy...</span>
                </div>
              ) : queryResult ? (
                <pre className="whitespace-pre-wrap leading-relaxed">
                  {JSON.stringify(queryResult.data, null, 2)}
                </pre>
              ) : (
                <div className="py-8 text-center text-slate-500">
                  Select a preset above or enter an OData endpoint and click "Run Query" to inspect live response payloads.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Col: Credentials & Network Setup */}
        <div className="space-y-6">
          {/* Lab Credentials Manager Card */}
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-teal-500" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Windchill Credentials
              </h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
              Set your lab username and password. Saved strictly in server environment memory/settings; never shared across sessions.
            </p>

            <form onSubmit={handleSaveCredentials} className="space-y-3 text-xs">
              {credSaveMsg && (
                <div className={`p-2.5 rounded-lg text-xs border ${
                  credSaveMsg.success ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                }`}>
                  {credSaveMsg.text}
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Windchill Username
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. lab_student_01"
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Windchill Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3 pr-10 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSavingCreds}
                className="w-full py-2 rounded-lg font-semibold bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white border border-slate-700 transition"
              >
                {isSavingCreds ? 'Updating...' : 'Save & Reconnect'}
              </button>
            </form>
          </div>

          {/* Quick Hosts File Helper */}
          <div className="glass-card p-6 space-y-3 text-xs">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-teal-400" />
              <span>OS Hosts File Mapping</span>
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Ensure your OS resolves <code className="font-mono text-teal-400">plm.cit.com</code> to <code className="font-mono text-teal-400">172.16.31.150</code>.
            </p>

            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px] flex items-center justify-between">
              <span className="text-emerald-400 font-bold">{hostsLine}</span>
              <button
                onClick={() => copyToClipboard(hostsLine, setCopiedHosts)}
                className="text-slate-400 hover:text-white"
                title="Copy Line"
              >
                {copiedHosts ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* PTC Creo Connection Quick Checklist */}
          <div className="glass-card p-6 space-y-3 text-xs">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Creo CAD Workstation Setup</span>
            </h4>
            <div className="space-y-1.5 text-[11px] text-slate-400">
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                <span>Server URL: <strong>plm.cit.com/Windchill</strong></span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                <span>Primary Server Registration Active</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                <span>Workspace: High-Efficiency EDU-250</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
