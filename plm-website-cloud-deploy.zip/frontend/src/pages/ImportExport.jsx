import React, { useState } from 'react';
import PageHeader from '../components/layout/PageHeader';
import api from '../services/api';
import { 
  ArrowDownUp, Download, RefreshCw, Upload, FileSpreadsheet, 
  FileText, CheckCircle2, AlertCircle, Server, Database, HardDrive, Printer
} from 'lucide-react';

export default function ImportExport() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState(null);
  const [error, setError] = useState(null);

  const handleSyncWindchill = async () => {
    setIsSyncing(true);
    setError(null);
    try {
      const res = await api.syncWindchill();
      setSyncResult(res);
    } catch (err) {
      setError(err.message || 'Failed to sync with Windchill server');
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="PLM Import & Export Gateway"
        description="Synchronize repositories with PTC Windchill REST Services or export engineering packages into CSV, Excel, and PDF formats."
        badge="Bi-Directional Gateway"
        actions={
          <button
            onClick={handlePrintPdf}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF Report</span>
          </button>
        }
      />

      {/* Two Column Layout: Import vs Export */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Import from Windchill Panel */}
        <div className="glass-card p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-teal-500/10 text-teal-500 border border-teal-500/20">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Pull Data from Windchill (Import)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Target: http://plm.cit.com/Windchill (172.16.31.150)
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Dispatches an automated OData batch query across <strong className="text-teal-400">/ProdMgmt/Products</strong>, <strong className="text-teal-400">/ProdMgmt/Parts</strong>, and <strong className="text-teal-400">/DocMgmt/Documents</strong>. Updates the local SQLite cache with revisions, BOM hierarchies, and lifecycle states.
            </p>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Connection Mode:</span>
                <span className="font-mono font-semibold text-teal-400">
                  {syncResult?.mode || 'Windchill REST / Demo Fallback'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Last Synchronized:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">
                  {syncResult?.timestamp ? new Date(syncResult.timestamp).toLocaleString() : 'Recent session active'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Target Hosts Resolution:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">172.16.31.150 → plm.cit.com</span>
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {syncResult && (
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs space-y-1">
                <div className="flex items-center gap-2 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{syncResult.message}</span>
                </div>
                <div className="grid grid-cols-4 gap-2 pt-2 text-center font-mono">
                  <div className="p-1 rounded bg-slate-900/40">
                    <span className="text-[10px] text-slate-400">Products</span>
                    <div className="font-bold text-white">{syncResult.productsCount}</div>
                  </div>
                  <div className="p-1 rounded bg-slate-900/40">
                    <span className="text-[10px] text-slate-400">Parts</span>
                    <div className="font-bold text-white">{syncResult.partsCount}</div>
                  </div>
                  <div className="p-1 rounded bg-slate-900/40">
                    <span className="text-[10px] text-slate-400">Docs</span>
                    <div className="font-bold text-white">{syncResult.documentsCount}</div>
                  </div>
                  <div className="p-1 rounded bg-slate-900/40">
                    <span className="text-[10px] text-slate-400">ECRs</span>
                    <div className="font-bold text-white">{syncResult.changeRequestsCount}</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <button
            onClick={handleSyncWindchill}
            disabled={isSyncing}
            className="w-full py-2.5 rounded-xl font-semibold text-xs bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white shadow-md shadow-teal-500/20 flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Executing Windchill REST Sync...' : 'Execute Full Repository Sync'}</span>
          </button>
        </div>

        {/* Export Data Suite Panel */}
        <div className="glass-card p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-500 border border-cyan-500/20">
                <Download className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Export Data Suite
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Standardized CSV, Excel (.xls), and structured reports
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Extract bill of materials, product hierarchies, and change management logs with RFC 4180 CSV compliance and Microsoft Excel UTF-8 tab-delimited formatting.
            </p>

            <div className="space-y-3">
              {/* Parts & BOM CSV */}
              <a
                href={api.exportPartsCsvUrl}
                download
                className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 transition group"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-teal-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">WTParts & Multi-Level BOM (.csv)</div>
                    <div className="text-[11px] text-slate-500">Includes part numbers, costs, weights, lead times & failure rates</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-teal-400 transition" />
              </a>

              {/* Products CSV */}
              <a
                href={api.exportProductsCsvUrl}
                download
                className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 transition group"
              >
                <div className="flex items-center gap-3">
                  <Database className="w-5 h-5 text-cyan-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">Windchill Products Catalog (.csv)</div>
                    <div className="text-[11px] text-slate-500">Product containers, GEN templates, and access permissions</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition" />
              </a>

              {/* Changes CSV */}
              <a
                href={api.exportChangesCsvUrl}
                download
                className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 transition group"
              >
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="w-5 h-5 text-orange-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">Change Requests & Problem Reports (.csv)</div>
                    <div className="text-[11px] text-slate-500">ECR, ECO, PR registers with AI risk scores</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-orange-400 transition" />
              </a>

              {/* Excel Format */}
              <a
                href={api.exportExcelUrl('parts')}
                download
                className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 transition group"
              >
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">Excel-Compatible Master Workbook (.xls)</div>
                    <div className="text-[11px] text-slate-500">Pre-formatted spreadsheet with UTF-8 BOM encoding</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-emerald-400 transition" />
              </a>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-400 text-center font-mono">
            Compliant with ISO 10303 STEP / PLM XML Exchange Standards
          </div>
        </div>
      </div>
    </div>
  );
}
