import React, { useState, useRef } from 'react';
import PageHeader from '../components/layout/PageHeader';
import { useAuth } from '../context/AuthContext';
import { 
  User, ShieldCheck, Mail, Building, Key, CheckCircle2, 
  Camera, Upload, Link as LinkIcon, Check, AlertCircle, RefreshCw, Trash2
} from 'lucide-react';

export default function Profile() {
  const { user, role, updateProfilePhoto } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [photoMessage, setPhotoMessage] = useState(null);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const fileInputRef = useRef(null);

  const defaultAvatar = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80';

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setPhotoMessage({ type: 'error', text: 'Please select a valid image file (JPG, PNG, WebP).' });
      return;
    }

    // Limit to reasonable size (e.g. 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setPhotoMessage({ type: 'error', text: 'Image file is too large. Please select an image under 5MB.' });
      return;
    }

    setIsUploading(true);
    setPhotoMessage(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const dataUrl = event.target.result;
        await updateProfilePhoto(dataUrl);
        setPhotoMessage({ type: 'success', text: 'Original profile photo successfully updated and saved!' });
        setTimeout(() => setPhotoMessage(null), 4000);
      } catch (err) {
        setPhotoMessage({ type: 'error', text: 'Failed to save profile photo: ' + err.message });
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleUrlSubmit = async (e) => {
    e.preventDefault();
    if (!customUrl.trim()) return;

    setIsUploading(true);
    setPhotoMessage(null);
    try {
      await updateProfilePhoto(customUrl.trim());
      setPhotoMessage({ type: 'success', text: 'Profile photo URL updated successfully!' });
      setShowUrlInput(false);
      setCustomUrl('');
      setTimeout(() => setPhotoMessage(null), 4000);
    } catch (err) {
      setPhotoMessage({ type: 'error', text: 'Failed to update photo URL: ' + err.message });
    } finally {
      setIsUploading(false);
    }
  };

  const handleResetToDefault = async () => {
    setIsUploading(true);
    try {
      await updateProfilePhoto(defaultAvatar);
      setPhotoMessage({ type: 'success', text: 'Reset to default institutional avatar.' });
      setTimeout(() => setPhotoMessage(null), 3000);
    } catch (err) {
      setPhotoMessage({ type: 'error', text: err.message });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <PageHeader
        title="User Engineering Profile"
        description="Active institutional credentials, role permissions, and customized profile photograph."
        badge={role}
      />

      {/* Profile Card */}
      <div className="glass-card p-6 space-y-6">
        {/* Status / Feedback Alert */}
        {photoMessage && (
          <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border transition animate-in fade-in ${
            photoMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-300'
          }`}>
            {photoMessage.type === 'success' ? (
              <Check className="w-4 h-4 shrink-0 text-emerald-500" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            )}
            <span>{photoMessage.text}</span>
          </div>
        )}

        {/* Profile Avatar & Details */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          {/* Avatar Container with Hover Upload Overlay */}
          <div className="relative group shrink-0">
            <img
              src={user?.avatar || defaultAvatar}
              alt={user?.name || 'Engineer'}
              className="w-24 h-24 rounded-2xl object-cover ring-4 ring-teal-500/30 shadow-lg bg-slate-900"
            />

            {/* Quick Upload Hover Overlay */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="absolute inset-0 rounded-2xl bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity duration-200 cursor-pointer"
              title="Click to upload your original photo"
            >
              {isUploading ? (
                <RefreshCw className="w-6 h-6 animate-spin text-teal-400" />
              ) : (
                <>
                  <Camera className="w-6 h-6 text-teal-400" />
                  <span className="text-[10px] font-semibold mt-1">Change Photo</span>
                </>
              )}
            </button>

            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
          </div>

          {/* User Identity Info */}
          <div className="flex-1 space-y-2">
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                {user?.name || 'Engineering User'}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 font-mono mt-0.5">
                {user?.email}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-semibold uppercase bg-teal-500/15 text-teal-700 dark:text-teal-400 border border-teal-500/30">
                {role} Role
              </span>
              <span className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                {user?.department || 'Product Engineering'}
              </span>
            </div>

            {/* Photo Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-500 hover:bg-teal-600 text-white shadow-sm shadow-teal-500/20 transition"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Original Photo</span>
              </button>

              <button
                type="button"
                onClick={() => setShowUrlInput(!showUrlInput)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition"
              >
                <LinkIcon className="w-3.5 h-3.5 text-teal-500" />
                <span>Use Image URL</span>
              </button>

              {user?.avatar && user.avatar !== defaultAvatar && (
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-slate-500 dark:text-slate-400 hover:text-rose-500 transition"
                  title="Reset to default avatar"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Enter Photo URL Sub-form */}
        {showUrlInput && (
          <form onSubmit={handleUrlSubmit} className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2 animate-in fade-in">
            <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200">
              Paste Direct Image Link (HTTPS)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="url"
                required
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://example.com/your-photo.jpg"
                className="flex-1 px-3 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-teal-500"
              />
              <button
                type="submit"
                disabled={isUploading || !customUrl.trim()}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-teal-500 text-white hover:bg-teal-600 transition"
              >
                Save URL
              </button>
            </div>
          </form>
        )}

        {/* Metadata Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-850/80 border border-slate-200 dark:border-slate-800 space-y-1">
            <span className="text-slate-500 dark:text-slate-400">Username</span>
            <div className="font-mono font-semibold text-slate-900 dark:text-white">{user?.username}</div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-850/80 border border-slate-200 dark:border-slate-800 space-y-1">
            <span className="text-slate-500 dark:text-slate-400">Department</span>
            <div className="font-semibold text-slate-900 dark:text-white">{user?.department || 'Product Engineering'}</div>
          </div>
        </div>

        {/* Role Privileges */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Role Privileges ({role})
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
              <span>Browse Products, WTParts, and BOMs</span>
            </div>
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
              <span>Interactive 3D Digital Twin Viewer</span>
            </div>
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
              <span>AI Copilot & Predictive Failure Models</span>
            </div>
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
              <span>Export CSV, Excel & PDF packages</span>
            </div>
            {role !== 'Viewer' && (
              <>
                <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
                  <span>Create Windchill Products (GEN Template)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
                  <span>Create WTParts & Submit Change Requests</span>
                </div>
              </>
            )}
            {role === 'Admin' && (
              <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
                <span>Manage Users & System Configuration</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
