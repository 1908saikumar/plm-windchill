const express = require('express');
const exportService = require('../services/exportService');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/export/parts.csv
 */
router.get('/parts.csv', (req, res) => {
  const csv = exportService.exportPartsToCsv();
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="windchill_wtparts_bom_export.csv"');
  res.send(csv);
});

/**
 * GET /api/export/products.csv
 */
router.get('/products.csv', (req, res) => {
  const csv = exportService.exportProductsToCsv();
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="windchill_products_export.csv"');
  res.send(csv);
});

/**
 * GET /api/export/changes.csv
 */
router.get('/changes.csv', (req, res) => {
  const csv = exportService.exportChangesToCsv();
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="windchill_change_requests_export.csv"');
  res.send(csv);
});

/**
 * GET /api/export/excel
 */
router.get('/excel', (req, res) => {
  const { type } = req.query;
  const content = exportService.exportToExcelXml(type || 'parts');
  res.setHeader('Content-Type', 'application/vnd.ms-excel; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="windchill_${type || 'parts'}_export.xls"`);
  res.send(content);
});

module.exports = router;
