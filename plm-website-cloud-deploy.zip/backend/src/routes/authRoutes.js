const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { db } = require('../db/database');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

/**
 * POST /api/auth/login
 */
router.post('/login', (req, res, next) => {
  try {
    const { login, password } = req.body;
    if (!login || !password) {
      return res.status(400).json({ error: 'Username/Email and password are required.' });
    }

    const user = db.prepare(`
      SELECT * FROM users 
      WHERE email = ? OR username = ?
    `).get(login, login);

    if (!user) {
      return res.status(401).json({ error: 'Invalid username/email or password.' });
    }

    const isValid = bcrypt.compareSync(password, user.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid username/email or password.' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    // Audit log
    db.prepare(`
      INSERT INTO audit_logs (user_id, user_name, action, entity_type, entity_id, details)
      VALUES (?, ?, 'LOGIN', 'USER', ?, 'Successful authentication')
    `).run(user.id, user.name, String(user.id));

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        name: user.name,
        department: user.department,
        avatar: user.avatar
      }
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/register
 */
router.post('/register', (req, res, next) => {
  try {
    const { email, username, password, name, department, role = 'Engineer' } = req.body;

    if (!email || !username || !password || !name) {
      return res.status(400).json({ error: 'Name, email, username, and password are required.' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?').get(email, username);
    if (existing) {
      return res.status(409).json({ error: 'User with this email or username already exists.' });
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    const validRole = ['Admin', 'Engineer', 'Viewer'].includes(role) ? role : 'Engineer';

    const insert = db.prepare(`
      INSERT INTO users (email, username, password_hash, role, name, department)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(email, username, passwordHash, validRole, name, department || 'Product Engineering');

    const newUser = db.prepare('SELECT id, email, username, role, name, department, avatar FROM users WHERE id = ?').get(insert.lastInsertRowid);

    const token = jwt.sign(
      { id: newUser.id, username: newUser.username, role: newUser.role },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.status(201).json({
      message: 'Account registered successfully',
      token,
      user: newUser
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/forgot-password
 */
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email address is required.' });
  }

  // Simulated password reset
  return res.json({
    message: 'If that email exists in the CIT PLM directory, password reset instructions have been dispatched.',
    demoNote: 'In demo mode, default accounts are admin@cit.com (admin123), engineer@cit.com (eng123), viewer@cit.com (view123).'
  });
});

/**
 * GET /api/auth/me
 */
router.get('/me', authenticate, (req, res) => {
  res.json({ user: req.user });
});

/**
 * POST /api/auth/profile-photo
 */
router.post('/profile-photo', authenticate, (req, res, next) => {
  try {
    const { photoUrl } = req.body;
    if (!photoUrl) {
      return res.status(400).json({ error: 'Photo data URL or image link is required.' });
    }

    db.prepare(`UPDATE users SET avatar = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(photoUrl, req.user.id);
    const updatedUser = db.prepare('SELECT id, email, username, role, name, department, avatar FROM users WHERE id = ?').get(req.user.id);

    // Audit log
    db.prepare(`
      INSERT INTO audit_logs (user_id, user_name, action, entity_type, entity_id, details)
      VALUES (?, ?, 'UPDATE_PROFILE_PHOTO', 'USER', ?, 'Updated user profile photograph')
    `).run(req.user.id, req.user.name, String(req.user.id));

    res.json({ message: 'Profile photo updated successfully', user: updatedUser });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/auth/users (Admin only)
 */
router.get('/users', authenticate, requireRole('Admin'), (req, res, next) => {
  try {
    const users = db.prepare('SELECT id, email, username, role, name, department, created_at FROM users ORDER BY id ASC').all();
    res.json({ users });
  } catch (err) {
    next(err);
  }
});

/**
 * PATCH /api/auth/users/:id/role (Admin only)
 */
router.patch('/users/:id/role', authenticate, requireRole('Admin'), (req, res, next) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (!['Admin', 'Engineer', 'Viewer'].includes(role)) {
      return res.status(400).json({ error: 'Role must be Admin, Engineer, or Viewer.' });
    }

    db.prepare(`UPDATE users SET role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(role, id);
    res.json({ message: 'User role updated successfully', id, role });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
