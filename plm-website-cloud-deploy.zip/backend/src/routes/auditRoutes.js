const express = require('express');
const { db } = require('../db/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/audit/logs
 */
router.get('/logs', authenticate, (req, res, next) => {
  try {
    const { action, search, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM audit_logs WHERE 1=1';
    const params = [];

    if (action) {
      sql += ' AND action = ?';
      params.push(action);
    }

    if (search) {
      sql += ' AND (details LIKE ? OR user_name LIKE ? OR entity_type LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s);
    }

    sql += ' ORDER BY timestamp DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit, 10), parseInt(offset, 10));

    const logs = db.prepare(sql).all(...params);
    const countSql = search 
      ? 'SELECT count(*) as total FROM audit_logs WHERE (details LIKE ? OR user_name LIKE ? OR entity_type LIKE ?)'
      : 'SELECT count(*) as total FROM audit_logs';
    const total = search ? db.prepare(countSql).get(`%${search}%`, `%${search}%`, `%${search}%`).total : db.prepare(countSql).get().total;

    res.json({ items: logs, total });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
