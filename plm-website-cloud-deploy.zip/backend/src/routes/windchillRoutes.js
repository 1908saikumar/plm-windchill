const express = require('express');
const windchillService = require('../services/windchillService');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/windchill/status
 */
router.get('/status', (req, res) => {
  const status = windchillService.lastConnectionStatus;
  status.isDemo = windchillService.isDemoMode();
  status.baseUrl = windchillService.getBaseUrl();
  res.json(status);
});

/**
 * POST /api/windchill/test-connection
 */
router.post('/test-connection', async (req, res, next) => {
  try {
    const result = await windchillService.testConnection();
    res.json(result);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/windchill/toggle-demo
 */
router.post('/toggle-demo', (req, res) => {
  const { enabled } = req.body;
  windchillService.setDemoMode(!!enabled);
  res.json({
    message: `Windchill Demo Mode ${enabled ? 'ENABLED' : 'DISABLED'}`,
    demoMode: windchillService.isDemoMode()
  });
});

/**
 * GET /api/windchill/products
 */
router.get('/products', async (req, res, next) => {
  try {
    const { search, limit, offset } = req.query;
    const data = await windchillService.getProducts({
      search: search || '',
      limit: parseInt(limit || '50', 10),
      offset: parseInt(offset || '0', 10)
    });
    res.json(data);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/windchill/products
 * Role: Admin or Engineer
 */
router.post('/products', authenticate, requireRole('Admin', 'Engineer'), async (req, res, next) => {
  try {
    const { name, description, template, privateAccess } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Product name is required.' });
    }

    const result = await windchillService.createProduct({
      name: name.trim(),
      description: description || '',
      template: template || 'GEN',
      privateAccess: !!privateAccess,
      createdBy: req.user.name
    });

    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/windchill/parts
 */
router.get('/parts', async (req, res, next) => {
  try {
    const { search, category, productId, parentId } = req.query;
    const parts = await windchillService.getParts({
      search,
      category,
      productId,
      parentId: parentId !== undefined ? parentId : undefined
    });
    res.json({ items: parts, total: parts.length });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/windchill/parts
 */
router.post('/parts', authenticate, requireRole('Admin', 'Engineer'), async (req, res, next) => {
  try {
    const { name, number, version, category, cost, weight, supplier, parentPartId, hasTwin, twinModelType } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Part name is required.' });
    }

    const created = await windchillService.createPart({
      name,
      number,
      version,
      category,
      cost: parseFloat(cost) || 0,
      weight: parseFloat(weight) || 0,
      supplier,
      parentPartId,
      hasTwin,
      twinModelType,
      author: req.user.name
    });

    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/windchill/bom
 */
router.get('/bom', async (req, res, next) => {
  try {
    const { rootPartId } = req.query;
    const tree = await windchillService.getBomTree(rootPartId || 'PART-EDU-TOP');
    res.json(tree);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/windchill/documents
 */
router.get('/documents', async (req, res, next) => {
  try {
    const { search, type } = req.query;
    const docs = await windchillService.getDocuments({ search, type });
    res.json({ items: docs, total: docs.length });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/windchill/documents
 */
router.post('/documents', authenticate, requireRole('Admin', 'Engineer'), async (req, res, next) => {
  try {
    const { name, type, version, fileName, fileSize, partId } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Document name is required.' });
    }

    const doc = await windchillService.createDocument({
      name,
      type,
      version,
      fileName,
      fileSize,
      partId,
      author: req.user.name
    });

    res.status(201).json(doc);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/windchill/change-requests
 */
router.get('/change-requests', async (req, res, next) => {
  try {
    const { search, type, priority } = req.query;
    const crs = await windchillService.getChangeRequests({ search, type, priority });
    res.json({ items: crs, total: crs.length });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/windchill/change-requests
 */
router.post('/change-requests', authenticate, requireRole('Admin', 'Engineer'), async (req, res, next) => {
  try {
    const { title, type, priority, affectedItemId, affectedItemName, description } = req.body;
    if (!title) {
      return res.status(400).json({ error: 'Change request title is required.' });
    }

    const cr = await windchillService.createChangeRequest({
      title,
      type,
      priority,
      affectedItemId,
      affectedItemName,
      description,
      createdBy: req.user.name
    });

    res.status(201).json(cr);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/windchill/credentials
 */
router.get('/credentials', authenticate, (req, res) => {
  const creds = windchillService.getCredentials();
  res.json({
    user: creds.user ? creds.user : '',
    hasPassword: !!creds.pass
  });
});

/**
 * POST /api/windchill/credentials
 */
router.post('/credentials', authenticate, requireRole('Admin', 'Engineer'), (req, res) => {
  const { user, pass } = req.body;
  if (!user) {
    return res.status(400).json({ error: 'Username is required.' });
  }
  windchillService.updateCredentials(user, pass || '');
  res.json({ message: 'Windchill credentials updated securely.', user });
});

/**
 * POST /api/windchill/execute-query
 */
router.post('/execute-query', authenticate, async (req, res, next) => {
  try {
    const { endpoint } = req.body;
    const result = await windchillService.executeODataQuery(endpoint || '/servlet/odata/v4/ProdMgmt/Products');
    res.json(result);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
