const express = require('express');
const digitalTwinService = require('../services/digitalTwinService');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/digital-twin/state
 */
router.get('/state', (req, res) => {
  const state = digitalTwinService.getState();
  res.json(state);
});

/**
 * POST /api/digital-twin/simulate-anomaly
 */
router.post('/simulate-anomaly', authenticate, (req, res) => {
  const { active, type } = req.body;
  const state = digitalTwinService.simulateAnomaly({
    active: active !== undefined ? active : true,
    type: type || 'BEARING_VIBRATION'
  });
  res.json(state);
});

module.exports = router;
