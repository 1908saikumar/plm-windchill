const express = require('express');
const aiService = require('../services/aiService');

const router = express.Router();

/**
 * POST /api/ai/chat
 */
router.post('/chat', async (req, res, next) => {
  try {
    const { message, context } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message query is required.' });
    }

    const response = await aiService.chat({ message, context });
    res.json(response);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/ai/predict-failure
 */
router.get('/predict-failure', async (req, res, next) => {
  try {
    const { partId } = req.query;
    const prediction = await aiService.predictFailureRisk(partId || 'PART-BEARING-DE');
    res.json(prediction);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/ai/bom-summary
 */
router.get('/bom-summary', async (req, res, next) => {
  try {
    const { rootPartId } = req.query;
    const summary = await aiService.generateBomSummary(rootPartId);
    res.json(summary);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/ai/change-impact/:id
 */
router.get('/change-impact/:id', async (req, res, next) => {
  try {
    const impact = await aiService.generateChangeImpact(req.params.id);
    res.json(impact);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/ai/detect-anomaly
 */
router.post('/detect-anomaly', async (req, res, next) => {
  try {
    const telemetry = req.body;
    const result = await aiService.detectSensorAnomalies(telemetry);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
