const express = require('express');
const { db } = require('../db/database');
const { authenticate, requireRole } = require('../middleware/auth');
const windchillService = require('../services/windchillService');

const router = express.Router();

/**
 * GET /api/settings
 */
router.get('/', (req, res, next) => {
  try {
    const rows = db.prepare('SELECT key, value, updated_at FROM settings').all();
    const settings = {};
    for (const r of rows) {
      settings[r.key] = r.value;
    }

    settings.windchill_server_ip = '172.16.31.150';
    settings.windchill_hostname = 'plm.cit.com';
    settings.windchill_user_configured = !!process.env.WINDCHILL_USER;
    res.json(settings);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/settings
 * Admin can update server URL, demo mode, and refresh rates
 */
router.post('/', authenticate, requireRole('Admin'), (req, res, next) => {
  try {
    const updates = req.body;
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO settings (key, value, updated_at)
      VALUES (?, ?, datetime('now'))
    `);

    for (const [key, value] of Object.entries(updates)) {
      if (typeof value !== 'undefined' && value !== null) {
        stmt.run(key, String(value));
        if (key === 'demo_mode') {
          windchillService.setDemoMode(value === 'true' || value === true);
        }
      }
    }

    db.prepare(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES (?, 'UPDATE_SETTINGS', 'SYSTEM', 'CONFIG', ?)
    `).run(req.user.name, `Updated system settings: ${Object.keys(updates).join(', ')}`);

    res.json({ message: 'Settings saved successfully' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
