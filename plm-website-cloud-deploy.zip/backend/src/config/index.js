require('dotenv').config();
const path = require('path');

const config = {
  port: parseInt(process.env.PORT || '5000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET || 'plm_default_secret_jwt_key_2026',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  
  windchill: {
    baseUrl: process.env.WINDCHILL_BASE_URL || 'http://plm.cit.com/Windchill',
    user: process.env.WINDCHILL_USER || '',
    pass: process.env.WINDCHILL_PASS || '',
    demoMode: process.env.DEMO_MODE !== 'false',
    timeoutMs: parseInt(process.env.WINDCHILL_TIMEOUT_MS || '6000', 10),
    maxRetries: parseInt(process.env.WINDCHILL_MAX_RETRIES || '2', 10),
    serverIp: '172.16.31.150',
    hostname: 'plm.cit.com'
  },
  
  ai: {
    apiKey: process.env.LLM_API_KEY || '',
    provider: process.env.LLM_PROVIDER || 'builtin'
  },
  
  db: {
    filePath: (() => {
      const fs = require('fs');
      const rootDb = path.resolve(__dirname, '../../../data/plm_digital_twin.db');
      const backendDb = path.resolve(__dirname, '../../data/plm_digital_twin.db');
      if (fs.existsSync(backendDb)) return backendDb;
      if (fs.existsSync(rootDb)) return rootDb;
      return backendDb;
    })()
  },
  
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173'
};

module.exports = config;
