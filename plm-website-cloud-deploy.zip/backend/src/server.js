const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const { initSchema } = require('./db/database');
const seed = require('./db/seed');
const errorHandler = require('./middleware/errorHandler');

// Import Route Handlers
const authRoutes = require('./routes/authRoutes');
const windchillRoutes = require('./routes/windchillRoutes');
const aiRoutes = require('./routes/aiRoutes');
const digitalTwinRoutes = require('./routes/digitalTwinRoutes');
const auditRoutes = require('./routes/auditRoutes');
const exportRoutes = require('./routes/exportRoutes');
const settingsRoutes = require('./routes/settingsRoutes');

const app = express();

// Security Middleware
app.use(helmet({
  contentSecurityPolicy: false, // Allow 3D canvas and inline assets
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));

app.use(cors({
  origin: true, // Allow client origin
  credentials: true
}));

// Rate Limiting (1000 requests per 15 mins for smooth live telemetry)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// Body Parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'UP',
    name: 'AI & Digital Twin Integration in PLM - Windchill API Proxy',
    timestamp: new Date().toISOString(),
    environment: config.nodeEnv,
    windchillServer: {
      baseUrl: config.windchill.baseUrl,
      serverIp: config.windchill.serverIp,
      hostname: config.windchill.hostname
    }
  });
});

// Mount API Routes
app.use('/api/auth', authRoutes);
app.use('/api/windchill', windchillRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/digital-twin', digitalTwinRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/settings', settingsRoutes);

// Serve Static Frontend if built
const frontendDist = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

// Error Handling Middleware
app.use(errorHandler);

// Start Server
const PORT = config.port;
const server = app.listen(PORT, () => {
  console.log(`=================================================================`);
  console.log(`🚀 CIT PLM & Digital Twin Platform Backend Running on port ${PORT}`);
  console.log(`🌐 Windchill Server Target: ${config.windchill.baseUrl} (${config.windchill.serverIp})`);
  console.log(`🛡️ Hosts Requirement: 172.16.31.150 plm.cit.com`);
  console.log(`💡 Mode: ${config.windchill.demoMode ? 'DEMO MODE (Simulated Fallback Ready)' : 'LIVE WINDCHILL'}`);
  console.log(`=================================================================`);
});

// Auto seed on boot
initSchema();
seed().catch(err => console.error('Seed error:', err.message));

module.exports = { app, server };
