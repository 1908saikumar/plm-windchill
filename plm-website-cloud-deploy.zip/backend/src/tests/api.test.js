const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const { app, server } = require('../server');

function makeRequest(path, { method = 'GET', body = null, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const port = server.address().port;
    const reqHeaders = { ...headers };
    let postData = '';

    if (body) {
      postData = JSON.stringify(body);
      reqHeaders['Content-Type'] = 'application/json';
      reqHeaders['Content-Length'] = Buffer.byteLength(postData);
    }

    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path,
      method,
      headers: reqHeaders
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let parsed = data;
        try {
          parsed = JSON.parse(data);
        } catch (e) {
          // keep as string
        }
        resolve({ status: res.statusCode, headers: res.headers, data: parsed });
      });
    });

    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

test('PLM & Digital Twin API Test Suite', async (t) => {
  let authToken = '';

  await t.test('1. Health check returns UP and Windchill server details', async () => {
    const res = await makeRequest('/api/health');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.status, 'UP');
    assert.strictEqual(res.data.windchillServer.serverIp, '172.16.31.150');
    assert.strictEqual(res.data.windchillServer.hostname, 'plm.cit.com');
  });

  await t.test('2. Auth login with valid admin credentials', async () => {
    const res = await makeRequest('/api/auth/login', {
      method: 'POST',
      body: { login: 'admin@cit.com', password: 'admin123' }
    });
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.token, 'Should return JWT token');
    assert.strictEqual(res.data.user.role, 'Admin');
    authToken = res.data.token;
  });

  await t.test('3. Auth login with invalid credentials fails with 401', async () => {
    const res = await makeRequest('/api/auth/login', {
      method: 'POST',
      body: { login: 'admin@cit.com', password: 'wrongpassword' }
    });
    assert.strictEqual(res.status, 401);
  });

  await t.test('4. Windchill connection status endpoint returns status and demo mode', async () => {
    const res = await makeRequest('/api/windchill/status');
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.baseUrl.includes('plm.cit.com'));
    assert.strictEqual(res.data.isDemo, true);
  });

  await t.test('5. Retrieve Windchill products and verify GEN template default', async () => {
    const res = await makeRequest('/api/windchill/products');
    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.data.items));
    assert.ok(res.data.items.length > 0);
    assert.strictEqual(res.data.items[0].template, 'GEN');
  });

  await t.test('6. Retrieve Bill of Materials (BOM) multi-level tree', async () => {
    const res = await makeRequest('/api/windchill/bom?rootPartId=PART-EDU-TOP');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.id, 'PART-EDU-TOP');
    assert.ok(Array.isArray(res.data.children));
    assert.ok(res.data.children.length > 0);
  });

  await t.test('7. Digital Twin telemetry endpoint returns live data and sensors', async () => {
    const res = await makeRequest('/api/digital-twin/state');
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.currentTelemetry.temperature > 0);
    assert.ok(res.data.currentTelemetry.rpm > 0);
    assert.ok(Array.isArray(res.data.lifecycle));
  });

  await t.test('8. AI failure prediction model returns Weibull curve and RUL', async () => {
    const res = await makeRequest('/api/ai/predict-failure?partId=PART-BEARING-DE');
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.remainingUsefulLifeHours > 0);
    assert.ok(Array.isArray(res.data.weibullCurve));
    assert.ok(res.data.weibullCurve.length > 0);
  });

  await t.test('9. AI PLM Copilot chat handles Creo and Windchill inquiries', async () => {
    const res = await makeRequest('/api/ai/chat', {
      method: 'POST',
      body: { message: 'How do I connect Creo Parametric to Windchill?' }
    });
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.reply.includes('Creo'));
    assert.ok(res.data.reply.includes('172.16.31.150') || res.data.reply.includes('plm.cit.com'));
  });

  await t.test('10. CSV Export of parts works properly', async () => {
    const res = await makeRequest('/api/export/parts.csv');
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.includes('Part Number'));
    assert.ok(res.data.includes('EDU-250'));
  });

  // Close server when done
  server.close();
});
