const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Ensure directory exists
const dbDir = path.dirname(config.db.filePath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new DatabaseSync(config.db.filePath);

// Enable WAL mode and foreign keys for high performance & reliability
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
`);

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'Engineer', -- 'Admin', 'Engineer', 'Viewer'
      name TEXT NOT NULL,
      department TEXT DEFAULT 'Product Engineering',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      user_name TEXT,
      action TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      ip_address TEXT,
      timestamp TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS cached_products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      number TEXT,
      description TEXT,
      template TEXT DEFAULT 'GEN',
      private_access INTEGER DEFAULT 0,
      state TEXT DEFAULT 'INWORK',
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      raw_json TEXT
    );

    CREATE TABLE IF NOT EXISTS cached_parts (
      id TEXT PRIMARY KEY,
      number TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      version TEXT DEFAULT 'A.1',
      state TEXT DEFAULT 'INWORK',
      product_id TEXT,
      category TEXT,
      cost REAL DEFAULT 0,
      weight REAL DEFAULT 0,
      unit TEXT DEFAULT 'ea',
      supplier TEXT,
      lead_time_days INTEGER DEFAULT 14,
      failure_rate REAL DEFAULT 0.02,
      parent_part_id TEXT,
      has_twin INTEGER DEFAULT 0,
      twin_model_type TEXT,
      raw_json TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS cached_documents (
      id TEXT PRIMARY KEY,
      number TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      type TEXT DEFAULT 'CADDrawing',
      version TEXT DEFAULT 'A.1',
      state TEXT DEFAULT 'APPROVED',
      file_name TEXT,
      file_size INTEGER DEFAULT 1048576,
      part_id TEXT,
      author TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS cached_change_requests (
      id TEXT PRIMARY KEY,
      number TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      type TEXT DEFAULT 'ECR', -- 'ECR', 'ECO', 'PR'
      priority TEXT DEFAULT 'Medium', -- 'Low', 'Medium', 'High', 'Critical'
      state TEXT DEFAULT 'Submitted', -- 'Draft', 'Submitted', 'Under Review', 'Approved', 'Implemented', 'Closed'
      affected_item_id TEXT,
      affected_item_name TEXT,
      description TEXT,
      ai_risk_score REAL DEFAULT 0.25,
      ai_impact_analysis TEXT,
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS sensor_telemetry (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      twin_id TEXT NOT NULL,
      temperature REAL,
      vibration REAL,
      pressure REAL,
      rpm REAL,
      power REAL,
      is_anomaly INTEGER DEFAULT 0,
      anomaly_reason TEXT,
      timestamp TEXT DEFAULT (datetime('now'))
    );
  `);
}

// Initialize tables
initSchema();

module.exports = {
  db,
  initSchema
};
