const bcrypt = require('bcryptjs');
const { db, initSchema } = require('./database');

async function seed() {
  console.log('🌱 Starting PLM Database Seeding...');
  initSchema();

  // 1. Seed Users
  const userCheck = db.prepare('SELECT COUNT(*) as count FROM users').get();
  if (userCheck.count === 0) {
    console.log('👤 Seeding default users (Admin, Engineer, Viewer)...');
    const adminHash = bcrypt.hashSync('admin123', 10);
    const engHash = bcrypt.hashSync('eng123', 10);
    const viewHash = bcrypt.hashSync('view123', 10);

    const insertUser = db.prepare(`
      INSERT INTO users (email, username, password_hash, role, name, department, avatar)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    insertUser.run(
      'admin@cit.com',
      'admin',
      adminHash,
      'Admin',
      'CIT PLM Administrator',
      'Systems Engineering',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
    );

    insertUser.run(
      'engineer@cit.com',
      'engineer',
      engHash,
      'Engineer',
      'Dr. Robert Chen',
      'Mechanical & Digital Twin R&D',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80'
    );

    insertUser.run(
      'viewer@cit.com',
      'viewer',
      viewHash,
      'Viewer',
      'Sarah Jenkins',
      'Quality & Production Audit',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80'
    );
  }

  // 2. Seed Default Settings
  const insertSetting = db.prepare(`
    INSERT OR REPLACE INTO settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
  `);

  insertSetting.run('windchill_base_url', 'http://plm.cit.com/Windchill');
  insertSetting.run('windchill_server_ip', '172.16.31.150');
  insertSetting.run('demo_mode', 'true');
  insertSetting.run('refresh_interval_sec', '5');
  insertSetting.run('theme_mode', 'dark');
  insertSetting.run('accent_color', 'teal');
  insertSetting.run('telemetry_sample_rate_ms', '1000');
  insertSetting.run('ai_temperature_anomaly_limit', '85.0');
  insertSetting.run('ai_vibration_anomaly_limit', '4.2');

  // 3. Seed Products
  const prodCheck = db.prepare('SELECT COUNT(*) as count FROM cached_products').get();
  if (prodCheck.count === 0) {
    console.log('📦 Seeding Windchill Products...');
    const insertProd = db.prepare(`
      INSERT INTO cached_products (id, name, number, description, template, private_access, state, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertProd.run(
      'PROD-EDU250',
      'High-Efficiency Electric Drive Unit 250kW',
      'PRD-00100',
      'Next-generation integrated e-axle motor, inverter and planetary gearbox for electric commercial mobility.',
      'GEN',
      0,
      'RELEASED',
      'Dr. Robert Chen'
    );

    insertProd.run(
      'PROD-AEROX4',
      'Autonomous Industrial Inspection Drone (AERO-X4)',
      'PRD-00101',
      'Long-endurance quadrotor system equipped with LiDAR and thermal imaging for high-voltage infrastructure.',
      'GEN',
      0,
      'INWORK',
      'CIT Systems Eng'
    );

    insertProd.run(
      'PROD-COBOT6',
      'Collaborative 6-Axis Articulated Robotic Arm',
      'PRD-00102',
      'High-precision collaborative manufacturing robot with embedded torque sensors on all joints.',
      'GEN',
      0,
      'UNDERREVIEW',
      'Automation Lab'
    );

    insertProd.run(
      'PROD-TURBINE9',
      'Smart Industrial Gas Turbine Blade & Stator Assembly',
      'PRD-00103',
      'Ceramic matrix composite blade assembly with embedded fiber-optic thermal strain sensors.',
      'GEN',
      0,
      'RELEASED',
      'Advanced Propulsion Group'
    );
  }

  // 4. Seed Parts & Multi-level BOM
  const partCheck = db.prepare('SELECT COUNT(*) as count FROM cached_parts').get();
  if (partCheck.count === 0) {
    console.log('⚙️ Seeding Windchill WTParts & BOM Tree...');
    const insertPart = db.prepare(`
      INSERT INTO cached_parts (
        id, number, name, version, state, product_id, category,
        cost, weight, unit, supplier, lead_time_days, failure_rate,
        parent_part_id, has_twin, twin_model_type
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Top Assembly
    insertPart.run(
      'PART-EDU-TOP',
      'EDU-250-ASY-001',
      'Electric Drive Unit 250kW Final Assembly',
      'B.1',
      'RELEASED',
      'PROD-EDU250',
      'Assembly',
      4250.00,
      78.5,
      'ea',
      'CIT Advanced Dynamics',
      28,
      0.012,
      null,
      1,
      'electric_motor'
    );

    // Level 1 Subassemblies
    insertPart.run(
      'PART-ROTOR-ASY',
      'EDU-250-ROT-100',
      'High-Speed Permanent Magnet Rotor Subassembly',
      'B.1',
      'RELEASED',
      'PROD-EDU250',
      'Subassembly',
      1280.00,
      22.4,
      'ea',
      'Neomagnetics AG',
      21,
      0.018,
      'PART-EDU-TOP',
      1,
      'rotor_shaft'
    );

    insertPart.run(
      'PART-STATOR-ASY',
      'EDU-250-STA-200',
      'Hairpin Winding Stator Core Assembly',
      'A.3',
      'RELEASED',
      'PROD-EDU250',
      'Subassembly',
      1450.00,
      31.2,
      'ea',
      'ElectroCoil Tech',
      25,
      0.015,
      'PART-EDU-TOP',
      1,
      'stator_housing'
    );

    insertPart.run(
      'PART-GEARBOX-ASY',
      'EDU-250-GBX-300',
      'Two-Stage Helical Planetary Reduction Gearbox',
      'A.2',
      'UNDERREVIEW',
      'PROD-EDU250',
      'Subassembly',
      920.00,
      18.0,
      'ea',
      'Precision Gears Ltd',
      30,
      0.024,
      'PART-EDU-TOP',
      1,
      'gearbox'
    );

    insertPart.run(
      'PART-INVERTER-MOD',
      'EDU-250-INV-400',
      'Silicon Carbide (SiC) Inverter Module 800V',
      'C.0',
      'RELEASED',
      'PROD-EDU250',
      'Electronics',
      600.00,
      6.9,
      'ea',
      'PowerSem Semi Corp',
      45,
      0.009,
      'PART-EDU-TOP',
      0,
      null
    );

    // Level 2 Components (under Rotor)
    insertPart.run(
      'PART-SHAFT-01',
      'EDU-250-ROT-101',
      'Forged High-Torque Rotor Shaft (EN24T)',
      'B.2',
      'RELEASED',
      'PROD-EDU250',
      'Component',
      380.00,
      11.8,
      'ea',
      'AlloyForging Co',
      18,
      0.005,
      'PART-ROTOR-ASY',
      0,
      null
    );

    insertPart.run(
      'PART-BEARING-DE',
      'EDU-250-BRG-102',
      'Drive-End Ceramic Hybrid Deep Groove Ball Bearing (6205)',
      'A.1',
      'RELEASED',
      'PROD-EDU250',
      'Standard Component',
      145.00,
      0.65,
      'ea',
      'SKF Precision',
      10,
      0.045, // Primary failure watchpoint
      'PART-ROTOR-ASY',
      1,
      'bearing_de'
    );

    insertPart.run(
      'PART-BEARING-NDE',
      'EDU-250-BRG-103',
      'Non-Drive End High-Speed Bearing with Current Insulation',
      'A.1',
      'RELEASED',
      'PROD-EDU250',
      'Standard Component',
      135.00,
      0.55,
      'ea',
      'SKF Precision',
      10,
      0.038,
      'PART-ROTOR-ASY',
      0,
      null
    );

    // Level 2 Components (under Stator)
    insertPart.run(
      'PART-HOUSING-AL',
      'EDU-250-CAS-201',
      'Die-Cast Aluminum Water-Glycol Cooling Jacket',
      'A.4',
      'RELEASED',
      'PROD-EDU250',
      'Component',
      520.00,
      14.5,
      'ea',
      'CastForm Industries',
      24,
      0.008,
      'PART-STATOR-ASY',
      0,
      null
    );

    insertPart.run(
      'PART-TEMP-SENSOR',
      'EDU-250-SNS-202',
      'Four-Wire RTD PT100 Stator Thermal Probe',
      'A.2',
      'RELEASED',
      'PROD-EDU250',
      'Sensor',
      42.00,
      0.12,
      'ea',
      'Sensoronics',
      7,
      0.015,
      'PART-STATOR-ASY',
      0,
      null
    );

    insertPart.run(
      'PART-VIB-ACCEL',
      'EDU-250-SNS-203',
      'Triaxial High-Bandwidth Piezoelectric Accelerometer',
      'B.1',
      'RELEASED',
      'PROD-EDU250',
      'Sensor',
      88.00,
      0.08,
      'ea',
      'VibeTech Global',
      12,
      0.020,
      'PART-STATOR-ASY',
      0,
      null
    );
  }

  // 5. Seed Documents
  const docCheck = db.prepare('SELECT COUNT(*) as count FROM cached_documents').get();
  if (docCheck.count === 0) {
    console.log('📄 Seeding Windchill WTDocuments & CAD models...');
    const insertDoc = db.prepare(`
      INSERT INTO cached_documents (id, number, name, type, version, state, file_name, file_size, part_id, author)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertDoc.run(
      'DOC-CAD-001',
      'DOC-000412',
      'Creo CAD Master Assembly 3D Model',
      'CreoCADModel',
      'B.2',
      'APPROVED',
      'edu_250_master_assy.asm',
      48234496,
      'PART-EDU-TOP',
      'Dr. Robert Chen'
    );

    insertDoc.run(
      'DOC-DRW-002',
      'DOC-000413',
      'Manufacturing GD&T Tolerance Drawing Sheet 1-4',
      'CADDrawing',
      'B.1',
      'APPROVED',
      'edu_250_manufacturing_dwg.drw',
      8388608,
      'PART-EDU-TOP',
      'CIT Drafting Group'
    );

    insertDoc.run(
      'DOC-FEA-003',
      'DOC-000414',
      'Ansys FEA Thermal Stress & Harmonic Response Report',
      'AnalysisReport',
      'A.1',
      'APPROVED',
      'edu250_thermal_harmonic_analysis.pdf',
      12582912,
      'PART-STATOR-ASY',
      'Dr. Robert Chen'
    );

    insertDoc.run(
      'DOC-SPEC-004',
      'DOC-000415',
      'ISO 26262 ASIL-D Functional Safety Qualification Protocol',
      'Specification',
      'C.0',
      'INWORK',
      'iso26262_functional_safety_v3.pdf',
      4194304,
      'PART-INVERTER-MOD',
      'Sarah Jenkins'
    );
  }

  // 6. Seed Change Requests
  const crCheck = db.prepare('SELECT COUNT(*) as count FROM cached_change_requests').get();
  if (crCheck.count === 0) {
    console.log('🔄 Seeding Windchill Change Requests (ECR/ECO/PR)...');
    const insertCR = db.prepare(`
      INSERT INTO cached_change_requests (
        id, number, title, type, priority, state,
        affected_item_id, affected_item_name, description,
        ai_risk_score, ai_impact_analysis, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertCR.run(
      'CR-ECR-0081',
      'ECR-00081',
      'Upgrade Drive-End Bearing to Si3N4 Hybrid Ceramic',
      'ECR',
      'High',
      'Under Review',
      'PART-BEARING-DE',
      'Drive-End Ceramic Hybrid Bearing (6205)',
      'High operational telemetry indicates elevated vibration harmonic (peak at 2.4x RPM) under continuous 14,000 RPM runs. Requesting upgrade to Si3N4 ceramic rolling elements with optimized cage geometry to extend MTBF from 18,000 hrs to 45,000 hrs.',
      0.34,
      'Low tooling risk. Moderate supplier lead time increase (+8 days). High reliability improvement (+150% bearing lifespan).',
      'Dr. Robert Chen'
    );

    insertCR.run(
      'CR-ECO-0094',
      'ECO-00094',
      'Optimize Stator Water Jacket Spiral Channel Pitch',
      'ECO',
      'Medium',
      'Approved',
      'PART-HOUSING-AL',
      'Die-Cast Aluminum Water-Glycol Cooling Jacket',
      'Fluid dynamic simulations indicate 4.2°C hotspot near winding termination. Redesign internal coolant jacket spiral pitch from 14mm to 11mm to enhance heat transfer coefficient by 18%.',
      0.22,
      'Requires die casting mold insert modification. Verified compatibility with existing O-ring sealing grooves.',
      'Thermal Eng Team'
    );

    insertCR.run(
      'CR-PR-0012',
      'PR-00012',
      'Intermittent Inverter Gate-Driver Under-Voltage Signal',
      'PR',
      'Critical',
      'Submitted',
      'PART-INVERTER-MOD',
      'Silicon Carbide Inverter Module 800V',
      'Occasional false positive under-voltage trip observed during rapid regenerative braking transients exceeding 320A. Needs filtering capacitor revision on PCB layer 2.',
      0.68,
      'High safety impact. Requires firmware filter debounce test and hardware qualification testing.',
      'Sarah Jenkins'
    );
  }

  // 7. Seed Sensor Telemetry History
  const telCheck = db.prepare('SELECT COUNT(*) as count FROM sensor_telemetry').get();
  if (telCheck.count === 0) {
    console.log('📡 Seeding Initial Digital Twin Telemetry...');
    const insertTel = db.prepare(`
      INSERT INTO sensor_telemetry (twin_id, temperature, vibration, pressure, rpm, power, is_anomaly, anomaly_reason, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now', ?))
    `);

    const basePoints = [
      { t: '-30 minutes', temp: 64.2, vib: 1.42, pres: 4.1, rpm: 8400, pwr: 142.0, anomaly: 0, reason: null },
      { t: '-25 minutes', temp: 66.8, vib: 1.55, pres: 4.15, rpm: 9200, pwr: 165.5, anomaly: 0, reason: null },
      { t: '-20 minutes', temp: 71.0, vib: 1.84, pres: 4.2, rpm: 11000, pwr: 198.0, anomaly: 0, reason: null },
      { t: '-15 minutes', temp: 74.5, vib: 2.10, pres: 4.25, rpm: 12500, pwr: 220.4, anomaly: 0, reason: null },
      { t: '-10 minutes', temp: 79.2, vib: 2.45, pres: 4.3, rpm: 13800, pwr: 242.0, anomaly: 0, reason: null },
      { t: '-5 minutes',  temp: 86.4, vib: 4.35, pres: 4.45, rpm: 14200, pwr: 249.5, anomaly: 1, reason: 'Temperature & Vibration Spike above safety thresholds (Bearing friction anomaly)' },
      { t: 'now',         temp: 81.3, vib: 3.12, pres: 4.35, rpm: 12000, pwr: 215.0, anomaly: 0, reason: 'Auto-throttle recovery active' }
    ];

    for (const pt of basePoints) {
      insertTel.run('TWIN-EDU250', pt.temp, pt.vib, pt.pres, pt.rpm, pt.pwr, pt.anomaly, pt.reason, pt.t);
    }
  }

  // 8. Seed Audit Log
  const auditCheck = db.prepare('SELECT COUNT(*) as count FROM audit_logs').get();
  if (auditCheck.count === 0) {
    const insertAudit = db.prepare(`
      INSERT INTO audit_logs (user_id, user_name, action, entity_type, entity_id, details, ip_address, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now', ?))
    `);

    insertAudit.run(1, 'CIT PLM Administrator', 'SYSTEM_INIT', 'SYSTEM', 'SYS-001', 'Database schema initialized and baseline seeded', '127.0.0.1', '-1 hour');
    insertAudit.run(2, 'Dr. Robert Chen', 'WINDCHILL_SYNC', 'PRODUCT', 'PROD-EDU250', 'Synchronized Part BOM tree from Windchill server plm.cit.com', '172.16.31.88', '-45 minutes');
    insertAudit.run(2, 'Dr. Robert Chen', 'DIGITAL_TWIN_CALIBRATION', 'TWIN', 'TWIN-EDU250', 'Calibrated sensor thresholds and 3D exploded view hierarchy', '172.16.31.88', '-30 minutes');
    insertAudit.run(3, 'Sarah Jenkins', 'AUDIT_REVIEW', 'CHANGE_REQUEST', 'CR-ECR-0081', 'Reviewed ECR-00081 Si3N4 ceramic bearing upgrade impact', '172.16.31.95', '-15 minutes');
  }

  console.log('✅ Seeding completed successfully!');
}

if (require.main === module) {
  seed().catch(err => {
    console.error('❌ Seeding error:', err);
    process.exit(1);
  });
}

module.exports = seed;
