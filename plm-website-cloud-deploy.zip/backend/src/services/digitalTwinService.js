const { db } = require('../db/database');
const aiService = require('./aiService');

class DigitalTwinService {
  constructor() {
    this.activeAnomaly = false;
    this.anomalyType = null;
    this.currentSimulationState = {
      twinId: 'TWIN-EDU250',
      partNumber: 'EDU-250-ASY-001',
      partName: 'High-Efficiency Electric Drive Unit 250kW',
      windchillPartId: 'PART-EDU-TOP',
      operationalHours: 14218,
      status: 'OPERATING',
      currentTelemetry: {
        temperature: 78.4,
        vibration: 2.15,
        pressure: 4.22,
        rpm: 12000,
        power: 210.5,
        statorCurrentA: 265.0,
        efficiencyPct: 96.4,
        timestamp: new Date().toISOString()
      },
      thresholds: {
        temperatureWarning: 80.0,
        temperatureCritical: 85.0,
        vibrationWarning: 3.0,
        vibrationCritical: 4.2,
        pressureWarning: 4.5,
        pressureCritical: 5.0,
        rpmMax: 15000
      },
      lifecycle: [
        { stage: 'Design', status: 'Completed', date: '2025-03-12', detail: 'Creo 3D Master Assembly & GD&T sign-off' },
        { stage: 'Manufacture', status: 'Completed', date: '2025-08-20', detail: 'Zero-defect pilot batch assembly at CIT Fab' },
        { stage: 'Operate', status: 'Active', date: '2026-01-10', detail: 'Field telemetry linked to Windchill digital thread' },
        { stage: 'Service', status: 'Upcoming', date: '2026-11-15', detail: 'Preventive bearing overhaul scheduled (ECR-00081)' },
        { stage: 'Retire', status: 'Pending', date: '2034-01-01', detail: 'Scheduled 10-year circular economy recycling' }
      ]
    };

    // Keep memory cache of recent 60 telemetry points for high-frequency chart rendering
    this.recentBuffer = [];
    this.initBuffer();
  }

  initBuffer() {
    try {
      const rows = db.prepare(`
        SELECT * FROM sensor_telemetry 
        WHERE twin_id = 'TWIN-EDU250' 
        ORDER BY timestamp ASC LIMIT 40
      `).all();
      this.recentBuffer = rows.map(r => ({
        id: r.id,
        temperature: r.temperature,
        vibration: r.vibration,
        pressure: r.pressure,
        rpm: r.rpm,
        power: r.power,
        isAnomaly: !!r.is_anomaly,
        anomalyReason: r.anomaly_reason,
        timestamp: r.timestamp
      }));
    } catch (e) {
      this.recentBuffer = [];
    }
  }

  /**
   * Generate next live tick of simulated sensor telemetry
   */
  generateTelemetryTick() {
    const s = this.currentSimulationState.currentTelemetry;
    
    // Natural jitter
    const tempNoise = (Math.random() - 0.48) * 0.4;
    const vibNoise = (Math.random() - 0.48) * 0.08;
    const presNoise = (Math.random() - 0.5) * 0.02;
    const rpmNoise = (Math.random() - 0.5) * 80;

    let targetTemp = 76.5;
    let targetVib = 2.0;

    if (this.activeAnomaly) {
      if (this.anomalyType === 'BEARING_VIBRATION') {
        targetVib = 4.45;
        targetTemp = 88.2;
      } else if (this.anomalyType === 'THERMAL_OVERLOAD') {
        targetTemp = 89.5;
        targetVib = 3.6;
      }
    }

    // Smooth convergence toward target with realistic dynamics
    s.temperature = Number(Math.max(40, Math.min(105, s.temperature * 0.95 + targetTemp * 0.05 + tempNoise)).toFixed(1));
    s.vibration = Number(Math.max(0.5, Math.min(8.0, s.vibration * 0.92 + targetVib * 0.08 + vibNoise)).toFixed(2));
    s.pressure = Number(Math.max(2.0, Math.min(6.0, s.pressure + presNoise)).toFixed(2));
    s.rpm = Math.round(Math.max(3000, Math.min(15000, s.rpm + rpmNoise)));
    s.power = Number(((s.rpm / 12000) * 210 + (Math.random() - 0.5) * 4).toFixed(1));
    s.timestamp = new Date().toISOString();

    const isAnomaly = s.temperature > this.currentSimulationState.thresholds.temperatureCritical ||
                      s.vibration > this.currentSimulationState.thresholds.vibrationCritical;

    const anomalyReason = isAnomaly 
      ? (s.vibration > 4.2 ? 'Critical Bearing Harmonic Resonance (4.35 mm/s)' : 'Thermal Overload Winding Exceeded (89°C)')
      : null;

    const point = {
      twinId: 'TWIN-EDU250',
      temperature: s.temperature,
      vibration: s.vibration,
      pressure: s.pressure,
      rpm: s.rpm,
      power: s.power,
      isAnomaly,
      anomalyReason,
      timestamp: s.timestamp
    };

    // Add to buffer
    this.recentBuffer.push(point);
    if (this.recentBuffer.length > 50) {
      this.recentBuffer.shift();
    }

    // Persist periodically into DB
    if (Math.random() < 0.25 || isAnomaly) {
      try {
        db.prepare(`
          INSERT INTO sensor_telemetry (twin_id, temperature, vibration, pressure, rpm, power, is_anomaly, anomaly_reason, timestamp)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `).run(point.twinId, point.temperature, point.vibration, point.pressure, point.rpm, point.power, point.isAnomaly ? 1 : 0, point.anomalyReason);
      } catch (e) {
        // ignore
      }
    }

    return point;
  }

  /**
   * Get Current Digital Twin state & recent telemetry series
   */
  getState() {
    // Generate fresh point on fetch
    this.generateTelemetryTick();
    return {
      ...this.currentSimulationState,
      recentSeries: this.recentBuffer,
      activeAnomaly: this.activeAnomaly,
      anomalyType: this.anomalyType
    };
  }

  /**
   * Trigger / Clear Anomaly Simulation
   */
  simulateAnomaly({ active = true, type = 'BEARING_VIBRATION' }) {
    this.activeAnomaly = active;
    this.anomalyType = active ? type : null;

    db.prepare(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ('Engineer', 'SIMULATE_ANOMALY', 'DIGITAL_TWIN', 'TWIN-EDU250', ?)
    `).run(active ? `Injected simulated anomaly: ${type}` : 'Cleared simulated anomaly. Reverted to steady state telemetry.');

    return this.getState();
  }
}

module.exports = new DigitalTwinService();
