const { db } = require('../db/database');

class ExportService {
  /**
   * Export Parts & BOM to CSV
   */
  exportPartsToCsv() {
    const parts = db.prepare('SELECT * FROM cached_parts ORDER BY number ASC').all();
    const headers = [
      'Part Number',
      'Name',
      'Revision',
      'Lifecycle State',
      'Category',
      'Unit Cost (USD)',
      'Weight (kg)',
      'Supplier',
      'Lead Time (Days)',
      'Annual Failure Rate (%)'
    ];

    const rows = parts.map(p => [
      `"${p.number}"`,
      `"${p.name.replace(/"/g, '""')}"`,
      `"${p.version}"`,
      `"${p.state}"`,
      `"${p.category}"`,
      p.cost.toFixed(2),
      p.weight.toFixed(2),
      `"${(p.supplier || '').replace(/"/g, '""')}"`,
      p.lead_time_days,
      (p.failure_rate * 100).toFixed(1)
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
  }

  /**
   * Export Products to CSV
   */
  exportProductsToCsv() {
    const products = db.prepare('SELECT * FROM cached_products ORDER BY number ASC').all();
    const headers = [
      'Product ID',
      'Number',
      'Name',
      'Template',
      'Private Access',
      'State',
      'Created By',
      'Created At'
    ];

    const rows = products.map(p => [
      `"${p.id}"`,
      `"${p.number}"`,
      `"${p.name.replace(/"/g, '""')}"`,
      `"${p.template}"`,
      p.private_access ? 'Yes' : 'No',
      `"${p.state}"`,
      `"${p.created_by}"`,
      `"${p.created_at}"`
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
  }

  /**
   * Export Change Requests to CSV
   */
  exportChangesToCsv() {
    const changes = db.prepare('SELECT * FROM cached_change_requests ORDER BY created_at DESC').all();
    const headers = [
      'Change Number',
      'Type',
      'Title',
      'Priority',
      'State',
      'Affected Item',
      'AI Risk Score',
      'Created By'
    ];

    const rows = changes.map(c => [
      `"${c.number}"`,
      `"${c.type}"`,
      `"${c.title.replace(/"/g, '""')}"`,
      `"${c.priority}"`,
      `"${c.state}"`,
      `"${(c.affected_item_name || '').replace(/"/g, '""')}"`,
      c.ai_risk_score.toFixed(2),
      `"${c.created_by}"`
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
  }

  /**
   * Export as Excel-compatible TSV/XML
   */
  exportToExcelXml(type = 'parts') {
    if (type === 'parts') {
      const csv = this.exportPartsToCsv();
      // Tab-separated values with BOM header opens natively in Excel without encoding issues
      return '\uFEFF' + csv.replace(/,/g, '\t');
    }
    const csv = this.exportProductsToCsv();
    return '\uFEFF' + csv.replace(/,/g, '\t');
  }
}

module.exports = new ExportService();
